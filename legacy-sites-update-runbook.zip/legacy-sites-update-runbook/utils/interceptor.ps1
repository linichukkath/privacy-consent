# Function to execute a query with exponential backoff
function ExecuteQueryWithRetry {
    [CmdletBinding()]
    param (
        [Microsoft.SharePoint.Client.ClientContext]$ctx
    )

    $callerInvocation = $MyInvocation
    $retryCount = 0
    $maxRetries = 5
    $delay = 5000 # Initial delay in milliseconds

    while ($retryCount -lt $maxRetries) {
        try {
            $ctx.ExecuteQuery()
            return
        }
        catch {
            $pushError = "The Push Notifications feature is not activated on the site"
            $errorMessage = $_.Exception.Message
            if ($_.Exception -is [Microsoft.SharePoint.Client.ClientRequestException] -and ($errorMessage -like "*429*" -or $errorMessage -like "*503*")) {
                $retryCount++
                Write-LogINFO "Throttled. Retrying in $delay milliseconds..."
                Start-Sleep -Milliseconds $delay
                $delay = [Math]::Min($delay * 2, 60000) # Exponential backoff with a max delay of 60 seconds
            }
            elseif ($_.Exception -is [System.OutOfMemoryException]) {
                Write-LogERR "Out of memory. Cannot continue."
                Write-LogERR "Error in $($callerInvocation.MyCommand) at $($callerInvocation.ScriptName):$($callerInvocation.ScriptLineNumber): $errorMessage"
                throw $_
            }
            elseif ($errorMessage -like "*(401)*" -or $errorMessage -like "*Unauthorized*") {
                # The context's bearer token is acquired once when the context is created and is
                # good for about an hour. A site whose dispatch waits on batch jobs runs far longer
                # than that, so every CSOM call after expiry returns 401 and the rest of the
                # migration collapses. GetSPOContext attaches a RefreshAccessToken method for
                # exactly this - it just was never called from anywhere.
                $retryCount++
                if ($null -eq $ctx.PSObject.Methods['RefreshAccessToken']) {
                    Write-LogERR "CSOM call returned 401 and this context has no RefreshAccessToken method: $errorMessage"
                    throw $_
                }
                Write-LogWarn "CSOM call returned 401 - refreshing the access token and retrying (attempt $retryCount of $maxRetries)."
                try {
                    $null = $ctx.RefreshAccessToken()
                }
                catch {
                    Write-LogERR "Access token refresh failed: $($_.Exception.Message)"
                    throw $_
                }
            }
            elseif ($errorMessage -like "*$pushError*") {
                $retryCount++
                Write-LogINFO "Transient error: $($errorMessage). Retrying in $delay milliseconds..."
                Start-Sleep -Milliseconds $delay
                $delay = [Math]::Min($delay * 2, 60000)
            }
            else {
                Write-LogERR "Unexpected error in $($callerInvocation.MyCommand) at $($callerInvocation.ScriptName):$($callerInvocation.ScriptLineNumber): $errorMessage"
                throw $_
            }
        }
    }

    throw "Max retry attempts reached. Operation failed."
}