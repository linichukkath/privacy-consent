
function Write-LogINFO {
    param($message)
    Write-Information ('INFO: ' + $message) -InformationAction Continue
}

function Write-LogWarn {
    param($message)
    Write-Warning ('WARN: ' + $message)
}

function Write-LogERR {
    param($message)
    Write-Error ('ERROR: ' + $message)
}

function Submit-Issue {
    #Function to use when you wish to log the error and also generate exception to be sent to parent scope
    #If you don't want to throw an exception and only log the error, use Write-LogERR

    Param(
      [Parameter(Mandatory)] $ErrorCode,
      [Parameter(Mandatory)] $ErrorText,
      $ErrorType #Error type can be null or have a value 'cancel'; if cancel, that means a cancellation will be triggered by UPS
    )
    Write-LogERR -Message ($ErrorCode.ToString() + ': ' + $ErrorText)
    $global:Issue = @{}
    $global:Issue.ErrorCode = $ErrorCode
    $global:Issue.ErrorType = $Errortype
    $global:Issue.ErrorText = $ErrorText
    throw $ErrorText
}

function Get-ProvisioningParameters {
    #This will mock fetching of job parameters from UPS Database
  $Params = @{
    RequestorEMail      = ''
    ResponseType        = ''
    SPO_CHANGE_LIBRARY  = 'update_all_libraries'
    RequestorID         = ''
    RequestID           = ''
    OrdererEMail        = ''
    LogicalObject       = ''
    OE                  = ''
    OriginalRequest     = ''
    ProviderItem        = ''
    ManagerEMail        = ''
    RequestOperation    = ''
    SPOURL              = 'https://allianzms.sharepoint.com/teams/DE1890-13338292'
    O365Admin           = 'spoipg01@allianzms.onmicrosoft.com' #SPO admin account
    ServiceInstanceID   = ''
    JobResubmitCount    = ''
    Port                = ''
    TransactionID       = ''
    Admin1              = 'michal.husak@allianz.de' #Azure Object Id of primary owner
    Admin2              = 'lini.chukkath-kuttan@allianz.com' #Azure Object Id of secondary ownery
    Title               = 'Facelifted E3 Site'
    CompanyID           = 'DE1478'
    ProvisioningStatus  = @('WorkloadCreated')
    Language            = 'de-DE'
    CollabType          = '' # Values: 'team', 'teamSite'
    IsDMS               = $true
  }
    return ($Params)
}

function Update-DBProvisioningParameter {
  [CmdletBinding(SupportsShouldProcess=$true)]
  [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSReviewUnusedParameter', '', Justification = 'Parameter is used in UPS')]
  param([Parameter(Mandatory)]$JobParameters)

  if ($PSCmdlet.ShouldProcess("Database", "Update provisioning parameters")) {
    # no action needed for local testing
    # when used in Production, this function will replace the parameters in DB
  }
}

function Get-Password {
  [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingConvertToSecureStringWithPlainText', '', Justification = 'Password is read from external config file')]
  param (
    [Parameter(Mandatory=$true)] [string]$userName,
    [switch]$PWOnly )
  $passwords = Get-Content "$global:CurrDir\configs\localhost-config.json" -Raw | ConvertFrom-Json
  $password = $passwords.$userName
  if ($PWOnly.IsPresent) {
    return $password
  }
  $cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $userName, $(ConvertTo-SecureString $password -AsPlainText -Force)
  return $cred
}