# this function needs to be assigned to a variable in order to be used in the Runspaces
# also this function contains embedded functions that are called within the updateItem function as it is not easy to pass them as arguments to the runspace
$updateItem = {
    param (
        [Parameter(Mandatory = $true)]
        [string]$siteUrl,

        [Parameter(Mandatory = $true)]
        [string]$libraryGUID,

        [Parameter(Mandatory = $true)]
        [hashtable]$headers,

        [Parameter(Mandatory = $true)]
        [object]$item,

        [Parameter(Mandatory = $true)]
        [string]$wantedContentTypeId,

        [Parameter(Mandatory = $true)]
        [psobject] $documentClassTerms,

        [Parameter(Mandatory = $true)]
        [int] $timeZoneOffset,

        [Parameter(Mandatory = $false)]
        [array] $mappedValuesArray
    )

    # inner helper functions
    function formatModifiedField {
        param (
            [Parameter(Mandatory = $true)]
            [string]$modifiedDateTimeString,

            [Parameter(Mandatory = $true)]
            [int]$timeZoneOffset

        )

        $culture = [CultureInfo]'en-us'
        $modifiedDateTime = [DateTime]::Parse($modifiedDateTimeString).ToUniversalTime().AddMinutes(-$timeZoneOffset)
        return $modifiedDateTime.ToString("yyyy-MM-dd HH:mm:ss", $culture)
    }

    function findTermByValue() {
        param (
            [Parameter(Mandatory = $false)] [string] $value,
            [Parameter(Mandatory = $true)] [psobject] $documentClassTerms
        )

        if ($null -eq $value) {
            return $null
        }
        foreach ($term in $documentClassTerms) {
            foreach ($label in $term.Labels) {
                if ($label.Value -eq $value) {
                    return $term
                }
            }
        }
        return $null
    }

    function getMergedDescriptionValue() {
        param (
            [Parameter(Mandatory = $true)] [object] $item
        )

        $extendedDescriptionValue = $item.OData__ExtendedDescription
        $documentSetDescriptionValue = $item.DocumentSetDescription

        # if there is nothing to merge or the document set description was already previously migrated
        if ($null -eq $extendedDescriptionValue -or $documentSetDescriptionValue -match "Legacy _ExtendedDescription") {
            return $documentSetDescriptionValue
        }

        if ($null -ne $extendedDescriptionValue) {
            return -join ($documentSetDescriptionValue, "`r`n Legacy _ExtendedDescription: ", $extendedDescriptionValue)
        }
        return $documentSetDescriptionValue
    }

    function hasLegacyDescriptionColumn() {
        param (
            [Parameter(Mandatory = $true)] [object] $item
        )
        return $null -ne $item.OData__ExtendedDescription
    }
    # end inner helper functions

    $itemId = $item.ItemId
    $itemUrl = "$siteUrl/_api/web/lists(guid'$libraryGUID')/Items($itemId)/ValidateUpdateListItem()"

    $updateParams = @{
        formValues = @(
            @{
                FieldName  = "ContentTypeId"
                FieldValue = $wantedContentTypeId
            },
            @{
                FieldName  = "Editor"
                FieldValue = "$($item.EditorId)"
            },
            @{
                FieldName  = "Modified"
                FieldValue = formatModifiedField -modifiedDateTimeString $item.Modified -timeZoneOffset $timeZoneOffset
            }
        )
    }
    $updateParams.bNewDocumentUpdate = $true

    # Add mapped values for choice fields if provided
    if ($null -ne $mappedValuesArray) {
        foreach ($mapped in $mappedValuesArray) {
            if ($null -ne $mapped.Field -and $null -ne $mapped.Value) {
                $updateParams.formValues += @{
                    FieldName  = $mapped.Field
                    FieldValue = $mapped.Value
                }
            }
        }
    }

    try {
        # Update the Document_Class field
        $term = findTermByValue -value $item.DocumentClass -documentClassTerms $documentClassTerms
        if ($null -eq $item.Document_Class -and $null -ne $term) {
            $updateParams.formValues += @{
                FieldName  = "Document_Class"
                FieldValue = "$($term.Name)|$($term.id)"
            }
        }

        # Update the DocumentSetDescription field if the legacy column has a value
        if (hasLegacyDescriptionColumn -item $item) {
            $updateParams.formValues += @{
                FieldName  = "DocumentSetDescription"
                FieldValue = getMergedDescriptionValue -item $item
            }
        }

        $maxRetries = 3
        $retryCount = 0
        $success = $false
        while (-not $success -and $retryCount -lt $maxRetries) {
            try {
                $itemMetadataJson = $updateParams | ConvertTo-Json -Depth 10
                $response = Invoke-RestMethod -Uri $itemUrl -Method Post -Headers $headers -Body $itemMetadataJson -ContentType "application/json;odata=verbose"

                $errors = @()
                $response.d.ValidateUpdateListItem.results | ForEach-Object {
                    # Editor/Modified are audit-stamp fields SharePoint sometimes flags as failed even though the value (and the real target field) was applied.
                    if ($_.HasException -and $_.FieldName -notin @('Editor', 'Modified')) {
                        $errors += $_.ErrorMessage
                    }
                }

                if ($errors.Count -gt 0) {
                    # Return an object indicating failure
                    return [PSCustomObject]@{
                        ItemId   = $itemId
                        Errors   = $errors
                        FileName = $item.File.Name
                        Path     = $item.File.ServerRelativeUrl
                        Url      = $item.File.LinkingUri
                    }
                }
                $success = $true
            }
            catch {
                if ($_.Exception.Response.StatusCode -in @(429, 409)) {
                    # Exponential backoff
                    Start-Sleep -Seconds ([math]::Pow(2, $retryCount))
                    $retryCount++
                }
                else {
                    throw $_
                }
            }
        }

        if (-not $success) {
            return [PSCustomObject]@{
                ItemId   = $itemId
                Errors   = @("Update failed after $maxRetries retry attempts")
                FileName = $item.File.Name
                Path     = $item.File.ServerRelativeUrl
                Url      = $item.File.LinkingUri
            }
        }
    }
    catch {
        # Catch any exceptions
        return [PSCustomObject]@{
            ItemId   = $item.ItemId
            Errors   = @($_.Exception.Message)
            FileName = $item.File.Name
            Path     = $item.File.ServerRelativeUrl
            Url      = $item.File.LinkingUri
        }
    }
}

function getContentTypeNameById {
    param (
        [Parameter(Mandatory = $true)] [string] $contentTypeId,
        [Parameter(Mandatory = $true)] [object[]] $libraryContentTypes
    )
    $match = $libraryContentTypes | Where-Object { $_.Id.StringValue -eq $contentTypeId }
    if ($match) { return $match.Name }
    return $contentTypeId
}


function New-UpdateItemPayload {
    param (
        [Parameter(Mandatory = $true)] [object]$item,
        [Parameter(Mandatory = $true)] [string]$wantedContentTypeId,
        [Parameter(Mandatory = $true)] [psobject]$documentClassTerms,
        [Parameter(Mandatory = $true)] [int]$timeZoneOffset,
        [Parameter(Mandatory = $false)] [array]$mappedValuesArray
    )

    $modifiedDateTime = [DateTime]::Parse($item.Modified).ToUniversalTime().AddMinutes(-$timeZoneOffset)
    $formValues = @(
        @{ FieldName = "ContentTypeId"; FieldValue = $wantedContentTypeId },
        @{ FieldName = "Editor"; FieldValue = "$($item.EditorId)" },
        @{ FieldName = "Modified"; FieldValue = $modifiedDateTime.ToString("yyyy-MM-dd HH:mm:ss", [CultureInfo]'en-us') }
    )

    if ($null -ne $mappedValuesArray) {
        foreach ($mapped in $mappedValuesArray) {
            if ($null -ne $mapped.Field -and $null -ne $mapped.Value) {
                $formValues += @{ FieldName = $mapped.Field; FieldValue = $mapped.Value }
            }
        }
    }

    if ($null -eq $item.Document_Class -and $null -ne $item.DocumentClass) {
        $term = $null
        foreach ($candidate in $documentClassTerms) {
            if ($candidate.Labels | Where-Object { $_.Value -eq $item.DocumentClass }) {
                $term = $candidate
                break
            }
        }
        if ($null -ne $term) {
            $formValues += @{ FieldName = "Document_Class"; FieldValue = "$($term.Name)|$($term.id)" }
        }
    }

    if ($null -ne $item.OData__ExtendedDescription) {
        $description = $item.DocumentSetDescription
        if ($description -notmatch "Legacy _ExtendedDescription") {
            $description = -join ($description, "`r`n Legacy _ExtendedDescription: ", $item.OData__ExtendedDescription)
        }
        $formValues += @{ FieldName = "DocumentSetDescription"; FieldValue = $description }
    }

    return @{ formValues = $formValues; bNewDocumentUpdate = $true } | ConvertTo-Json -Depth 10 -Compress
}

function getChoiceFieldsToMap {
    param (
        [Parameter(Mandatory = $true)] [string]$configPath
    )

    if (Test-Path $configPath) {
        $configuredFields = @(Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json)
        if ($configuredFields.Count -gt 0) {
            return @($configuredFields | ForEach-Object {
                    if ($_ -is [string]) {
                        $_
                    }
                    elseif ($null -ne $_.InternalName) {
                        $_.InternalName
                    }
                    elseif ($null -ne $_.Key) {
                        $_.Key
                    }
                } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        }
    }

    $columnsConfigPath = "$global:CurrDir\configs\columns.json"
    if (-not (Test-Path $columnsConfigPath)) {
        Write-LogWarn "Choice field mapping skipped: $columnsConfigPath not found."
        return @()
    }

    $columnsConfig = Get-Content $columnsConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    return @($columnsConfig.PSObject.Properties |
        Where-Object { $_.Value.Type -eq 'Choice' -and $null -ne $_.Value.Choices } |
        ForEach-Object { if ($null -ne $_.Value.InternalName) { $_.Value.InternalName } else { $_.Name } })
}

# Audit-stamp fields SharePoint sometimes flags as HasException=true via ValidateUpdateListItem
# even though the value (and the real target field, e.g. ContentTypeId) was actually applied.
$script:BenignUpdateExceptionFields = @('Editor', 'Modified')

function Get-SharePointBatchPartErrors {
    <#
        Parses a single sub-response's JSON body and returns a list of
        human-readable error strings. Empty array = success.

        Handles two shapes:
          1. A top-level SharePoint REST error (bad request, permissions, etc.)
             -> { "error": { "message": { "value": "..." } } }
          2. A ValidateUpdateListItem() result, which returns HTTP 200 even
             when individual fields failed validation
             -> { "d": { "ValidateUpdateListItem": { "results": [ { "FieldName": ..., "ErrorMessage": ..., "HasException": ... } ] } } }
    #>
    param (
        [Parameter(Mandatory = $true)] [string]$JsonBody
    )

    $errors = @()

    try {
        $parsed = $JsonBody | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        return @("Could not parse SharePoint response JSON: $($_.Exception.Message)")
    }

    if ($parsed.error) {
        $message = $parsed.error.message.value
        if (-not $message) { $message = $parsed.error.message }
        $errors += "SharePoint error: $message"
        return $errors
    }

    $validationResults = $parsed.d.ValidateUpdateListItem.results
    if ($validationResults) {
        foreach ($fieldResult in $validationResults) {
            if ($fieldResult.HasException -or $fieldResult.ErrorMessage) {
                $errors += "Field '$($fieldResult.FieldName)': $($fieldResult.ErrorMessage)"
            }
        }
        return $errors
    }

    return $errors
}

function New-SharePointBatchBody {
    <#
        Builds a $batch payload with ONE CHANGESET PER ITEM.

        This is deliberate: a changeset is transactional in SharePoint - if any
        request inside a changeset fails, the whole changeset rolls back, including
        requests that would otherwise have succeeded. Wrapping every item in its
        own changeset means one bad item can never take down the others in the
        same batch.
    #>
    param (
        [Parameter(Mandatory = $true)] [string]$siteUrl,
        [Parameter(Mandatory = $true)] [string]$libraryGUID,
        [Parameter(Mandatory = $true)] [string]$BatchBoundary,
        [Parameter(Mandatory = $true)] [object[]]$WorkItems
    )

    $body = [System.Text.StringBuilder]::new()

    foreach ($workItem in $WorkItems) {
        $changesetBoundary = "changeset_$([Guid]::NewGuid().ToString('N'))"
        $itemUrl = "$siteUrl/_api/web/lists(guid'$libraryGUID')/Items($($workItem.Item.ItemId))/ValidateUpdateListItem()"

        $null = $body.Append("--$BatchBoundary`r`n")
        $null = $body.Append("Content-Type: multipart/mixed; boundary=$changesetBoundary`r`n`r`n")
        $null = $body.Append("--$changesetBoundary`r`n")
        $null = $body.Append("Content-Type: application/http`r`n")
        $null = $body.Append("Content-Transfer-Encoding: binary`r`n`r`n")
        $null = $body.Append("POST $itemUrl HTTP/1.1`r`n")
        $null = $body.Append("Accept: application/json;odata=verbose`r`n")
        $null = $body.Append("Content-Type: application/json;odata=verbose`r`n`r`n")
        $null = $body.Append("$($workItem.Payload)`r`n")
        $null = $body.Append("--$changesetBoundary--`r`n")
    }

    $null = $body.Append("--$BatchBoundary--`r`n")
    return $body.ToString()
}

function Get-BatchResponseHttpParts {
    <#
        Generalized parser for a $batch response that may contain a mix of:
          - changesets wrapped in their own nested multipart section (one per item, each
            with its own distinct boundary token - this is what New-SharePointBatchBody produces)
          - flat HTTP responses with no nested wrapping (some servers do this for single-request changesets)

        Returns HTTP response chunks in the same order requests were sent, since
        SharePoint preserves request order in both batch and changeset responses.
    #>
    param (
        [Parameter(Mandatory = $true)] [string]$Content,
        [Parameter(Mandatory = $true)] [string]$OuterBoundary
    )

    $outerParts = $Content -split "--$([regex]::Escape($OuterBoundary))(?:--)?\r?\n"
    $httpParts = @()

    foreach ($part in $outerParts) {
        if ([string]::IsNullOrWhiteSpace($part)) { continue }

        $hasDirectHttp = $part -match 'HTTP/\d(?:\.\d)?\s+\d{3}'
        $nestedBoundaryMatch = [regex]::Match($part, 'boundary=(?<b>[^\r\n;]+)')

        if ($nestedBoundaryMatch.Success) {
            # This outer part wraps a nested changeset - split again to reach the real HTTP response
            $nestedBoundary = $nestedBoundaryMatch.Groups['b'].Value.Trim('"')
            $nestedParts = $part -split "--$([regex]::Escape($nestedBoundary))(?:--)?\r?\n" |
            Where-Object { $_ -match 'HTTP/\d(?:\.\d)?\s+\d{3}' }
            $httpParts += $nestedParts
        }
        elseif ($hasDirectHttp) {
            $httpParts += $part
        }
        # else: boilerplate/empty segment between boundaries - skip
    }

    return $httpParts
}

function Invoke-SharePointUpdateBatch {
    <#
        Sends one $batch request (up to 100 items, each in its own changeset)
        and returns a per-item result: WorkItem, StatusCode, Succeeded, Errors.
    #>
    param (
        [Parameter(Mandatory = $true)] [string]$siteUrl,
        [Parameter(Mandatory = $true)] [string]$libraryGUID,
        [Parameter(Mandatory = $true)] [hashtable]$headers,
        [Parameter(Mandatory = $true)] [object[]]$workItems
    )

    if ($workItems.Count -gt 100) {
        throw "SharePoint REST batches cannot contain more than 100 requests"
    }

    $batchBoundary = "batch_$([Guid]::NewGuid().ToString('N'))"
    $body = New-SharePointBatchBody -siteUrl $siteUrl -libraryGUID $libraryGUID -BatchBoundary $batchBoundary -WorkItems $workItems

    $batchHeaders = @{
        Authorization = $headers.Authorization
        Accept        = "application/json;odata=verbose"
    }

    # Let outer-call failures (401, 429, 503, network errors) bubble up as exceptions -
    # the caller (Invoke-SharePointBulkUpdate) is responsible for retry/backoff on those.
    $response = Invoke-WebRequest -Uri "$siteUrl/_api/`$batch" -Method Post `
        -Headers $batchHeaders -Body $body `
        -ContentType "multipart/mixed; boundary=$batchBoundary" -UseBasicParsing

    # Invoke-WebRequest only auto-decodes .Content to a string for recognized text
    # content types (text/*, application/json, etc). "multipart/mixed" isn't on that
    # list, so .Content comes back as a raw byte[] - decode it explicitly.
    $responseContent = $response.Content
    if ($responseContent -is [byte[]]) {
        $responseContent = [System.Text.Encoding]::UTF8.GetString($responseContent)
    }

    # --- Parse the multipart response using the ACTUAL boundary strings SharePoint
    # --- returns, rather than guessing with a generic regex. This is more robust
    # --- because the server is free to generate its own boundary tokens.

    $responseContentType = $response.Headers['Content-Type']
    if ($responseContentType -is [array]) { $responseContentType = $responseContentType[0] }

    $outerBoundaryMatch = [regex]::Match($responseContentType, 'boundary=(?<b>[^;]+)')
    if (-not $outerBoundaryMatch.Success) {
        throw "Could not determine outer batch boundary from response Content-Type: $responseContentType"
    }
    $outerBoundary = $outerBoundaryMatch.Groups['b'].Value.Trim('"')

    $itemParts = Get-BatchResponseHttpParts -Content $responseContent -OuterBoundary $outerBoundary

    if ($itemParts.Count -ne $workItems.Count) {
        Write-Warning "Expected $($workItems.Count) responses but parsed $($itemParts.Count). Results below are matched by order and may be misaligned - treat with caution."
    }

    $results = @()
    for ($index = 0; $index -lt $workItems.Count; $index++) {
        if ($index -ge $itemParts.Count) {
            $results += [PSCustomObject]@{
                WorkItem   = $workItems[$index]
                StatusCode = $null
                Succeeded  = $false
                Errors     = @("No matching response was returned for this item")
            }
            continue
        }

        $part = $itemParts[$index]
        $statusMatch = [regex]::Match($part, 'HTTP/\d(?:\.\d)?\s+(?<status>\d{3})')
        $statusCode = [int]$statusMatch.Groups['status'].Value

        $jsonStart = $part.IndexOf('{')
        $jsonEnd = $part.LastIndexOf('}')

        $errors = @()
        if ($jsonStart -ge 0 -and $jsonEnd -gt $jsonStart) {
            $jsonBody = $part.Substring($jsonStart, $jsonEnd - $jsonStart + 1)
            $errors = @(Get-SharePointBatchPartErrors -JsonBody $jsonBody)
        }

        if ($errors.Count -eq 0 -and ($statusCode -lt 200 -or $statusCode -ge 300)) {
            $errors = @("SharePoint batch request returned HTTP $statusCode")
        }

        $results += [PSCustomObject]@{
            WorkItem   = $workItems[$index]
            StatusCode = $statusCode
            Succeeded  = $errors.Count -eq 0
            Errors     = $errors
        }
    }

    return $results
}

function Invoke-UpdateItemWithRetry {
    <#
        Falls back to a single (non-batch) ValidateUpdateListItem() call for one item that
        failed as part of a batch, retrying transient failures (429/503) with backoff.
        Relies on $script:BenignUpdateExceptionFields to ignore audit-stamp field exceptions
        that SharePoint sometimes flags even though the real target field was applied.
    #>
    param (
        [Parameter(Mandatory = $true)] [string]$siteUrl,
        [Parameter(Mandatory = $true)] [string]$libraryGUID,
        [Parameter(Mandatory = $true)] [hashtable]$headers,
        [Parameter(Mandatory = $true)] [object]$workItem,
        [int]$MaxRetries = 3
    )

    $itemUrl = "$siteUrl/_api/web/lists(guid'$libraryGUID')/Items($($workItem.Item.ItemId))/ValidateUpdateListItem()"
    $itemHeaders = @{
        Authorization  = $headers.Authorization
        Accept         = "application/json;odata=verbose"
        "Content-Type" = "application/json;odata=verbose"
    }

    $lastErrors = @()
    $attempt = 0
    while ($attempt -lt $MaxRetries) {
        $attempt++
        try {
            $response = Invoke-WebRequest -Uri $itemUrl -Method Post -Headers $itemHeaders -Body $workItem.Payload -UseBasicParsing
            $responseContent = $response.Content
            if ($responseContent -is [byte[]]) {
                $responseContent = [System.Text.Encoding]::UTF8.GetString($responseContent)
            }

            $errors = @(Get-SharePointBatchPartErrors -JsonBody $responseContent)
            $errors = @($errors | Where-Object {
                    $fieldError = $_
                    -not ($script:BenignUpdateExceptionFields | Where-Object { $fieldError -like "Field '$_':*" })
                })

            if ($errors.Count -eq 0) {
                return [PSCustomObject]@{ Succeeded = $true; Errors = @() }
            }
            $lastErrors = $errors
        }
        catch {
            $statusCode = $null
            $webResponse = $_.Exception.Response
            if ($webResponse) {
                try { $statusCode = [int]$webResponse.StatusCode } catch { $statusCode = $null }
            }
            $lastErrors = @("HTTP $statusCode`: $($_.Exception.Message)")

            if ($statusCode -in 429, 503) {
                $retryAfter = 5
                if ($webResponse -and $webResponse.Headers) {
                    try {
                        $retryAfterHeader = $webResponse.Headers['Retry-After']
                        if ($retryAfterHeader) { $retryAfter = [int]$retryAfterHeader }
                    }
                    catch {}
                }
                Start-Sleep -Seconds $retryAfter
                $attempt--   # throttling doesn't count against MaxRetries
                continue
            }
        }

        if ($attempt -lt $MaxRetries) {
            Start-Sleep -Seconds ([Math]::Pow(2, $attempt) + (Get-Random -Minimum 0 -Maximum 2))
        }
    }

    return [PSCustomObject]@{ Succeeded = $false; Errors = $lastErrors }
}

function Invoke-SharePointBulkUpdate {
    <#
        Driver for large-scale runs (millions of items, batches of 100):
          - Chunks items into batches
          - Retries only the items that failed within a batch, with exponential backoff + jitter
          - Handles outer-call throttling (429/503, respecting Retry-After) and token expiry (401)
          - Streams every attempt to a CSV log (does not hold results in memory)
          - Writes permanently-failed items (after MaxRetries) to a separate CSV for manual review
          - Writes a checkpoint file after every batch so an interrupted run can be resumed

        .PARAMETER GetAuthHeader
            Scriptblock returning @{ Authorization = "Bearer <token>" }. Called fresh
            per batch attempt so long runs survive token expiry without extra plumbing.

        .PARAMETER AllItems
            Full ordered collection of items to update. For true million-item scale, pass
            this in from a paged/streamed source rather than loading everything into memory
            at once - see the notes below the function.
    #>
    param (
        [Parameter(Mandatory = $true)] [string]$siteUrl,
        [Parameter(Mandatory = $true)] [string]$libraryGUID,
        [Parameter(Mandatory = $true)] [scriptblock]$GetAuthHeader,
        [Parameter(Mandatory = $true)] [object[]]$AllItems,
        [int]$BatchSize = 1000,
        [int]$MaxRetries = 3,
        [string]$LogPath = ".\batch_update_log.csv",
        [string]$FailedLogPath = ".\permanently_failed_items.csv",
        [string]$CheckpointPath = ".\batch_update_checkpoint.txt"
    )

    $totalItems = $AllItems.Count
    $startBatchIndex = 0

    if (Test-Path $CheckpointPath) {
        $savedIndex = Get-Content $CheckpointPath -Raw
        if ($savedIndex -match '^\d+$') {
            $startBatchIndex = [int]$savedIndex
            Write-LogINFO "Resuming from checkpoint: batch $startBatchIndex"
        }
    }

    $batchNumber = 0
    for ($start = 0; $start -lt $totalItems; $start += $BatchSize) {
        $batchNumber++
        if ($batchNumber -le $startBatchIndex) { continue }   # skip already-completed batches on resume

        $end = [Math]::Min($start + $BatchSize - 1, $totalItems - 1)
        $pendingItems = $AllItems[$start..$end]
        $attempt = 0

        while ($pendingItems.Count -gt 0 -and $attempt -lt $MaxRetries) {
            $attempt++
            $headers = & $GetAuthHeader
            $batchResults = $null

            try {
                $batchResults = Invoke-SharePointUpdateBatch -siteUrl $siteUrl -libraryGUID $libraryGUID -headers $headers -workItems $pendingItems
            }
            catch {
                $statusCode = $null
                $webResponse = $_.Exception.Response
                if ($webResponse) {
                    try { $statusCode = [int]$webResponse.StatusCode } catch { $statusCode = $null }
                }

                if ($statusCode -in 429, 503) {
                    $retryAfter = 5
                    $retryAfterHeader = $null
                    if ($webResponse -and $webResponse.Headers) {
                        try { $retryAfterHeader = $webResponse.Headers['Retry-After'] } catch { $retryAfterHeader = $null }
                    }
                    if ($retryAfterHeader) { $retryAfter = [int]$retryAfterHeader }
                    Write-Warning "Batch $batchNumber throttled (HTTP $statusCode). Waiting $retryAfter s before retry."
                    Start-Sleep -Seconds $retryAfter
                    $attempt--   # throttling doesn't count against MaxRetries
                    continue
                }
                elseif ($statusCode -eq 401) {
                    Write-Warning "Batch $batchNumber`: auth token rejected. Refreshing and retrying."
                    $attempt--   # token refresh doesn't count against MaxRetries either
                    continue
                }
                else {
                    # Whole batch call failed for an unexpected reason - log every pending item
                    # as failed for this attempt, then let the outer while loop decide whether to retry.
                    foreach ($item in $pendingItems) {
                        [PSCustomObject]@{
                            Timestamp   = (Get-Date -Format 'o')
                            BatchNumber = $batchNumber
                            Attempt     = $attempt
                            ItemId      = $item.Item.ItemId
                            StatusCode  = $statusCode
                            Succeeded   = $false
                            Errors      = $_.Exception.Message
                        } | Export-Csv -Path $LogPath -NoTypeInformation -Append -Encoding UTF8
                    }
                    Start-Sleep -Seconds ([Math]::Pow(2, $attempt) + (Get-Random -Minimum 0 -Maximum 2))
                    continue
                }
            }

            foreach ($result in $batchResults) {
                [PSCustomObject]@{
                    Timestamp   = (Get-Date -Format 'o')
                    BatchNumber = $batchNumber
                    Attempt     = $attempt
                    ItemId      = $result.WorkItem.Item.ItemId
                    StatusCode  = $result.StatusCode
                    Succeeded   = $result.Succeeded
                    Errors      = ($result.Errors -join ' | ')
                } | Export-Csv -Path $LogPath -NoTypeInformation -Append -Encoding UTF8
            }

            $pendingItems = @($batchResults | Where-Object { -not $_.Succeeded } | ForEach-Object { $_.WorkItem })

            if ($pendingItems.Count -gt 0 -and $attempt -lt $MaxRetries) {
                $backoff = [Math]::Pow(2, $attempt) * 2 + (Get-Random -Minimum 0 -Maximum 2)
                Write-Warning "Batch $batchNumber`: $($pendingItems.Count) item(s) failed on attempt $attempt. Retrying after $backoff s."
                Start-Sleep -Seconds $backoff
            }
        }

        if ($pendingItems.Count -gt 0) {
            foreach ($item in $pendingItems) {
                [PSCustomObject]@{
                    Timestamp   = (Get-Date -Format 'o')
                    BatchNumber = $batchNumber
                    ItemId      = $item.Item.ItemId
                    Note        = "Exhausted $MaxRetries retries - needs manual review"
                } | Export-Csv -Path $FailedLogPath -NoTypeInformation -Append -Encoding UTF8
            }
            Write-Warning "Batch $batchNumber`: $($pendingItems.Count) item(s) permanently failed after $MaxRetries attempts."
        }

        Set-Content -Path $CheckpointPath -Value $batchNumber

        if ($batchNumber % 100 -eq 0) {
            Write-LogINFO "Progress: $($end + 1) / $totalItems items processed ($batchNumber batches)"
        }
    }

    Remove-Item $CheckpointPath -ErrorAction SilentlyContinue
    Write-LogINFO "Bulk update complete. Full log: $LogPath | Permanent failures: $FailedLogPath"
}

# Runs one $batch REST call (with per-item retry-on-failure) inside a runspace.
# Kept as a standalone scriptblock so it can be shipped into worker runspaces via
# InitialSessionState below - it only calls the batch/retry helpers, all of which
# are self-contained (no closures over the parent scope needed).
$processUpdateBatch = {
    param (
        [Parameter(Mandatory = $true)] [string]$siteUrl,
        [Parameter(Mandatory = $true)] [string]$libraryGUID,
        [Parameter(Mandatory = $true)] [hashtable]$headers,
        [Parameter(Mandatory = $true)] [object[]]$workItems,
        [Parameter(Mandatory = $true)] [int]$batchNumber
    )

    $script:BenignUpdateExceptionFields = @('Editor', 'Modified')

    try {
        $batchResults = @(Invoke-SharePointUpdateBatch -siteUrl $siteUrl -libraryGUID $libraryGUID -headers $headers -workItems $workItems)
    }
    catch {
        $batchError = $_.Exception.Message
        $batchResults = @($workItems | ForEach-Object {
                [PSCustomObject]@{ WorkItem = $_; Succeeded = $false; Errors = @($batchError) }
            })
    }

    $finalResults = @()
    foreach ($batchResult in $batchResults) {
        if ($batchResult.Succeeded) {
            $finalResults += [PSCustomObject]@{ WorkItem = $batchResult.WorkItem; Succeeded = $true; Errors = @() }
            continue
        }

        $retryResult = Invoke-UpdateItemWithRetry -siteUrl $siteUrl -libraryGUID $libraryGUID -headers $headers -workItem $batchResult.WorkItem
        $finalResults += [PSCustomObject]@{ WorkItem = $batchResult.WorkItem; Succeeded = $retryResult.Succeeded; Errors = $retryResult.Errors }
    }

    return [PSCustomObject]@{ BatchNumber = $batchNumber; Results = $finalResults }
}

function updateItems {
    param (
        [Parameter(Mandatory = $true)] [string]$siteUrl,
        [Parameter(Mandatory = $true)] [string]$libraryGUID,
        [Parameter(Mandatory = $true)] [string]$libraryTitle,
        [Parameter(Mandatory = $true)] [psobject] $contentTypesConfig,
        [Parameter(Mandatory = $true)] [psobject] $documentClassTerms,
        [Parameter(Mandatory = $true)] [psobject] $updateConfig,
        [Parameter(Mandatory = $true)] [string] $language,
        [Parameter(Mandatory = $true)] [int] $timeZoneOffset,
        [Parameter(Mandatory = $true)] [object] $context,
        # Azure Automation sandboxes are memory-constrained regardless of reported CPU count -
        # too high a default here risks "Thread failed to start (OutOfMemoryException)" once
        # combined with a large in-memory item page (up to 5000 items) plus per-runspace overhead.
        [Parameter(Mandatory = $false)] [int] $maxParallelThreads = 3,
        [Parameter(Mandatory = $false)] [int] $StartId = 0,
        [Parameter(Mandatory = $false)] [int] $EndId = 0,
        [Parameter(Mandatory = $false)] [int] $BatchSize = 3000,
        # Hard ceiling on our batch jobs running at once. Each child loads SPO Management Shell +
        # CSOM + MSAL in its own sandbox, so this is a memory ceiling as much as a rate limit.
        [Parameter(Mandatory = $false)] [int] $MaxConcurrentJobs = 30
    )

    # start measuring time
    $startTime = Get-Date

    if ($StartId -eq 0 -and $EndId -eq 0 -and (Get-Command Get-AutomationVariable -ErrorAction SilentlyContinue)) {
        $webhookUrl = Get-UpdateItemsAutomationVariable -Name 'UpdateItemsWebhookUrl'
        Write-LogINFO "Retrieved UpdateItems webhook URL: $webhookUrl"
        if (-not [string]::IsNullOrWhiteSpace($webhookUrl)) {
            $dispatchSummary = Invoke-UpdateItemsWebhookBatches `
                -WebhookUrl $webhookUrl `
                -SiteUrl $siteUrl `
                -LibraryGUID $libraryGUID `
                -LibraryTitle $libraryTitle `
                -BatchSize $BatchSize `
                -MaxConcurrentJobs $MaxConcurrentJobs `
                -Context $context `
                -KeepBatchReports

            # The per-item ItemChanges records stay in the child jobs on purpose: shipping them
            # back would mean moving millions of rows through job output. Counts come back so the
            # master job can report real totals, and WebhookDispatch signals to callers that
            # per-item detail is not available for report generation from here.
            return @{
                Exceptions      = @()
                ItemChanges     = @()
                BeforeCtCounts  = @{}
                WebhookDispatch = $dispatchSummary
                UpdatedCount    = if ($dispatchSummary) { $dispatchSummary.UpdatedCount } else { 0 }
                FailedCount     = if ($dispatchSummary) { $dispatchSummary.FailedCount } else { 0 }
            }
        }
    }

    $accessToken = Get-AzureADAccessToken `
        -tenantId $context.AuthState.TenantId `
        -clientId $context.AuthState.ClientId `
        -clientSecret $context.AuthState.ClientSecret `
        -certificate $context.AuthState.Certificate `
        -resourceUrl $context.AuthState.SiteUrl

    $headers = @{
        Authorization = "Bearer $accessToken"
        Accept        = "application/json;odata=verbose"
    }

    $libraryContentTypes = getLibraryContentTypes -siteUrl $siteUrl -libraryGUID $libraryGUID -headers $headers

    $wantedContentTypePrefixes = @($contentTypesConfig.PSObject.Properties.Name | Where-Object { $_ -ne "0x0101" })
    $contentTypeNameById = @{}
    foreach ($libraryContentType in $libraryContentTypes) {
        $contentTypeNameById[$libraryContentType.Id.StringValue] = $libraryContentType.Name
    }

    $targetContentTypeIdByLegacyName = @{}
    foreach ($contentTypeConfig in $updateConfig.ContentTypes) {
        $targetContentTypeId = getListContentTypeByParentId `
            -ParentId $contentTypeConfig.Key `
            -LibraryContentTypes $libraryContentTypes
        if ($null -eq $targetContentTypeId) {
            continue
        }

        $legacyNames = @($contentTypeConfig.LegacyNames) + @($contentTypesConfig.$($contentTypeConfig.Key).Name.$language)
        foreach ($legacyName in $legacyNames) {
            if ([string]::IsNullOrEmpty($legacyName)) {
                continue
            }

            $renamedLegacyName = "$legacyName`_Legacy"
            if (-not $targetContentTypeIdByLegacyName.ContainsKey($renamedLegacyName)) {
                $targetContentTypeIdByLegacyName[$renamedLegacyName] = $targetContentTypeId
            }
        }
    }

    $exceptions = [System.Collections.Generic.List[object]]::new()
    $itemChanges = [System.Collections.Generic.List[object]]::new()
    $sep = [char]0
    $beforeCtCounts = @{}
    $updatingItemsCount = 0
    $updatedItemsCount = 0
    $lastTokenRefresh = Get-Date

    # SharePoint supports up to 5000 rows for this ordered REST query.
    $pageSize = 5000
    $updateBatchSize = 100
    $choiceFieldsConfigPath = "$global:CurrDir\configs\choice-fields-to-map.json"
    $choiceFields = getChoiceFieldsToMap -configPath $choiceFieldsConfigPath
    $fieldExists = checkFieldsExistence -siteUrl $siteUrl -libraryGUID $libraryGUID -headers $headers -choiceFields $choiceFields
    $choiceFields = @($fieldExists.ChoiceFields)
    $fieldsQuery = getFieldsQuery -fieldExists $fieldExists -choiceFields $choiceFields

    $idFilter = ""
    if ($StartId -gt 0 -or $EndId -gt 0) {
        $filterParts = [System.Collections.Generic.List[string]]::new()
        if ($StartId -gt 0) { $filterParts.Add("ID ge $StartId") }
        if ($EndId -gt 0) { $filterParts.Add("ID le $EndId") }
        $idFilter = "&`$filter=" + ($filterParts -join " and ")
    }
    $nextUrl = "$siteUrl/_api/web/lists(guid'$libraryGUID')/items?`$select=$fieldsQuery&`$expand=ContentType,File/Name&`$orderby=ID&`$top=$pageSize$idFilter"

    # Load columns.json config once
    $columnsConfigPath = "$global:CurrDir\configs\columns.json"
    $columnsConfig = Get-Content $columnsConfigPath -Raw | ConvertFrom-Json

    $targetChoiceValuesByField = @{}
    $choiceValueMapByField = @{}
    foreach ($field in $choiceFields) {
        $choicesObj = $columnsConfig.$field.Choices
        if ($null -eq $choicesObj) {
            continue
        }

        $targetChoices = @($choicesObj.$language)
        $targetChoiceValues = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($targetChoice in $targetChoices) {
            if ($null -ne $targetChoice) {
                [void]$targetChoiceValues.Add([string]$targetChoice)
            }
        }

        $choiceValueMap = [System.Collections.Generic.Dictionary[string, string]]::new([System.StringComparer]::Ordinal)
        foreach ($sourceLanguage in $choicesObj.PSObject.Properties.Name) {
            $sourceChoices = @($choicesObj.$sourceLanguage)
            for ($choiceIndex = 0; $choiceIndex -lt $sourceChoices.Count -and $choiceIndex -lt $targetChoices.Count; $choiceIndex++) {
                $sourceChoice = $sourceChoices[$choiceIndex]
                $targetChoice = $targetChoices[$choiceIndex]
                if ($null -ne $sourceChoice -and $null -ne $targetChoice -and -not $choiceValueMap.ContainsKey([string]$sourceChoice)) {
                    $choiceValueMap.Add([string]$sourceChoice, [string]$targetChoice)
                }
            }
        }

        $targetChoiceValuesByField[$field] = $targetChoiceValues
        $choiceValueMapByField[$field] = $choiceValueMap
    }

    if ($maxParallelThreads -le 0) {
        $maxParallelThreads = [Math]::Min([int]$env:NUMBER_OF_PROCESSORS, 3)
    }

    $workerFunctionNames = @(
        'New-SharePointBatchBody',
        'Get-BatchResponseHttpParts',
        'Get-SharePointBatchPartErrors',
        'Invoke-SharePointUpdateBatch',
        'Invoke-UpdateItemWithRetry'
    )
    $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    foreach ($fnName in $workerFunctionNames) {
        $fnCommand = Get-Command -Name $fnName -CommandType Function
        $iss.Commands.Add([System.Management.Automation.Runspaces.SessionStateFunctionEntry]::new($fnName, $fnCommand.Definition))
    }
    # Never hand $Host to the pool - see the note on the QC pool in legacy-update-util.ps1.
    # The (iss) overload gives the pool a private default host instead of the Azure Automation
    # sandbox host, so a worker thread can't take down the job's log relay. min/max are widened
    # after construction because that overload fixes both at 1.
    $pool = [RunspaceFactory]::CreateRunspacePool($iss)
    $null = $pool.SetMaxRunspaces($maxParallelThreads)
    $null = $pool.SetMinRunspaces(1)
    $pool.ApartmentState = "MTA"
    $pool.Open()

    $totalItemsFetched = 0
    $pendingUpdates = [System.Collections.Generic.List[object]]::new()
    $inFlight = @()
    $totalBatches = 0
    $completedBatchesCount = 0
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    $receiveCompletedBatches = {
        param([bool]$WaitForOne)

        do {
            $completed = @($inFlight | Where-Object { $_.Status.IsCompleted })
            if ($WaitForOne -and $completed.Count -eq 0 -and $inFlight.Count -gt 0) {
                Start-Sleep -Milliseconds 100
            }
        } while ($WaitForOne -and $completed.Count -eq 0 -and $inFlight.Count -gt 0)

        foreach ($finishedRunspace in $completed) {
            try {
                $output = $finishedRunspace.Pipe.EndInvoke($finishedRunspace.Status)
                foreach ($batchOutput in $output) {
                    foreach ($result in $batchOutput.Results) {
                        if ($result.Succeeded) {
                            $itemChanges.Add($result.WorkItem.ChangeRecord)
                            $updatedItemsCount++
                            continue
                        }

                        $failedItem = $result.WorkItem.Item
                        $exceptions.Add([PSCustomObject]@{
                            ItemId   = $failedItem.ItemId
                            Errors   = $result.Errors
                            FileName = $failedItem.File.Name
                            Path     = $failedItem.File.ServerRelativeUrl
                            Url      = $failedItem.File.LinkingUri
                        })
                    }
                }
            }
            catch {
                Write-LogERR "Batch $($finishedRunspace.BatchNumber) failed: $($_.Exception.Message)"
            }
            finally {
                $finishedRunspace.Pipe.Dispose()
            }

            $completedBatchesCount++
            Write-LogINFO "Progress: Batch $completedBatchesCount completed; $totalBatches dispatched. Total successfully updated items so far: $updatedItemsCount."
        }

        # Remove only the runspaces received above. Re-checking IsCompleted here would also drop
        # any batch that finished while the loop was running, without its results ever being
        # read - the items are updated in SharePoint but missing from counts and reports.
        $receivedBatchNumbers = @($completed | ForEach-Object { $_.BatchNumber })
        $inFlight = @($inFlight | Where-Object { $receivedBatchNumbers -notcontains $_.BatchNumber })
    }

    $dispatchUpdateBatch = {
        param([object[]]$WorkItems)

        while ($inFlight.Count -ge $maxParallelThreads) {
            . $receiveCompletedBatches -WaitForOne $true
        }

        if (((Get-Date) - $lastTokenRefresh).TotalMinutes -ge 45) {
            $accessToken = Get-AzureADAccessToken `
                -tenantId $context.AuthState.TenantId `
                -clientId $context.AuthState.ClientId `
                -clientSecret $context.AuthState.ClientSecret `
                -certificate $context.AuthState.Certificate `
                -resourceUrl $context.AuthState.SiteUrl
            $headers.Authorization = "Bearer $accessToken"
            $lastTokenRefresh = Get-Date
            Write-LogINFO "Refreshed access token during parallel batch processing."
        }

        $totalBatches++
        $headersCopy = @{ Authorization = $headers.Authorization; Accept = $headers.Accept }
        try {
            $runspace = [PowerShell]::Create()
            $runspace.RunspacePool = $pool
            $null = $runspace.AddScript($processUpdateBatch).
                AddArgument($siteUrl).
                AddArgument($libraryGUID).
                AddArgument($headersCopy).
                AddArgument($WorkItems).
                AddArgument($totalBatches)

            $inFlight += [PSCustomObject]@{
                Pipe        = $runspace
                Status      = $runspace.BeginInvoke()
                BatchNumber = $totalBatches
            }
        }
        catch {
            # Thread creation can fail under sandbox memory pressure (e.g. "Thread failed to
            # start (OutOfMemoryException)"). Drain all in-flight batches first to free up
            # memory/thread slots, permanently reduce future concurrency, then process this
            # batch synchronously on the main thread instead of losing it / crashing the job.
            Write-LogWARN "Failed to start a new batch runspace (batch $totalBatches): $($_.Exception.Message). Draining in-flight batches and falling back to synchronous processing."
            while ($inFlight.Count -gt 0) {
                . $receiveCompletedBatches -WaitForOne $true
            }
            if ($maxParallelThreads -gt 1) {
                $maxParallelThreads--
                Write-LogWARN "Reduced parallel batch threads to $maxParallelThreads to relieve memory pressure."
            }
            [System.GC]::Collect()

            $batchOutput = & $processUpdateBatch $siteUrl $libraryGUID $headersCopy $WorkItems $totalBatches
            foreach ($result in $batchOutput.Results) {
                if ($result.Succeeded) {
                    $itemChanges.Add($result.WorkItem.ChangeRecord)
                    $updatedItemsCount++
                    continue
                }

                $failedItem = $result.WorkItem.Item
                $exceptions.Add([PSCustomObject]@{
                    ItemId   = $failedItem.ItemId
                    Errors   = $result.Errors
                    FileName = $failedItem.File.Name
                    Path     = $failedItem.File.ServerRelativeUrl
                    Url      = $failedItem.File.LinkingUri
                })
            }
            $completedBatchesCount++
            Write-LogINFO "Progress: Batch $completedBatchesCount completed (synchronous fallback); $totalBatches dispatched. Total successfully updated items so far: $updatedItemsCount."
        }
    }

    try {
        do {
        if (((Get-Date) - $lastTokenRefresh).TotalMinutes -ge 45) {
            $accessToken = Get-AzureADAccessToken `
                -tenantId $context.AuthState.TenantId `
                -clientId $context.AuthState.ClientId `
                -clientSecret $context.AuthState.ClientSecret `
                -certificate $context.AuthState.Certificate `
                -resourceUrl $context.AuthState.SiteUrl
            $headers.Authorization = "Bearer $accessToken"
            $lastTokenRefresh = Get-Date
            Write-LogINFO "Refreshed access token during long-running library update."
        }

        $batchItems = getListItemsBatch -nextUrl $nextUrl -headers $headers
        $nextUrl = $batchItems.NextUrl
        $totalItemsFetched += $batchItems.Items.Count
        Write-LogINFO "Fetched page with $($batchItems.Items.Count) items (total fetched: $totalItemsFetched)."

        foreach ($item in $batchItems.Items) {
            $wantedContentTypeId = $null
            $needsContentTypeUpdate = $false
            $hasWantedContentType = $false
            foreach ($contentTypePrefix in $wantedContentTypePrefixes) {
                if ($item.ContentTypeId -like "$contentTypePrefix*") {
                    $hasWantedContentType = $true
                    break
                }
            }
            if (-not $hasWantedContentType) {
                $wantedContentTypeId = $targetContentTypeIdByLegacyName[$item.ContentType.Name]
                if ($null -ne $wantedContentTypeId) {
                    $needsContentTypeUpdate = $true
                }
            }

            # Check if any choice field needs mapping
            $needsChoiceUpdate = $false
            $mappedValuesArray = @()
            foreach ($field in $choiceFields) {
                if ($null -ne $columnsConfig -and $null -ne $item.$field) {
                    $mappedValue = $null
                    $oldValue = $item.$field
                    if ($oldValue -and $choiceValueMapByField.ContainsKey($field)) {
                        $targetChoiceValues = $targetChoiceValuesByField[$field]
                        $choiceValueMap = $choiceValueMapByField[$field]
                        if (-not $targetChoiceValues.Contains([string]$oldValue) -and $choiceValueMap.ContainsKey([string]$oldValue)) {
                            $mappedValue = $choiceValueMap[[string]$oldValue]
                        }
                    }
                    if ($null -ne $mappedValue -and $mappedValue -ne $item.$field) {
                        $needsChoiceUpdate = $true
                        $mappedValuesArray += [PSCustomObject]@{
                            Field = $field
                            Value = $mappedValue
                        }
                    }
                }
            }

            if ($item.FileSystemObjectType -eq 0) {
                $ctKey = "$siteUrl$sep$libraryTitle$sep$($item.ContentTypeId)"
                if (-not $beforeCtCounts.ContainsKey($ctKey)) {
                    $beforeCtCounts[$ctKey] = [PSCustomObject]@{
                        SiteUrl         = $siteUrl
                        LibraryName     = $libraryTitle
                        ContentTypeId   = $item.ContentTypeId
                        ContentTypeName = $item.ContentType.Name
                        Count           = 0
                    }
                }
                $beforeCtCounts[$ctKey].Count++
            }

            # Only skip if neither content type nor choice field needs update
            if (-not $needsContentTypeUpdate -and -not $needsChoiceUpdate) {
                continue
            }

            if (-not $needsContentTypeUpdate) {
                # If content type is not being updated, set wantedContentTypeId to current
                $wantedContentTypeId = $item.ContentTypeId
            }

            $updatingItemsCount++
            $changeRecord = [PSCustomObject]@{
                SiteUrl               = $siteUrl
                LibraryId             = $libraryGUID
                LibraryName           = $libraryTitle
                ItemId                = $item.ItemId
                FileName              = $item.File.Name
                FilePath              = $item.File.ServerRelativeUrl
                BeforeContentTypeId   = $item.ContentTypeId
                BeforeContentTypeName = $item.ContentType.Name
                AfterContentTypeId    = $wantedContentTypeId
                AfterContentTypeName  = if ($contentTypeNameById.ContainsKey($wantedContentTypeId)) { $contentTypeNameById[$wantedContentTypeId] } else { $wantedContentTypeId }
                MigrationDate         = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            }
            try {
                $pendingUpdates.Add([PSCustomObject]@{
                    Item         = $item
                    Payload      = New-UpdateItemPayload -item $item `
                        -wantedContentTypeId $wantedContentTypeId `
                        -documentClassTerms $documentClassTerms `
                        -timeZoneOffset $timeZoneOffset `
                        -mappedValuesArray $mappedValuesArray
                    ChangeRecord = $changeRecord
                })
            }
            catch {
                $exceptions.Add([PSCustomObject]@{
                    ItemId   = $item.ItemId
                    Errors   = @("Could not prepare update: $($_.Exception.Message)")
                    FileName = $item.File.Name
                    Path     = $item.File.ServerRelativeUrl
                    Url      = $item.File.LinkingUri
                })
            }
        }

            $fullBatchItemCount = [Math]::Floor($pendingUpdates.Count / $updateBatchSize) * $updateBatchSize
            for ($offset = 0; $offset -lt $fullBatchItemCount; $offset += $updateBatchSize) {
                $lastIndex = $offset + $updateBatchSize - 1
                $workItems = @($pendingUpdates[$offset..$lastIndex])
                . $dispatchUpdateBatch -WorkItems $workItems
            }

            $remainingUpdates = [System.Collections.Generic.List[object]]::new()
            for ($index = $fullBatchItemCount; $index -lt $pendingUpdates.Count; $index++) {
                $remainingUpdates.Add($pendingUpdates[$index])
            }
            $pendingUpdates = $remainingUpdates
            . $receiveCompletedBatches -WaitForOne $false
        } while ($null -ne $nextUrl)

        if ($pendingUpdates.Count -gt 0) {
            . $dispatchUpdateBatch -WorkItems $pendingUpdates.ToArray()
            $pendingUpdates.Clear()
        }

        while ($inFlight.Count -gt 0) {
            . $receiveCompletedBatches -WaitForOne $true
        }
    }
    finally {
        $pool.Close()
        $pool.Dispose()
    }

    $sw.Stop()
    Write-LogINFO "Item scanning and batch processing took $($sw.Elapsed.TotalSeconds)s for $updatingItemsCount items in $totalBatches batches"
    Write-LogINFO "Batch processing completed. Total successfully updated items: $updatedItemsCount."

    Write-LogINFO "Update-able items count: $updatingItemsCount"
    Write-LogINFO "Successfully updated items count: $updatedItemsCount"
    if ($updatedItemsCount -ne $updatingItemsCount) {
        Write-LogERR "$($updatingItemsCount - $updatedItemsCount) item(s) were not updated after individual retries."
    }
    $endTime = Get-Date
    $duration = $endTime - $startTime
    Write-LogINFO "Total time taken: $($duration.Hours) hours, $($duration.Minutes) minutes, $($duration.Seconds) seconds updating library $($libraryGUID)"
    return @{
        Exceptions     = $exceptions.ToArray()
        ItemChanges    = $itemChanges.ToArray()
        BeforeCtCounts = $beforeCtCounts
    }
}

function checkFieldsExistence {
    param (
        [Parameter(Mandatory = $true)]
        [string]$siteUrl,

        [Parameter(Mandatory = $true)]
        [string]$libraryGUID,

        [Parameter(Mandatory = $true)]
        [hashtable]$headers,

        [Parameter(Mandatory = $false)]
        [array]$choiceFields = @()
    )

    $fieldExists = @{
        DocumentClass = $false
        OData__ExtendedDescription = $false
        ChoiceFields = @()
    }

    $fieldNames = @('DocumentClass', 'OData__ExtendedDescription') + @($choiceFields | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $fieldNames = @($fieldNames | Select-Object -Unique)
    $filterParts = @($fieldNames | ForEach-Object { "InternalName eq '$($_.Replace("'", "''"))'" })
    $filterExpression = $filterParts -join ') or ('
    $fieldCheckUrl = "$siteUrl/_api/web/lists(guid'$libraryGUID')/fields?`$filter=(($filterExpression))"
    try {
        $fieldCheckResponse = Invoke-RestMethod -Uri $fieldCheckUrl -Method Get -Headers $headers
        foreach ($field in $fieldCheckResponse.d.results) {
            if ($field.InternalName -eq 'DocumentClass') {
                $fieldExists.DocumentClass = $true
            }
            if ($field.InternalName -eq 'OData__ExtendedDescription') {
                $fieldExists.OData__ExtendedDescription = $true
            }
            if ($field.InternalName -in $choiceFields) {
                $fieldExists.ChoiceFields += $field.InternalName
            }
        }
    }
    catch {
        Write-LogINFO "Error checking for fields: $_.Exception.Message"
    }

    return $fieldExists
}

function getFieldsQuery {
    param (
        [Parameter(Mandatory = $true)]
        [hashtable]$fieldExists,

        [Parameter(Mandatory = $false)]
        [array]$choiceFields = @()
    )

    $selectQuery = "File,Title,Modified,EditorId,ContentTypeId,ContentType/Name,ID,FileSystemObjectType,Document_Class,DocumentSetDescription"
    if ($fieldExists.DocumentClass) {
        $selectQuery += ",DocumentClass"
    }
    if ($fieldExists.OData__ExtendedDescription) {
        $selectQuery += ",OData__ExtendedDescription"
    }
    foreach ($choiceField in $choiceFields) {
        if (-not [string]::IsNullOrWhiteSpace($choiceField)) {
            $selectQuery += ",$choiceField"
        }
    }
    return $selectQuery
}

function getListItemsBatch {
    param (
        [Parameter(Mandatory = $true)]
        [string]$nextUrl,

        [Parameter(Mandatory = $true)]
        [hashtable]$headers
    )
    try {
        $response = Invoke-RestMethod -Uri $nextUrl -Method Get -Headers $headers
        if ($null -ne $response -and ($response | Out-String) -like '*"Id"*') {
            $responseData = $response.Replace("""Id""", "ItemId") | ConvertFrom-Json
            return @{
                Items = $responseData.d.results
                NextUrl = $responseData.d.__next
            }
        }
    }
    catch {
        Write-LogINFO $_.Exception.Message
    }

    return @{
        Items = @()
        NextUrl = $null
    }
}

function getAllListItems {
    param (
        [Parameter(Mandatory = $true)]
        [string]$siteUrl,

        [Parameter(Mandatory = $true)]
        [string]$libraryGUID,

        [Parameter(Mandatory = $true)]
        [hashtable]$headers
    )

    $allItems = @()

    # Check if the DocumentClass and OData__ExtendedDescription fields exist
    $fieldExists = @{
        DocumentClass = $false
        OData__ExtendedDescription = $false
    }
    $fieldCheckUrl = "$siteUrl/_api/web/lists(guid'$libraryGUID')/fields?`$filter=((InternalName eq 'DocumentClass') or (InternalName eq 'OData__ExtendedDescription'))"
    try {
        $fieldCheckResponse = Invoke-RestMethod -Uri $fieldCheckUrl -Method Get -Headers $headers
        foreach ($field in $fieldCheckResponse.d.results) {
            if ($field.InternalName -eq 'DocumentClass') {
                $fieldExists.DocumentClass = $true
            }
            if ($field.InternalName -eq 'OData__ExtendedDescription') {
                $fieldExists.OData__ExtendedDescription = $true
            }
        }
    }
    catch {
        Write-LogINFO "Error checking for fields: $_.Exception.Message"
    }

    # Construct the select query based on the existence of the fields
    $selectQuery = "File,Title,Modified,EditorId,ContentTypeId,ContentType/Name,ContentType/Parent/Id,ID,FileSystemObjectType,Document_Class,DocumentSetDescription"
    if ($fieldExists.DocumentClass) {
        $selectQuery += ",DocumentClass"
    }
    if ($fieldExists.OData__ExtendedDescription) {
        $selectQuery += ",OData__ExtendedDescription"
    }

    $nextUrl = "$siteUrl/_api/web/lists(guid'$libraryGUID')/items?`$select=$selectQuery&`$expand=ContentType,ContentType/Parent,File/Name"

    do {
        try {
            $response = Invoke-RestMethod -Uri $nextUrl -Method Get -Headers $headers
            if ($null -ne $response -and ($response | Out-String) -like '*"ID"*') {
                $responseData = $response.Replace("""ID""", "_ID") | ConvertFrom-Json
                $allItems += $responseData.d.results
                $nextUrl = $responseData.d.__next
            } else {
                $nextUrl = $null
            }
        }
        catch {
            Write-LogINFO $_.Exception.Message
            break
        }
    } while ($nextUrl)

    return $allItems
}

function getWantedContentTypeId {
    param (
        [Parameter(Mandatory = $true)] [object] $item,
        [Parameter(Mandatory = $true)] [psobject] $updateConfig,
        [Parameter(Mandatory = $true)] [object[]] $libraryContentTypes,
        [Parameter(Mandatory = $true)] [psobject] $ContentTypeDefinitions,
        [Parameter(Mandatory = $true)] [psobject] $language
    )

    $contentTypesConfig = $updateConfig.ContentTypes

    foreach ($contentTypeConfig in $contentTypesConfig) {
        $legacyNames = $contentTypeConfig.LegacyNames + @($ContentTypeDefinitions.$($contentTypeConfig.Key).Name.$language)

        foreach ($legacyName in $legacyNames) {
            if ($item.ContentType.Name -eq "$legacyName`_Legacy") {
                return getListContentTypeByParentId -ParentId $contentTypeConfig.Key -LibraryContentTypes $libraryContentTypes
            }
        }
    }

    return $null
}

function getListContentTypeByParentId() {
    param (
        [Parameter(Mandatory = $true)] [string] $parentId,
        [Parameter(Mandatory = $true)] [object[]] $libraryContentTypes
    )
    # Prefer matching by the loaded parent content type ID.
    foreach ($libraryContentType in $libraryContentTypes) {
        if ($null -ne $libraryContentType.Parent -and $null -ne $libraryContentType.Parent.Id -and $libraryContentType.Parent.Id.StringValue -eq $parentId) {
            return $libraryContentType.Id.StringValue
        }

        if ($null -ne $libraryContentType.Parent -and $null -ne $libraryContentType.Parent.StringValue -and $libraryContentType.Parent.StringValue -eq $parentId) {
            return $libraryContentType.Id.StringValue
        }
    }

    foreach ($libraryContentType in $libraryContentTypes) {
        if ($libraryContentType.Id.StringValue -like "$parentId*") {
            return $libraryContentType.Id.StringValue
        }
    }
    return $null
}

function getLibraryContentTypes {
    param (
        [Parameter(Mandatory = $true)]
        [string]$siteUrl,

        [Parameter(Mandatory = $true)]
        [string]$libraryGUID,

        [Parameter(Mandatory = $true)]
        [hashtable]$headers
    )

    $url = "$siteUrl/_api/web/lists(guid'$libraryGUID')/ContentTypes?`$expand=Parent"
    Write-LogINFO "Getting library content types from $($url)"
    $response = Invoke-RestMethod -Uri $url -Method Get -Headers $headers
    $contentTypes = $response.d.results
    return $contentTypes
}

function getDocumentClassTerms() {
    param (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $context
    )
    try {
        $documentClassField = $context.Web.Fields.GetByInternalNameOrTitle("Document_Class");
        $context.Load($documentClassField)
        ExecuteQueryWithRetry -Ctx $Context
        $termSetId = $documentClassField.TypedObject.TermSetId
        $session = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($context)
        $termStore = $session.GetDefaultSiteCollectionTermStore()
        $termSet = $termStore.GetTermSet($termSetId)
        $terms = $termSet.GetAllTerms()
        $context.Load($terms)
        ExecuteQueryWithRetry -Ctx $Context
        foreach ($term in $terms) {
            $context.Load($term.Labels)
        }
        ExecuteQueryWithRetry -Ctx $Context
        return $terms
    }
    catch {
        Write-LogERR "Error getting document class terms " $_.Exception.Message
        return $null
    }
}

function getTimezoneOffset($ctx) {
    $ctx.Load($ctx.Web.RegionalSettings.TimeZone)
    ExecuteQueryWithRetry -ctx $Ctx
    $timezoneBias = $Ctx.Web.RegionalSettings.TimeZone.Information.Bias
    return $timezoneBias
}

function Get-UpdateItemsAutomationVariable {
    param([Parameter(Mandatory = $true)] [string]$Name)

    if (-not (Get-Command Get-AutomationVariable -ErrorAction SilentlyContinue)) {
        return $null
    }
    try {
        return Get-AutomationVariable -Name $Name -ErrorAction Stop
    }
    catch {
        return $null
    }
}

$script:managedIdentityTokenCache = @{}

function Get-UpdateItemsManagedIdentityToken {
    <#
    .SYNOPSIS
    Acquires a managed identity access token, in the cloud sandbox or on a Hybrid Runbook Worker.

    .DESCRIPTION
    Mirrors the identity pattern the UPS runbooks use (UPS_ChangeContentType): a user-assigned
    managed identity whose client ID lives in the 'managedId' Automation Variable, acquired from
    IMDS with a client_id parameter.

    Two endpoints are needed because only one works in each host:
      - Cloud sandbox: Azure Automation injects IDENTITY_ENDPOINT/IDENTITY_HEADER. IMDS
        (169.254.169.254) is NOT reachable from the sandbox container.
      - Hybrid Runbook Worker / any Azure VM: IMDS is the only option, and IDENTITY_ENDPOINT is
        not set.
    Both accept client_id, so the same identity is used either way. Tokens are cached per
    resource+identity with a safety buffer, because a long dispatch loop can outlive one token.
    #>
    param(
        [Parameter(Mandatory = $true)] [string]$Resource,
        [Parameter(Mandatory = $false)] [string]$ClientId,
        [Parameter(Mandatory = $false)] [int]$ExpiryBufferSeconds = 300
    )

    if ([string]::IsNullOrWhiteSpace($ClientId)) {
        $ClientId = Get-UpdateItemsAutomationVariable -Name 'managedId'
    }

    $cacheKey = "$Resource|$ClientId"
    $cached = $script:managedIdentityTokenCache[$cacheKey]
    if ($null -ne $cached -and (Get-Date) -lt $cached.ExpiresAt) {
        return $cached.AccessToken
    }

    $response = $null
    $identityUsed = $null
    $failures = @()

    # A user-assigned identity reached through IMDS is attached to the WORKER VM, while the same
    # identity reached through IDENTITY_ENDPOINT must be attached to the AUTOMATION ACCOUNT. They
    # are configured separately, so the user-assigned attempt can fail in one host and succeed in
    # the other - fall back to the account's system-assigned identity rather than dying, and say
    # so loudly, because two hosts silently using different identities is how a 403 turns into
    # hours of debugging.
    $identityCandidates = @()
    if (-not [string]::IsNullOrWhiteSpace($ClientId)) { $identityCandidates += $ClientId }
    $identityCandidates += $null

    foreach ($candidateId in $identityCandidates) {
        $candidateLabel = if ($candidateId) { "user-assigned $candidateId" } else { 'system-assigned' }

        if ($null -eq $response -and -not [string]::IsNullOrWhiteSpace($env:IDENTITY_ENDPOINT)) {
            try {
                $uri = "$($env:IDENTITY_ENDPOINT)?resource=$([System.Uri]::EscapeDataString($Resource))&api-version=2019-08-01"
                if ($candidateId) { $uri += "&client_id=$([System.Uri]::EscapeDataString($candidateId))" }
                $response = Invoke-RestMethod -Uri $uri `
                    -Headers @{ 'X-IDENTITY-HEADER' = $env:IDENTITY_HEADER } `
                    -Method Get -ErrorAction Stop
                $identityUsed = "$candidateLabel via sandbox IDENTITY_ENDPOINT"
            }
            catch {
                $failures += "IDENTITY_ENDPOINT [$candidateLabel]: $($_.Exception.Message)"
            }
        }

        if ($null -eq $response) {
            try {
                $imdsBody = @{ 'api-version' = '2018-02-01'; resource = $Resource }
                if ($candidateId) { $imdsBody['client_id'] = $candidateId }
                $response = Invoke-RestMethod -Method Get -Uri 'http://169.254.169.254/metadata/identity/oauth2/token' `
                    -Headers @{ Metadata = 'true' } -Body $imdsBody -TimeoutSec 15 -ErrorAction Stop
                $identityUsed = "$candidateLabel via IMDS"
            }
            catch {
                $failures += "IMDS [$candidateLabel]: $($_.Exception.Message)"
            }
        }

        if ($null -ne $response) {
            if (-not [string]::IsNullOrWhiteSpace($ClientId) -and $candidateId -ne $ClientId) {
                Write-LogWarn ("Managed identity '$ClientId' (Automation Variable 'managedId') could not issue a token for '$Resource'; " +
                               "fell back to the system-assigned identity. In the cloud sandbox this means that user-assigned identity is " +
                               "not attached to the Automation account - attach it there so both hosts use the identity the UPS runbooks use.")
            }
            break
        }
    }

    if ($null -eq $response -or [string]::IsNullOrWhiteSpace($response.access_token)) {
        throw "Managed identity token request failed for resource '$Resource'$(if ($ClientId) { " (client_id $ClientId)" }). Tried: $($failures -join ' | ')"
    }

    # expires_on is unix seconds from both endpoints; fall back to a conservative window if absent.
    $expiresAt = (Get-Date).AddMinutes(50)
    if ($response.PSObject.Properties['expires_on'] -and -not [string]::IsNullOrWhiteSpace([string]$response.expires_on)) {
        try {
            $expiresAt = [DateTimeOffset]::FromUnixTimeSeconds([long]$response.expires_on).LocalDateTime.AddSeconds(-$ExpiryBufferSeconds)
        }
        catch {
            Write-LogWarn "Could not parse managed identity token expiry '$($response.expires_on)'; using a 50 minute window."
        }
    }

    $script:managedIdentityTokenCache[$cacheKey] = [PSCustomObject]@{
        AccessToken = [string]$response.access_token
        ExpiresAt   = $expiresAt
        Identity    = $identityUsed
    }
    Write-LogINFO "Managed identity token acquired for '$Resource' via $identityUsed; valid until $expiresAt."
    return [string]$response.access_token
}

function Get-UpdateItemsActiveAutomationJobCount {
    param(
        [Parameter(Mandatory = $true)] [string]$SubscriptionId,
        [Parameter(Mandatory = $true)] [string]$ResourceGroup,
        [Parameter(Mandatory = $true)] [string]$AutomationAccount,
        [Parameter(Mandatory = $true)] [string]$AccessToken
    )

    return @(Get-UpdateItemsRunningAutomationJobs `
        -SubscriptionId $SubscriptionId `
        -ResourceGroup $ResourceGroup `
        -AutomationAccount $AutomationAccount `
        -AccessToken $AccessToken).Count
}

# Uses the same collection-level job lookup as the UPS runbooks. This avoids one ARM
# request per child job and gives the dispatcher one consistent snapshot of the account.
function Get-UpdateItemsAutomationJobs {
    param(
        [Parameter(Mandatory = $true)] [string]$SubscriptionId,
        [Parameter(Mandatory = $true)] [string]$ResourceGroup,
        [Parameter(Mandatory = $true)] [string]$AutomationAccount,
        [Parameter(Mandatory = $true)] [string]$AccessToken,
        [Parameter(Mandatory = $false)] [int]$MaxRetries = 3
    )

    $url = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccount/jobs?api-version=2019-06-01"
    $headers = @{ Authorization = "Bearer $AccessToken"; "Content-Type" = "application/json" }

    for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {
        try {
            # ARM pages this collection. Reading only the first page silently loses jobs once the
            # account has accumulated a few hundred, which makes our own jobs look absent - and an
            # absent job reads as "finished" to a waiter and as "still running" to a gate. Follow
            # nextLink so the snapshot is complete.
            $allJobs = [System.Collections.Generic.List[object]]::new()
            $pageUrl = $url
            while (-not [string]::IsNullOrWhiteSpace($pageUrl)) {
                $response = Invoke-RestMethod -Uri $pageUrl -Headers $headers -Method Get -ErrorAction Stop
                if ($null -eq $response) { break }
                foreach ($job in @($response.value)) {
                    if ($null -ne $job) { $allJobs.Add($job) }
                }
                $pageUrl = $response.nextLink
            }
            return @($allJobs)
        }
        catch {
            $statusCode = $null
            if ($null -ne $_.Exception.Response) { $statusCode = [int]$_.Exception.Response.StatusCode }

            # 403 is authorization, not authentication - the token was accepted but the identity
            # has no rights at this scope. Retrying cannot fix it, so fail immediately with the
            # exact grant that is missing instead of burning three attempts on a dead end.
            if ($statusCode -eq 403) {
                throw ("Azure Automation jobs lookup returned 403 Forbidden. The managed identity is authenticated but not authorized on " +
                       "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccount. " +
                       "Grant it the 'Automation Job Operator' role at that scope (it needs Microsoft.Automation/automationAccounts/jobs/read), " +
                       "and verify the AutomationSubscriptionId / AutomationResourceGroup / AutomationAccountName variables point at that account.")
            }

            if ($attempt -eq $MaxRetries) {
                throw "Failed to fetch Azure Automation jobs after $MaxRetries attempts: $($_.Exception.Message)"
            }
            Write-LogWARN "Azure Automation jobs lookup attempt $attempt failed: $($_.Exception.Message). Retrying..."
            Start-Sleep -Seconds ($attempt * 10)
        }
    }
}

function Get-UpdateItemsRunningAutomationJobs {
    param(
        [Parameter(Mandatory = $true)] [string]$SubscriptionId,
        [Parameter(Mandatory = $true)] [string]$ResourceGroup,
        [Parameter(Mandatory = $true)] [string]$AutomationAccount,
        [Parameter(Mandatory = $true)] [string]$AccessToken
    )

    $jobs = Get-UpdateItemsAutomationJobs `
        -SubscriptionId $SubscriptionId `
        -ResourceGroup $ResourceGroup `
        -AutomationAccount $AutomationAccount `
        -AccessToken $AccessToken
    return @($jobs | Where-Object { $_.properties.status -in @('Running', 'Queued') })
}

$script:updateItemsTerminalJobStatus = @{}

# A job that has reached one of these will never change again, so its status can be cached
# permanently and never re-queried.
$script:updateItemsTerminalStatuses = @('Completed', 'Failed', 'Stopped', 'Suspended', 'Blocked')

function Get-UpdateItemsJobStatusMap {
    <#
    .SYNOPSIS
    Returns a jobId -> status map for the given jobs, read one job at a time.

    .DESCRIPTION
    Deliberately queries each job by ID instead of scanning the account's job collection. The
    collection is paged and ordered by the service, so a job can be missing from a snapshot for
    reasons that have nothing to do with its state - and for a hard concurrency cap, a job whose
    state we cannot read must never be mistaken for a free slot.

    Terminal statuses are cached, so a poll only costs one request per job still in flight - at
    most $MaxConcurrentJobs requests regardless of how many batches the library needs.
    A job ARM has not materialised yet reports $null, which callers treat as in flight.
    #>
    param(
        [Parameter(Mandatory = $true)] [string]$SubscriptionId,
        [Parameter(Mandatory = $true)] [string]$ResourceGroup,
        [Parameter(Mandatory = $true)] [string]$AutomationAccount,
        [Parameter(Mandatory = $true)] [string]$AccessToken,
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [string[]]$JobIds
    )

    $headers = @{ Authorization = "Bearer $AccessToken"; 'Content-Type' = 'application/json' }
    $statuses = @{}

    foreach ($rawJobId in $JobIds) {
        $jobId = [string]$rawJobId
        if ([string]::IsNullOrWhiteSpace($jobId)) { continue }

        if ($script:updateItemsTerminalJobStatus.ContainsKey($jobId)) {
            $statuses[$jobId] = $script:updateItemsTerminalJobStatus[$jobId]
            continue
        }

        $jobUrl = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccount/jobs/$jobId" + "?api-version=2019-06-01"
        try {
            $response = Invoke-RestMethod -Uri $jobUrl -Headers $headers -Method Get -ErrorAction Stop
            $status = [string]$response.properties.status
            $statuses[$jobId] = $status
            if ($script:updateItemsTerminalStatuses -contains $status) {
                $script:updateItemsTerminalJobStatus[$jobId] = $status
            }
        }
        catch {
            # A 404 immediately after dispatch just means ARM has not created the job record yet.
            # Unknown, not finished.
            $statuses[$jobId] = $null
        }
    }

    return $statuses
}

# Marker the child batch job writes to its OUTPUT stream so the dispatcher can read per-batch
# counts back. Deliberately the Output stream, not Warning: Write-Log* goes to Warning, so the
# Output stream contains only these structured lines and needs no filtering.
$script:updateItemsBatchResultMarker = 'DMS-BATCH-RESULT'

function Get-UpdateItemsJobBatchResult {
    <#
    .SYNOPSIS
    Reads a child batch job's output stream and returns its reported updated/failed counts.

    .DESCRIPTION
    Child jobs run in their own sandbox, so their results never come back through the return value
    of anything the dispatcher called. The dispatcher instead reads the job's output through ARM
    and parses the marker line the child emitted. Returns $null when the job produced no marker
    (for example it died before reaching the summary).
    #>
    param(
        [Parameter(Mandatory = $true)] [string]$SubscriptionId,
        [Parameter(Mandatory = $true)] [string]$ResourceGroup,
        [Parameter(Mandatory = $true)] [string]$AutomationAccount,
        [Parameter(Mandatory = $true)] [string]$AccessToken,
        [Parameter(Mandatory = $true)] [string]$JobId
    )

    # Azure Automation exposes a job's output through /streams, NOT /output. The previous version
    # used /output, which returns nothing here - which is why every batch reported "no batch result"
    # while the children had in fact done the work. read-job-output.js uses this same /streams path.
    $headers = @{ Authorization = "Bearer $AccessToken" }
    $jobBase = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Automation/automationAccounts/$AutomationAccount/jobs/$JobId"

    # Try the Output-only filter first to avoid fetching a child's hundreds of Warning streams,
    # then fall back to unfiltered. The fallback must also trigger when the filtered call SUCCEEDS
    # but matches nothing: the previous version only retried on an exception, so a filter the
    # service accepts yet evaluates differently reported "no output streams" for a job that had
    # plenty - which is exactly what happened.
    $streams = @()
    foreach ($streamsQuery in @("?api-version=2019-06-01&`$filter=properties/streamType%20eq%20'Output'", "?api-version=2019-06-01")) {
        $streamsUrl = "$jobBase/streams$streamsQuery"
        $pageStreams = @()
        try {
            while (-not [string]::IsNullOrWhiteSpace($streamsUrl)) {
                $response = Invoke-RestMethod -Uri $streamsUrl -Headers $headers -Method Get -ErrorAction Stop
                foreach ($streamEntry in @($response.value)) {
                    if ($null -ne $streamEntry) { $pageStreams += $streamEntry }
                }
                $streamsUrl = $response.nextLink
            }
            $streams = $pageStreams
        }
        catch {
            Write-LogWarn "Could not list job streams for ${JobId} (${streamsQuery}): $($_.Exception.Message)"
        }
        if ($streams.Count -gt 0) { break }
    }

    if ($streams.Count -eq 0) {
        Write-LogWarn "Job $JobId produced no streams at all (filtered and unfiltered both empty)."
        return $null
    }

    foreach ($stream in $streams) {
        # summary in the list response is truncated, so fetch the stream for its full text. Property
        # naming varies across stream types, hence several candidates.
        $textCandidates = @()
        if ($null -ne $stream.properties) { $textCandidates += [string]$stream.properties.summary }

        if (-not [string]::IsNullOrWhiteSpace([string]$stream.id)) {
            try {
                $detail = Invoke-RestMethod -Uri "https://management.azure.com$($stream.id)?api-version=2019-06-01" `
                    -Headers $headers -Method Get -ErrorAction Stop
                if ($null -ne $detail.properties) {
                    $textCandidates += [string]$detail.properties.streamText
                    $textCandidates += [string]$detail.properties.summary
                    if ($null -ne $detail.properties.value) {
                        foreach ($valueProperty in $detail.properties.value.PSObject.Properties) {
                            $textCandidates += [string]$valueProperty.Value
                        }
                    }
                }
            }
            catch {
                # One unreadable stream must not abandon the whole job's result.
            }
        }

        foreach ($text in $textCandidates) {
            if ([string]::IsNullOrWhiteSpace($text)) { continue }
            foreach ($line in ($text -split "`r?`n")) {
                $trimmed = $line.Trim()
                if (-not $trimmed.StartsWith($script:updateItemsBatchResultMarker)) { continue }
                $json = $trimmed.Substring($script:updateItemsBatchResultMarker.Length).Trim()
                try {
                    return $json | ConvertFrom-Json
                }
                catch {
                    Write-LogWarn "Job $JobId emitted an unparsable batch result: $json"
                }
            }
        }
    }

    Write-LogWarn "Job $JobId had $($streams.Count) stream(s) but none contained a '$($script:updateItemsBatchResultMarker)' line."
    return $null
}

function Get-UpdateItemsBatchResultFile {
    <#
    .SYNOPSIS
    Reads a batch's result JSON from the site's SiteAssets library.

    .DESCRIPTION
    The primary channel for batch results. The child writes a small JSON file under a name the
    parent can compute exactly, so nothing depends on Azure Automation's job output stream being
    retrievable through ARM - which proved unreliable. uploadFileToSiteAssets is the same path the
    runbook log already uses successfully, so this reuses machinery known to work.
    #>
    param(
        [Parameter(Mandatory = $true)] [string]$SiteUrl,
        [Parameter(Mandatory = $true)] [hashtable]$Headers,
        [Parameter(Mandatory = $true)] [string]$FileName
    )

    $webRelativeUrl = ([System.Uri]$SiteUrl).AbsolutePath.TrimEnd('/')
    $fileUrl = "$SiteUrl/_api/web/GetFileByServerRelativeUrl('$webRelativeUrl/SiteAssets/$FileName')/`$value"
    try {
        $raw = Invoke-RestMethod -Uri $fileUrl -Headers $Headers -Method Get -ErrorAction Stop
        if ($null -eq $raw) { return $null }
        if ($raw -is [string]) { return $raw | ConvertFrom-Json }
        return $raw
    }
    catch {
        return $null
    }
}

function Get-UpdateItemsBatchResultFileName {
    param(
        [Parameter(Mandatory = $true)] [string]$LibraryGUID,
        [Parameter(Mandatory = $true)] [int]$BatchNumber
    )
    return "DMS-Batch-Result-$LibraryGUID-batch$BatchNumber.json"
}

function Get-UpdateItemsSiteAssetFile {
    <#
    .SYNOPSIS
    Downloads one SiteAssets file to a local path. Returns $true on success.
    #>
    param(
        [Parameter(Mandatory = $true)] [string]$SiteUrl,
        [Parameter(Mandatory = $true)] [hashtable]$Headers,
        [Parameter(Mandatory = $true)] [string]$FileName,
        [Parameter(Mandatory = $true)] [string]$DestinationPath
    )

    $webRelativeUrl = ([System.Uri]$SiteUrl).AbsolutePath.TrimEnd('/')
    $fileUrl = "$SiteUrl/_api/web/GetFileByServerRelativeUrl('$webRelativeUrl/SiteAssets/$FileName')/`$value"
    try {
        # -OutFile streams straight to disk; a batch report must never be materialised as a string.
        Invoke-WebRequest -Uri $fileUrl -Headers $Headers -Method Get -OutFile $DestinationPath `
            -UseBasicParsing -ErrorAction Stop | Out-Null
        return $true
    }
    catch {
        Write-LogWarn "Could not download SiteAssets file '$FileName': $($_.Exception.Message)"
        return $false
    }
}

function Remove-UpdateItemsSiteAssetFile {
    <#
    .SYNOPSIS
    Deletes one SiteAssets file. Deleted files go to the site recycle bin, so this is recoverable.
    #>
    param(
        [Parameter(Mandatory = $true)] [string]$SiteUrl,
        [Parameter(Mandatory = $true)] [hashtable]$Headers,
        [Parameter(Mandatory = $true)] [string]$FileName
    )

    $webRelativeUrl = ([System.Uri]$SiteUrl).AbsolutePath.TrimEnd('/')
    $fileUrl = "$SiteUrl/_api/web/GetFileByServerRelativeUrl('$webRelativeUrl/SiteAssets/$FileName')"
    $deleteHeaders = @{}
    foreach ($headerEntry in $Headers.GetEnumerator()) { $deleteHeaders[$headerEntry.Key] = $headerEntry.Value }
    $deleteHeaders['X-HTTP-Method'] = 'DELETE'
    $deleteHeaders['IF-MATCH'] = '*'
    try {
        Invoke-RestMethod -Uri $fileUrl -Headers $deleteHeaders -Method Post -ErrorAction Stop | Out-Null
        return $true
    }
    catch {
        Write-LogWarn "Could not delete SiteAssets file '$FileName': $($_.Exception.Message)"
        return $false
    }
}

function Get-UpdateItemsFileNameFromUrl {
    param([Parameter(Mandatory = $true)] [string]$Url)
    $path = ([System.Uri]$Url).AbsolutePath
    return [System.Uri]::UnescapeDataString(($path -split '/')[-1])
}

function Get-UpdateItemsSiteAssetLocation {
    <#
    .SYNOPSIS
    Splits a SiteAssets URL into the web it belongs to and the file name within it.

    .DESCRIPTION
    Needed because reports do not all live in one web: a library on a subsite has its report in
    that subsite's SiteAssets. Consolidation therefore has to read each source from its own web,
    and cannot assume a single site URL. Returns $null for a URL that is not a SiteAssets path.
    #>
    param([Parameter(Mandatory = $true)] [string]$Url)

    $marker = '/SiteAssets/'
    $markerIndex = $Url.IndexOf($marker, [System.StringComparison]::OrdinalIgnoreCase)
    if ($markerIndex -lt 0) { return $null }

    return [PSCustomObject]@{
        SiteUrl  = $Url.Substring(0, $markerIndex)
        FileName = [System.Uri]::UnescapeDataString($Url.Substring($markerIndex + $marker.Length))
    }
}

function New-UpdateItemsConsolidatedItemReport {
    <#
    .SYNOPSIS
    Concatenates the per-batch item migration CSVs into one CSV and uploads it.

    .DESCRIPTION
    Per-item rows, so the batches concatenate: keep the first header, drop the rest. Streamed line
    by line through a StreamWriter because a consolidated report for a six-figure library is tens of
    megabytes and must never be held in memory inside a 400 MB sandbox.
    #>
    param(
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [string[]]$SourceUrls,
        [Parameter(Mandatory = $true)] [string]$TargetSiteUrl,
        [Parameter(Mandatory = $true)] [hashtable]$Headers,
        [Parameter(Mandatory = $true)] [string]$TargetFileName,
        [Parameter(Mandatory = $false)] [object]$Context
    )

    if ($SourceUrls.Count -eq 0) { return $null }

    $tempDir = Get-RunbookTempDir
    $consolidatedPath = Join-Path $tempDir $TargetFileName
    if (Test-Path $consolidatedPath) { Remove-Item $consolidatedPath -Force -ErrorAction SilentlyContinue }

    $rowCount = 0
    $merged = 0
    $missing = @()
    $writer = [System.IO.StreamWriter]::new($consolidatedPath, $false, [System.Text.UTF8Encoding]::new($true))
    try {
        $headerWritten = $false
        foreach ($sourceUrl in $SourceUrls) {
            $location = Get-UpdateItemsSiteAssetLocation -Url $sourceUrl
            if ($null -eq $location) {
                # A local fallback path rather than a SiteAssets URL - nothing to download.
                $missing += $sourceUrl
                continue
            }

            $localPath = Join-Path $tempDir "dl-$($location.FileName)"
            if (-not (Get-UpdateItemsSiteAssetFile -SiteUrl $location.SiteUrl -Headers $Headers -FileName $location.FileName -DestinationPath $localPath)) {
                $missing += $sourceUrl
                continue
            }
            $merged++

            $reader = [System.IO.StreamReader]::new($localPath)
            try {
                $lineNumber = 0
                while ($null -ne ($line = $reader.ReadLine())) {
                    $lineNumber++
                    if ($lineNumber -eq 1) {
                        if (-not $headerWritten) {
                            $writer.WriteLine($line)
                            $headerWritten = $true
                        }
                        continue
                    }
                    if ([string]::IsNullOrWhiteSpace($line)) { continue }
                    $writer.WriteLine($line)
                    $rowCount++
                }
            }
            finally {
                $reader.Dispose()
                Remove-Item $localPath -Force -ErrorAction SilentlyContinue
            }
        }
    }
    finally {
        $writer.Dispose()
    }

    if ($missing.Count -gt 0) {
        Write-LogWarn "Consolidated item report is missing $($missing.Count) source file(s): $($missing -join ', ')"
    }
    if ($rowCount -eq 0) {
        Remove-Item $consolidatedPath -Force -ErrorAction SilentlyContinue
        return $null
    }

    Write-LogINFO "Consolidated item migration report: $rowCount row(s) merged from $merged source file(s)."
    $uploaded = uploadFileToSiteAssets -siteUrl $TargetSiteUrl -headers $Headers `
        -sourceFilePath $consolidatedPath -targetFileName $TargetFileName -context $Context
    if ($uploaded) { return "$TargetSiteUrl/SiteAssets/$TargetFileName" }
    return $null
}

function New-UpdateItemsConsolidatedContentTypeReport {
    <#
    .SYNOPSIS
    Aggregates the per-batch content type summary CSVs into one CSV and uploads it.

    .DESCRIPTION
    These rows are COUNTS per content type, not per-item records, so concatenating would emit one
    duplicate row per batch for every content type. They are summed on
    SiteUrl + LibraryName + ContentTypeId instead. Each batch file is only a handful of rows, so
    Import-Csv is fine here.
    #>
    param(
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [string[]]$SourceUrls,
        [Parameter(Mandatory = $true)] [string]$TargetSiteUrl,
        [Parameter(Mandatory = $true)] [hashtable]$Headers,
        [Parameter(Mandatory = $true)] [string]$TargetFileName,
        [Parameter(Mandatory = $false)] [object]$Context
    )

    if ($SourceUrls.Count -eq 0) { return $null }

    $tempDir = Get-RunbookTempDir
    $aggregated = @{}
    $missing = @()

    foreach ($sourceUrl in $SourceUrls) {
        $location = Get-UpdateItemsSiteAssetLocation -Url $sourceUrl
        if ($null -eq $location) {
            $missing += $sourceUrl
            continue
        }
        $localPath = Join-Path $tempDir "dl-$($location.FileName)"
        if (-not (Get-UpdateItemsSiteAssetFile -SiteUrl $location.SiteUrl -Headers $Headers -FileName $location.FileName -DestinationPath $localPath)) {
            $missing += $sourceUrl
            continue
        }
        try {
            foreach ($row in @(Import-Csv -Path $localPath)) {
                $key = "$($row.SiteUrl)|$($row.LibraryName)|$($row.ContentTypeId)"
                if (-not $aggregated.ContainsKey($key)) {
                    $aggregated[$key] = [PSCustomObject]@{
                        SiteUrl              = $row.SiteUrl
                        LibraryName          = $row.LibraryName
                        ContentTypeId        = $row.ContentTypeId
                        ContentTypeName      = $row.ContentTypeName
                        BeforeMigrationCount = 0
                        AfterMigrationCount  = 0
                    }
                }
                $beforeValue = 0; $afterValue = 0
                [void][int]::TryParse([string]$row.BeforeMigrationCount, [ref]$beforeValue)
                [void][int]::TryParse([string]$row.AfterMigrationCount, [ref]$afterValue)
                $aggregated[$key].BeforeMigrationCount += $beforeValue
                $aggregated[$key].AfterMigrationCount += $afterValue
            }
        }
        catch {
            Write-LogWarn "Could not read content type rows from '$($location.FileName)': $($_.Exception.Message)"
        }
        finally {
            Remove-Item $localPath -Force -ErrorAction SilentlyContinue
        }
    }

    if ($missing.Count -gt 0) {
        Write-LogWarn "Consolidated content type report is missing $($missing.Count) source file(s): $($missing -join ', ')"
    }
    if ($aggregated.Count -eq 0) { return $null }

    $consolidatedPath = Join-Path $tempDir $TargetFileName
    $aggregated.Values |
        Sort-Object SiteUrl, LibraryName, ContentTypeName |
        Select-Object SiteUrl, LibraryName, ContentTypeId, ContentTypeName, BeforeMigrationCount, AfterMigrationCount |
        Export-Csv -Path $consolidatedPath -NoTypeInformation -Encoding UTF8

    Write-LogINFO "Consolidated content type summary report: $($aggregated.Count) content type row(s)."
    $uploaded = uploadFileToSiteAssets -siteUrl $TargetSiteUrl -headers $Headers `
        -sourceFilePath $consolidatedPath -targetFileName $TargetFileName -context $Context
    if ($uploaded) { return "$TargetSiteUrl/SiteAssets/$TargetFileName" }
    return $null
}

function Invoke-UpdateItemsWebhookPost {
    <#
    .SYNOPSIS
    POSTs one batch to the UpdateItems webhook, retrying when Azure Automation throttles.

    .DESCRIPTION
    The webhook endpoint rate-limits job submissions and answers 429 when it has had enough.
    Previously a single 429 propagated straight out and aborted the whole site migration partway
    through dispatch, abandoning the batches already running. Throttling is expected at this scale,
    not exceptional, so back off and retry - honouring Retry-After when the service supplies one.
    #>
    param(
        [Parameter(Mandatory = $true)] [string]$WebhookUrl,
        [Parameter(Mandatory = $true)] [string]$Payload,
        [Parameter(Mandatory = $false)] [int]$MaxAttempts = 6
    )

    $backoffSeconds = 15
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            return Invoke-RestMethod -Uri $WebhookUrl -Method Post -Body $Payload `
                -ContentType 'application/json; charset=utf-8' -ErrorAction Stop
        }
        catch {
            $statusCode = $null
            if ($null -ne $_.Exception.Response) { $statusCode = [int]$_.Exception.Response.StatusCode }

            # Only throttling and transient unavailability are worth retrying; anything else is a
            # real failure and must surface immediately.
            if ($statusCode -ne 429 -and $statusCode -ne 503) { throw }

            if ($attempt -eq $MaxAttempts) {
                throw "Webhook POST was throttled ($statusCode) on all $MaxAttempts attempts: $($_.Exception.Message)"
            }

            $waitSeconds = $backoffSeconds
            try {
                $retryAfter = $_.Exception.Response.Headers['Retry-After']
                $parsedRetryAfter = 0
                if (-not [string]::IsNullOrWhiteSpace($retryAfter) -and
                    [int]::TryParse($retryAfter, [ref]$parsedRetryAfter) -and $parsedRetryAfter -gt 0) {
                    $waitSeconds = $parsedRetryAfter
                }
            }
            catch {
                # No usable Retry-After - the exponential backoff below still applies.
            }

            Write-LogWarn "Webhook POST throttled ($statusCode) on attempt $attempt of $MaxAttempts. Retrying in ${waitSeconds}s."
            Start-Sleep -Seconds $waitSeconds
            $backoffSeconds = [Math]::Min($backoffSeconds * 2, 120)
        }
    }
}

function Get-UpdateItemsInFlightJobCount {
    <#
    .SYNOPSIS
    Counts how many of OUR dispatched batch jobs have not reached a terminal state.

    .DESCRIPTION
    Only our own jobs count, so other runbooks in the account do not consume the budget. A job
    with an unknown status counts as in flight: being pessimistic costs one poll interval, being
    optimistic breaks the cap.
    #>
    param(
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [string[]]$DispatchedJobIds,
        [Parameter(Mandatory = $true)] [hashtable]$StatusMap
    )

    $inFlight = 0
    foreach ($rawJobId in $DispatchedJobIds) {
        $jobId = [string]$rawJobId
        if ([string]::IsNullOrWhiteSpace($jobId)) { continue }
        $status = $StatusMap[$jobId]
        if ([string]::IsNullOrWhiteSpace($status) -or $script:updateItemsTerminalStatuses -notcontains $status) {
            $inFlight++
        }
    }
    return $inFlight
}

function Invoke-UpdateItemsWebhookBatches {
    param(
        [Parameter(Mandatory = $true)] [string]$WebhookUrl,
        [Parameter(Mandatory = $true)] [string]$SiteUrl,
        [Parameter(Mandatory = $true)] [string]$LibraryGUID,
        [Parameter(Mandatory = $true)] [string]$LibraryTitle,
        [Parameter(Mandatory = $true)] [int]$BatchSize,
        [Parameter(Mandatory = $true)] [int]$MaxConcurrentJobs,
        [Parameter(Mandatory = $false)] [int]$PollIntervalSeconds = 30,
        [Parameter(Mandatory = $true)] [object]$Context,
        # Keeps the per-batch report and result files in SiteAssets after consolidation. Off by
        # default so each library ends up with exactly one item report and one content type report;
        # turn it on to inspect the intermediates when a consolidation looks wrong.
        [Parameter(Mandatory = $false)] [switch]$KeepBatchReports
    )

    $accessToken = Get-AzureADAccessToken `
        -tenantId $Context.AuthState.TenantId `
        -clientId $Context.AuthState.ClientId `
        -clientSecret $Context.AuthState.ClientSecret `
        -certificate $Context.AuthState.Certificate `
        -resourceUrl $SiteUrl
    Write-LogINFO "Retrieved Azure AD access token for site: $SiteUrl"
    $headers = @{ Authorization = "Bearer $accessToken"; Accept = "application/json;odata=verbose" }
    # Enumerate the ACTUAL item IDs rather than walking 1..maxId in BatchSize steps.
    # SharePoint never reuses an ID after a delete, so ID ranges are sparse: a library holding
    # 9,000 items can have a max ID of 45,388 and produce 46 batches by arithmetic, ~37 of which
    # have no items to process. Paging $select=ID is cheap (IDs only, 5,000 per page) and lets each
    # batch cover BatchSize real items, so the job count matches the work.
    #
    # Note on parsing: SharePoint's verbose JSON for list items carries both "ID" and "Id".
    # PowerShell 5.1's deserializer rejects keys differing only by case ("contains the duplicated
    # keys 'ID' and 'Id'") and Invoke-RestMethod then returns the RAW JSON STRING instead of an
    # object - which is why every library previously looked empty. Strip the collision and parse
    # explicitly, the same way getListItemsBatch/getAllListItems do.
    $itemIds = [System.Collections.Generic.List[int]]::new()
    $pageUrl = "$SiteUrl/_api/web/lists(guid'$LibraryGUID')/items?`$select=ID&`$orderby=ID&`$top=5000"
    $pageNumber = 0
    while (-not [string]::IsNullOrWhiteSpace($pageUrl)) {
        $page = Invoke-RestMethod -Uri $pageUrl -Headers $headers -Method Get -ErrorAction Stop
        if ($page -is [string]) { $page = $page.Replace('"Id"', '"_Id"') | ConvertFrom-Json }

        $rows = @()
        $nextUrl = $null
        if ($null -ne $page -and $null -ne $page.d -and $null -ne $page.d.results) {
            $rows = @($page.d.results)                      # odata=verbose
            $nextUrl = $page.d.__next
        }
        elseif ($null -ne $page -and $null -ne $page.value) {
            $rows = @($page.value)                          # odata=minimalmetadata / nometadata
            $nextUrl = $page.'odata.nextLink'
        }

        foreach ($row in $rows) {
            $idValue = $row.ID
            if ($null -eq $idValue) { $idValue = $row._Id }
            if ($null -ne $idValue) { $itemIds.Add([int]$idValue) }
        }

        $pageNumber++
        Write-LogINFO "Enumerated item ID page $pageNumber for '$LibraryTitle' ($($rows.Count) ID(s); running total $($itemIds.Count))."

        # Guard against a malformed page that yields no rows but still hands back a next link.
        $pageUrl = if ($rows.Count -gt 0) { $nextUrl } else { $null }
    }

    if ($itemIds.Count -eq 0) {
        # Never silently skip a library. Cross-check against ItemCount (a scalar endpoint with no
        # key collision): if the library really is empty, skipping is correct - but if it has items
        # and we still read none, the whole library would go unmigrated while the job reported
        # success, so fail loudly instead.
        $itemCount = -1
        try {
            $countResponse = Invoke-RestMethod -Uri "$SiteUrl/_api/web/lists(guid'$LibraryGUID')/ItemCount" `
                -Headers $headers -Method Get -ErrorAction Stop
            if ($countResponse -is [string]) { $countResponse = $countResponse | ConvertFrom-Json }
            if ($null -ne $countResponse.d -and $null -ne $countResponse.d.ItemCount) {
                $itemCount = [int]$countResponse.d.ItemCount
            }
            elseif ($null -ne $countResponse.value) {
                $itemCount = [int]$countResponse.value
            }
        }
        catch {
            Write-LogWarn "Could not read ItemCount for '$LibraryTitle': $($_.Exception.Message)"
        }

        if ($itemCount -gt 0) {
            throw "Enumerated 0 item IDs for library '$LibraryTitle' ($LibraryGUID), but ItemCount reports $itemCount item(s). Refusing to skip the library."
        }

        Write-LogINFO "Library '$LibraryTitle' has no items (ItemCount: $itemCount); no webhook batches created."
        return
    }

    $totalPlannedBatches = [Math]::Ceiling($itemIds.Count / [double]$BatchSize)
    Write-LogINFO "Library '$LibraryTitle': $($itemIds.Count) item(s), ID range $($itemIds[0])-$($itemIds[$itemIds.Count - 1]). Dispatching $totalPlannedBatches batch(es) of up to $BatchSize items."

    $subscriptionId = Get-UpdateItemsAutomationVariable -Name 'AutomationSubscriptionId'
    $resourceGroup = Get-UpdateItemsAutomationVariable -Name 'AutomationResourceGroup'
    $automationAccount = Get-UpdateItemsAutomationVariable -Name 'AutomationAccountName'
    if ([string]::IsNullOrWhiteSpace($subscriptionId) -or [string]::IsNullOrWhiteSpace($resourceGroup) -or [string]::IsNullOrWhiteSpace($automationAccount)) {
        throw "AutomationSubscriptionId, AutomationResourceGroup, and AutomationAccountName variables are required for webhook batch dispatch."
    }

    # Fetched through the cache on every use rather than once up front: dispatching tens of
    # batches while waiting on concurrency slots can outlive a single token's lifetime, and the
    # cache makes the repeated calls free until refresh is actually due.
    $armToken = Get-UpdateItemsManagedIdentityToken -Resource 'https://management.azure.com/'
    $jobIds = [System.Collections.Generic.List[string]]::new()
    $batchNumber = 0
    for ($offset = 0; $offset -lt $itemIds.Count; $offset += $BatchSize) {
        # Each batch spans the first and last REAL id in this chunk, so the child job's inclusive
        # StartId/EndId contract is unchanged while the chunk holds exactly BatchSize items.
        $lastIndex = [Math]::Min($offset + $BatchSize, $itemIds.Count) - 1
        $startId = $itemIds[$offset]
        $endId = $itemIds[$lastIndex]
        # Hold here until at least one of the in-flight jobs reaches a terminal state, so no more
        # than $MaxConcurrentJobs of our batch jobs ever run at once. The window slides: one
        # finishes, one goes out.
        do {
            $armToken = Get-UpdateItemsManagedIdentityToken -Resource 'https://management.azure.com/'
            $statusMap = Get-UpdateItemsJobStatusMap `
                -SubscriptionId $subscriptionId `
                -ResourceGroup $resourceGroup `
                -AutomationAccount $automationAccount `
                -AccessToken $armToken `
                -JobIds $jobIds.ToArray()
            $inFlightJobs = Get-UpdateItemsInFlightJobCount `
                -DispatchedJobIds $jobIds.ToArray() `
                -StatusMap $statusMap
            if ($inFlightJobs -ge $MaxConcurrentJobs) {
                Write-LogINFO "At capacity: $inFlightJobs/$MaxConcurrentJobs batch job(s) in flight; $($jobIds.Count) of $totalPlannedBatches dispatched. Waiting $PollIntervalSeconds s for a slot."
                Start-Sleep -Seconds $PollIntervalSeconds
            }
        } while ($inFlightJobs -ge $MaxConcurrentJobs)

        $batchNumber++
        $payload = @{
            operation    = 'UpdateItemsBatch'
            siteUrl      = $SiteUrl
            libraryGUID  = $LibraryGUID
            libraryTitle = $LibraryTitle
            startId      = $startId
            endId        = $endId
            batchNumber  = $batchNumber
        } | ConvertTo-Json -Depth 5 -Compress

        # Jobs we have already claimed are the only dedup set discovery needs. This used to list
        # every job in the account (now following every page) once per batch, which is a lot of ARM
        # traffic for information we already hold.
        $jobIdsBeforeDispatch = $jobIds.ToArray()
        $dispatchStartedAt = (Get-Date).ToUniversalTime()

        $responseObject = Invoke-UpdateItemsWebhookPost -WebhookUrl $WebhookUrl -Payload $payload
        $returnedJobIds = @()
        if ($null -ne $responseObject -and $responseObject -isnot [string]) {
            $returnedJobIds = @(
                $responseObject.JobIds
                $responseObject.jobIds
                $responseObject.jobId
                $responseObject.id
                if ($null -ne $responseObject.properties) { $responseObject.properties.jobId }
            ) | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | Select-Object -Unique
        }

        # Azure Automation commonly returns an empty 202 response for a webhook POST.
        # In that case discover the newly created job from the account-level jobs list,
        # matching the collection-based approach used by the existing UPS runbooks.
        if (@($returnedJobIds).Count -eq 0) {
            for ($discoveryAttempt = 1; $discoveryAttempt -le 6 -and @($returnedJobIds).Count -eq 0; $discoveryAttempt++) {
                Start-Sleep -Seconds 5
                $jobsAfterDispatch = Get-UpdateItemsAutomationJobs `
                    -SubscriptionId $subscriptionId `
                    -ResourceGroup $resourceGroup `
                    -AutomationAccount $automationAccount `
                    -AccessToken $armToken
                $returnedJobIds = @($jobsAfterDispatch | Where-Object {
                    if ($null -eq $_ -or $null -eq $_.properties -or $null -eq $_.properties.jobId) { return $false }
                    $jobId = [string]$_.properties.jobId
                    $createdTime = $null
                    try { $createdTime = [datetime]$_.properties.creationTime } catch { $createdTime = $null }
                    ($jobIdsBeforeDispatch -notcontains $jobId) -and
                    ($null -eq $createdTime -or $createdTime.ToUniversalTime() -ge $dispatchStartedAt.AddSeconds(-5))
                } | ForEach-Object { [string]$_.properties.jobId } | Select-Object -Unique)
            }
        }
        if ($returnedJobIds.Count -eq 0) {
            throw "Webhook did not return an Automation job ID for batch $batchNumber ($startId-$endId)."
        }
        foreach ($jobId in $returnedJobIds) { $jobIds.Add([string]$jobId) }
        Write-LogINFO "Webhook batch $batchNumber dispatched for '$LibraryTitle' (IDs $startId-$endId), job(s) $($returnedJobIds -join ', ')."
    }

    # Wait on explicit per-job status. The previous version inferred completion from absence in
    # the Running/Queued set, so a job that had not yet appeared - or that fell off an unpaged
    # snapshot - counted as finished and the dispatcher could declare success while batches were
    # still running.
    while ($true) {
        $armToken = Get-UpdateItemsManagedIdentityToken -Resource 'https://management.azure.com/'
        $statusMap = Get-UpdateItemsJobStatusMap `
            -SubscriptionId $subscriptionId `
            -ResourceGroup $resourceGroup `
            -AutomationAccount $automationAccount `
            -AccessToken $armToken `
            -JobIds $jobIds.ToArray()

        $failedSummary = @()
        foreach ($jobId in $jobIds) {
            $status = $statusMap[[string]$jobId]
            if (@('Failed', 'Stopped', 'Suspended', 'Blocked') -contains $status) {
                $failedSummary += "$($jobId): $status"
            }
        }
        if ($failedSummary.Count -gt 0) {
            throw "UpdateItems webhook job(s) failed: $($failedSummary -join ', ')"
        }

        $stillRunning = Get-UpdateItemsInFlightJobCount -DispatchedJobIds $jobIds.ToArray() -StatusMap $statusMap
        if ($stillRunning -eq 0) { break }

        Write-LogINFO "Waiting for $stillRunning of $($jobIds.Count) update-items webhook job(s) to complete..."
        Start-Sleep -Seconds $PollIntervalSeconds
    }
    Write-LogINFO "All $($jobIds.Count) webhook batches completed for '$LibraryTitle'."

    # Collect per-batch counts from the child jobs. Without this the master job has no idea how
    # much work actually happened - the children do the updating in their own sandboxes, so their
    # totals are only visible through their job output.
    $totalUpdated = 0
    $totalFailed = 0
    $batchesWithoutResult = @()
    $itemReportUrls = @()
    $ctReportUrls = @()
    $armToken = Get-UpdateItemsManagedIdentityToken -Resource 'https://management.azure.com/'

    # Re-acquire the SharePoint token. The one taken at dispatch time is an hour old by now - a
    # 36 batch library spent 51 minutes in the wait loop, and a larger one will exceed the lifetime
    # outright, so reading results with the original token would start failing as libraries grow.
    $resultToken = Get-AzureADAccessToken `
        -tenantId $Context.AuthState.TenantId `
        -clientId $Context.AuthState.ClientId `
        -clientSecret $Context.AuthState.ClientSecret `
        -certificate $Context.AuthState.Certificate `
        -resourceUrl $SiteUrl
    $resultHeaders = @{ Authorization = "Bearer $resultToken"; Accept = 'application/json;odata=verbose' }

    $batchNumberForJob = 0
    foreach ($jobId in $jobIds) {
        $batchNumberForJob++

        # Primary channel: the result file the child wrote to SiteAssets under a name we can compute.
        $resultFileName = Get-UpdateItemsBatchResultFileName -LibraryGUID $LibraryGUID -BatchNumber $batchNumberForJob
        $batchResult = Get-UpdateItemsBatchResultFile `
            -SiteUrl $SiteUrl `
            -Headers $resultHeaders `
            -FileName $resultFileName

        # Fallback: the marker on the job's output stream.
        if ($null -eq $batchResult) {
            Write-LogINFO "No result file '$resultFileName'; falling back to job output for $jobId."
            $batchResult = Get-UpdateItemsJobBatchResult `
                -SubscriptionId $subscriptionId `
                -ResourceGroup $resourceGroup `
                -AutomationAccount $automationAccount `
                -AccessToken $armToken `
                -JobId ([string]$jobId)
        }

        if ($null -eq $batchResult) {
            $batchesWithoutResult += [string]$jobId
            continue
        }

        $updated = 0; $failed = 0
        if ($null -ne $batchResult.updated) { $updated = [int]$batchResult.updated }
        if ($null -ne $batchResult.failed) { $failed = [int]$batchResult.failed }
        $totalUpdated += $updated
        $totalFailed += $failed
        if (-not [string]::IsNullOrWhiteSpace($batchResult.itemReportUrl)) { $itemReportUrls += [string]$batchResult.itemReportUrl }
        if (-not [string]::IsNullOrWhiteSpace($batchResult.ctReportUrl)) { $ctReportUrls += [string]$batchResult.ctReportUrl }
        Write-LogINFO "  Batch $($batchResult.batchNumber) (IDs $($batchResult.startId)-$($batchResult.endId)): $updated updated, $failed failed."
    }

    Write-LogINFO "=== Item update totals for '$LibraryTitle' ==="
    Write-LogINFO "  Items updated : $totalUpdated"
    Write-LogINFO "  Items failed  : $totalFailed"
    Write-LogINFO "  Batches       : $($jobIds.Count)"
    if ($batchesWithoutResult.Count -gt 0) {
        # Counts are understated rather than wrong - say so, so the totals are not read as complete.
        Write-LogWarn "  $($batchesWithoutResult.Count) job(s) reported no batch result, so these totals are incomplete: $($batchesWithoutResult -join ', ')"
    }

    # The children each wrote a report for their own slice - per-item detail for a six-figure
    # library cannot travel back through a job output stream. Merge those slices into one report
    # per library here, then remove the intermediates so SiteAssets holds a single file per report.
    $consolidatedItemReportUrl = $null
    $consolidatedCtReportUrl = $null
    $reportTimestamp = Get-Date -Format 'dd-MM-yyyy_HH-mm-ss'
    $safeLibraryTitle = ($LibraryTitle -replace '[^A-Za-z0-9._-]', '_')

    if ($itemReportUrls.Count -eq 0) {
        Write-LogWarn "  No item migration reports were produced by the batch jobs."
    }
    else {
        try {
            $consolidatedItemReportUrl = New-UpdateItemsConsolidatedItemReport `
                -SourceUrls $itemReportUrls -TargetSiteUrl $SiteUrl -Headers $resultHeaders `
                -TargetFileName "DMS-Item-Migration-Report-$safeLibraryTitle-$reportTimestamp.csv" `
                -Context $Context
            if ($consolidatedItemReportUrl) {
                Write-LogINFO "  Item migration report (library): $consolidatedItemReportUrl"
                if (-not $KeepBatchReports) {
                    $removed = 0
                    foreach ($reportUrl in $itemReportUrls) {
                        $location = Get-UpdateItemsSiteAssetLocation -Url $reportUrl
                        if ($null -ne $location -and (Remove-UpdateItemsSiteAssetFile -SiteUrl $location.SiteUrl -Headers $resultHeaders -FileName $location.FileName)) { $removed++ }
                    }
                    Write-LogINFO "  Removed $removed of $($itemReportUrls.Count) per-batch item report(s) (recoverable from the site recycle bin)."
                }
            }
        }
        catch {
            # Never fail a completed migration over reporting. The per-batch files still exist.
            Write-LogWarn "  Could not consolidate item migration reports: $($_.Exception.Message)"
            foreach ($reportUrl in $itemReportUrls) { Write-LogINFO "    $reportUrl" }
        }
    }

    if ($ctReportUrls.Count -gt 0) {
        try {
            $consolidatedCtReportUrl = New-UpdateItemsConsolidatedContentTypeReport `
                -SourceUrls $ctReportUrls -TargetSiteUrl $SiteUrl -Headers $resultHeaders `
                -TargetFileName "DMS-ContentType-Summary-Report-$safeLibraryTitle-$reportTimestamp.csv" `
                -Context $Context
            if ($consolidatedCtReportUrl) {
                Write-LogINFO "  Content type summary report (library): $consolidatedCtReportUrl"
                if (-not $KeepBatchReports) {
                    $removed = 0
                    foreach ($reportUrl in $ctReportUrls) {
                        $location = Get-UpdateItemsSiteAssetLocation -Url $reportUrl
                        if ($null -ne $location -and (Remove-UpdateItemsSiteAssetFile -SiteUrl $location.SiteUrl -Headers $resultHeaders -FileName $location.FileName)) { $removed++ }
                    }
                    Write-LogINFO "  Removed $removed of $($ctReportUrls.Count) per-batch content type report(s) (recoverable from the site recycle bin)."
                }
            }
        }
        catch {
            Write-LogWarn "  Could not consolidate content type summary reports: $($_.Exception.Message)"
            foreach ($reportUrl in $ctReportUrls) { Write-LogINFO "    $reportUrl" }
        }
    }

    # The per-batch result JSON files are plumbing, not output.
    if (-not $KeepBatchReports) {
        for ($resultBatchNumber = 1; $resultBatchNumber -le $jobIds.Count; $resultBatchNumber++) {
            $resultFileName = Get-UpdateItemsBatchResultFileName -LibraryGUID $LibraryGUID -BatchNumber $resultBatchNumber
            $null = Remove-UpdateItemsSiteAssetFile -SiteUrl $SiteUrl -Headers $resultHeaders -FileName $resultFileName
        }
    }

    return [PSCustomObject]@{
        LibraryTitle              = $LibraryTitle
        BatchCount                = $jobIds.Count
        UpdatedCount              = $totalUpdated
        FailedCount               = $totalFailed
        JobIds                    = $jobIds.ToArray()
        JobsWithoutResult         = $batchesWithoutResult
        ItemReportUrl             = $consolidatedItemReportUrl
        ContentTypeReportUrl      = $consolidatedCtReportUrl
        BatchItemReportUrls       = $itemReportUrls
        BatchContentTypeReportUrls = $ctReportUrls
    }
}