Function BooleanToString {
    param (
        [Parameter(Mandatory=$true)]
        [bool]$Value
    )
    if ($Value) {
        return "TRUE"
    } else {
        return "FALSE"
    }
}

Function BooleanToInt {
    param (
        [Parameter(Mandatory=$true)]
        [bool]$Value
    )
    if ($Value) {
        return 1
    } else {
        return 0
    }
}

Function getSiteType {
    param (
        [Parameter(Mandatory=$true)]
        [bool]$isDMS
    )
    if ($isDMS) {
        return "DMS"
    } else {
        return "E3"
    }
}