function ProvisionSite {
    param (
        [Parameter(Mandatory=$true)] [string] $tenant,
        [Parameter(Mandatory=$true)] [string] $owner,
        [Parameter(Mandatory=$true)] [string] $url,
        [Parameter(Mandatory=$true)] [string] $title,
        [Parameter(Mandatory=$true)] [string] $siteCollectionAdmin,
        [Parameter(Mandatory=$false)] [string] $template = "STS#3",
        [Parameter(Mandatory=$false)] [string] $storagequota = "1",
        [Parameter(Mandatory=$false)] [string] $clientId = "d4dfa3f9-88ac-4d83-af72-cc72ff128699",
        [Parameter(Mandatory=$false)] [string] $clientSecret = ""
    )

    # Connecting to the tenant using ACS OAuth (app-only authentication)
    try {
        Write-LogINFO "Connecting to the $tenant tenant as an admin"
        LogInToTenant -tenant $tenant -clientId $clientId -clientSecret $clientSecret
    }
    catch { throw }

    # Creating SharePoint site
    try {
        Write-LogINFO "Creating SharePoint site: $url"
        CreateSite -owner $owner -url $url -title $title -template $template -storagequota $storageQuota
    }
    catch { throw }

    # Adding Site collection admin
    try {
        Write-LogINFO "Adding Site collection admin: $siteCollectionAdmin"
        Set-SPOUser -site $url -LoginName $siteCollectionAdmin -IsSiteCollectionAdmin $true
    }
    catch { throw }

}

Function RemoveSiteCollectionAdmin($url, $siteCollectionAdmin) {
    try {
        Write-LogINFO "Removing Site collection admin: $siteCollectionAdmin"
        Set-SPOUser -site $url -LoginName $siteCollectionAdmin -IsSiteCollectionAdmin $false
    }
    catch { throw }
}

Function EnableSPOFeatures {
    param ($Context)

    try {
        # Enable document set feature
        EnableSPOFeature $Context "3bae86a2-776d-499d-9db8-fa4cdc7884f8"
        # Taxonomy feature
        EnableSPOFeature $Context "73EF14B1-13A9-416b-A9B5-ECECA2B0604C"
        # Document ID feature
        EnableSPOFeature $Context "b50e3104-6812-424f-a011-cc90e6327318"
    }
    catch {
        throw
    }

}


#Function to Enable Feature in SharePoint Online
Function EnableSPOFeature
{
    param ($Context, $FeatureGuid)
    try {
        $Site = $Context.Site

        #Check the Feature Status
        $FeatureStatus = $Site.Features.GetById($FeatureGuid)
        $FeatureStatus.Retrieve("DefinitionId")
        $Context.Load($FeatureStatus)
        ExecuteQueryWithRetry -Ctx $Context

        #sharepoint online activate feature using powershell (if its not enabled already)
        if($null -eq $FeatureStatus.DefinitionId) {
            Write-LogINFO "Enabling Feature $FeatureGuid..."
            $Site.Features.Add($FeatureGuid, $true, [Microsoft.SharePoint.Client.FeatureDefinitionScope]::None) | Out-Null
            ExecuteQueryWithRetry -Ctx $Context
            Write-LogINFO "Feature Enabled on site!"
        }
        else {
            Write-LogINFO "Feature is Already Active on the Site collection!"
        }
    }
    catch {
        throw
    }
}

Function SetSiteScripting() {
    param (
        [Parameter(Mandatory=$true)] [boolean] $isAllowed,
        [Parameter(Mandatory=$true)] [string] $url
    )
    try {
        Write-LogINFO "Allowing to customize site scripting/customizing: $isAllowed"
        $isAllowed = !$isAllowed
        Set-SPOSite $url -DenyAddAndCustomizePages $isAllowed
    }
    catch {
        Write-LogERR "Error while setting site scripting: $($_.Exception.Message)"
    }
}

Function CreateSite() {

    param (
        [Parameter(Mandatory=$true)] [string] $owner,
        [Parameter(Mandatory=$true)] [string] $url,
        [Parameter(Mandatory=$true)] [string] $title,
        [Parameter(Mandatory=$false)] [string] $template = "STS#3",
        [Parameter(Mandatory=$false)] [string] $storagequota = "1"
    )

    New-SPOSite `
        -Owner $owner `
        -StorageQuota $storagequota `
        -Url $url `
        -Title $title `
        -Template $template `
        -LocaleId 1033
}

function GetSiteLanguage ($context, $web) {
    # first try to search it in the property bag
    $customSiteLanguage = GetPropertyBag -Context $context -PropertyName "customSiteLanguage"
    if ($customSiteLanguage) {
        return $customSiteLanguage
    }
    # if not found then try the heuristic approach to detect the language based on Document_Class column Display name
    try {
        $fields = $Web.Fields
        $context.Load($fields)
        ExecuteQueryWithRetry -Ctx $Context
    }
    catch {
        write-loginfo -ErrorText "Unable to identify site language . $($_.Exception.Message)"
    }

    $DocumentClassField = $fields | Where-Object -FilterScript { $_.InternalName -eq "Document_class" }
    if ($null -eq $DocumentClassField) {
        $DocumentClassField = $fields | Where-Object -FilterScript { $_.InternalName -eq "DocumentClass" }
    }

    if ($null -eq $DocumentClassField) {
        $DisplayName = 'Document Class'
    }
    else {
        $DisplayName = $DocumentClassField.Title
    }

    $Language = ""

    switch ($DisplayName) {
        'Document Class' { $Language = "en-US" ; break; }
        'Classe de document' { $Language = "fr-FR"; break; }
        'Categoria del documento' { $Language = "es-ES" ; break; }
        'Tipo di documento' { $Language = "it-IT" ; break; }
        'Dokumentenkategorie' { $Language = "de-DE" ; break; }
        'Dokumentenklasse' { $Language = "de-DE" ; break; }
        default { $Language = "en-US" ; break; }
    }

    write-loginfo "Language identified for site is : $Language "

    return $Language
}

function InvokeGetSPOSiteWithRetry {
    param(
        [Parameter(Mandatory=$true)] [hashtable] $Params
    )
    $retryCount = 0
    $maxRetries = 5
    $delay = 5000

    while ($retryCount -lt $maxRetries) {
        try {
            return Get-SPOSite @Params
        }
        catch {
            $errorMessage = $_.Exception.Message
            $statusCode = $null
            if ($_.Exception.Response) {
                $statusCode = [int]$_.Exception.Response.StatusCode
            }
            if ($statusCode -eq 429 -or $errorMessage -like "*429*") {
                $retryAfter = $null
                if ($_.Exception.Response -and $_.Exception.Response.Headers) {
                    $retryAfter = $_.Exception.Response.Headers["Retry-After"]
                }
                if ($retryAfter) {
                    $delay = [int]$retryAfter * 1000
                }
                $retryCount++
                Write-LogINFO "Throttled (Get-SPOSite). Retrying in $delay milliseconds... (attempt $retryCount/$maxRetries)"
                Start-Sleep -Milliseconds $delay
                $delay = [Math]::Min($delay * 2, 60000)
            }
            else {
                throw
            }
        }
    }
    throw "Max retry attempts reached for Get-SPOSite."
}

function GetPrivateChannels {
    param(
        [Parameter(Mandatory=$true)] [string] $url,
        [Parameter(Mandatory=$true)] [Microsoft.SharePoint.Client.ClientContext] $context
    )

    try {
        Write-LogInfo "Discovering Teams private channels..."
        $PrivateChannels = @()
        $m365GroupId = (Get-SPOSite $url -Detailed).GroupId.Guid
        if ([string]::IsNullOrEmpty($m365GroupId) -or $m365GroupId -eq "00000000-0000-0000-0000-000000000000") {
            Write-LogInfo "M365 Group ID is null GUID. No private channels will be discovered."
            return $PrivateChannels
        }

        if ([string]::IsNullOrEmpty($m365GroupId) -or
            $m365GroupId -eq "00000000-0000-0000-0000-000000000000") {
            Write-LogInfo "Group ID is null or empty. No private channels to discover."
            return $PrivateChannels
        }
        $graphToken = Get-OAuthToken -Scope "https://graph.microsoft.com/.default" -authState $context.AuthState
        $headers = @{ Authorization = "Bearer $graphToken" }
        # ── List private channels scoped to this team only ────────────────────────
        $channelsUri = "https://graph.microsoft.com/v1.0/teams/$m365GroupId/channels" +
                       "?`$filter=membershipType eq 'private'"
        $channels    = (Invoke-RestMethod -Uri $channelsUri -Headers $headers -Method Get).value
        # ── Resolve each channel's SharePoint site URL via filesFolder ─────────────
        foreach ($channel in $channels) {
            $folderUri = "https://graph.microsoft.com/v1.0/teams/$m365GroupId" +
                         "/channels/$($channel.id)/filesFolder"
            $folder    = Invoke-RestMethod -Uri $folderUri -Headers $headers -Method Get

            if ($folder.webUrl) {
                # Trim folder webUrl down to the site-collection root
                # For non-standard managed paths, use $folder.parentReference.siteId instead:
                #   $graphSite = Invoke-RestMethod "https://graph.microsoft.com/v1.0/sites/$($folder.parentReference.siteId)" -Headers $headers
                #   $siteUrl   = $graphSite.webUrl
                $u       = [Uri]$folder.webUrl
                $siteUrl = "{0}://{1}/{2}/{3}" -f `
                    $u.Scheme, $u.Host, $u.Segments[1].TrimEnd('/'), $u.Segments[2].TrimEnd('/')

                $PrivateChannels += [PSCustomObject]@{ Url = $siteUrl }
            }
        }

        $count = $PrivateChannels.Count
        Write-LogInfo "Private Channels Count: $count"
        return $PrivateChannels
    }
    catch {
        Write-LogERR $_.Exception.Message
        throw
    }
}
function GetPrivateChannels_Old {
    param(
        [Parameter(Mandatory=$true)] [string] $url
    )

    try {
        Write-LogInfo "Connecting to tenant for private channels discovery..."
        # LogInToTenant -tenant $tenant -clientId $clientId -clientSecret $clientSecret

        Write-LogInfo "Discovering Teams private channels..."
        $PrivateChannels = @()
        $m365GroupId = (InvokeGetSPOSiteWithRetry @{ Identity = $url; Detailed = $true }).GroupId.Guid
        if ($m365GroupId -eq "00000000-0000-0000-0000-000000000000") {
            Write-LogInfo "M365 Group ID is null GUID. No private channels will be discovered."
            return $PrivateChannels
        }
        $SitesSet1 = InvokeGetSPOSiteWithRetry @{ Template = "TEAMCHANNEL#1"; Limit = "All" }
        $SitesSet0 = InvokeGetSPOSiteWithRetry @{ Template = "TEAMCHANNEL#0"; Limit = "All" }
        $PrivateChannelsSet1 = $SitesSet1 | Where-Object { ($_.RelatedGroupId -eq $m365GroupId) -and ($_.GroupId -eq "00000000-0000-0000-0000-000000000000") }
        for ($i = 0; $i -lt $PrivateChannelsSet1.Length; $i++) {
            $PrivateChannels += New-Object PSObject -Property ([ordered]@{
                    'Url' = $PrivateChannelsSet1[$i].Url
                })
        }
        $PrivateChannelsSet0 = $SitesSet0 | Where-Object { ($_.RelatedGroupId -eq $m365GroupId) -and ($_.GroupId -eq "00000000-0000-0000-0000-000000000000") }
        for ($i = 0; $i -lt $PrivateChannelsSet0.Length; $i++) {
            $PrivateChannels += New-Object PSObject -Property ([ordered]@{
                    'Url' = $PrivateChannelsSet0[$i].Url
                })
        }

        $count = $PrivateChannels.Count
        Write-LogInfo "Private Channels Count: $count"
        return $PrivateChannels
    }
    catch {
        # Caller will handle failures appropriately
        throw
    }
}

function GetRedirectedSiteUrl($siteUrl){
    $redirectedUrl = $siteUrl
    # Create a web request to the URL
    try {
        $response = Invoke-WebRequest -Uri $siteUrl -Method Head -MaximumRedirection 0 -ErrorAction SilentlyContinue -UseBasicParsing
        # Check if there is a Location header indicating a redirection
        if($response.StatusCode -eq 308 -and $null -ne $response.Headers["Location"]){
            $redirectedUrl = $response.Headers["Location"].TrimEnd('/')
        }
    }
    catch {
        Write-LogERR "Error accessing the site: $($_.Exception.Message)"
    }
    return $redirectedUrl
}

function GetParentTeamSiteUrl ($privateChannelUrl) {
    $uri = [Uri]$privateChannelUrl
    $lastSegment = $uri.Segments[-1].TrimEnd('/')

    # Split on the last '-' to separate team and channel
    $firstIndex = $lastSegment.IndexOf('-')
    $splitIndex = $lastSegment.IndexOf('-', $firstIndex + 1)
    if ($splitIndex -gt 0) {
        $teamName = $lastSegment.Substring(0, $splitIndex)
        $parentTeamSiteUrl = "$($uri.Scheme)://$($uri.Host)$($uri.AbsolutePath.Substring(0, $uri.AbsolutePath.LastIndexOf('/') + 1))$teamName"
        Write-LogInfo "Parent Team Site URL: $parentTeamSiteUrl"
        return $parentTeamSiteUrl
    } else {
        Write-LogInfo "Could not determine parent team site URL."
        return $null
    }
}