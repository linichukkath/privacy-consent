Function WriteSiteInfoToPropertyBag() {
    param (
        [Microsoft.SharePoint.Client.ClientContext] $context,
        [string] $siteType,
        [string] $eccs,
        [string] $version,
        $provisionedOn,
        $updatedOn,
        [string] $language,
        [string] $retentionPeriod,
        [string] $siteOwner,
        [string] $deputyAdmin,
        [string] $sensitivityClass,
        [string] $externalSharingStatus,
        [string] $originType,
        $dateUpgradedToDMS,
        $softDeletionDate
    )

    Write-LogINFO "Writing into property bag..."

    SetPropertyBag -Context $context -PropertyName 'customSiteType' -PropertyValue $siteType -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customECCS' -PropertyValue $eccs -Indexable $true

    $customSiteVersion = GetPropertyBag -Context $context -PropertyName 'customSiteVersion'
    if ($null -eq $customSiteVersion) {
        $customSiteVersion = "NA"
    }
    SetPropertyBag -Context $context -PropertyName 'customSitePreviousVersion' -PropertyValue $customSiteVersion -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customSiteVersion' -PropertyValue $version -Indexable $true

    if ($null -ne $provisionedOn) {
        SetPropertyBag -Context $context -PropertyName 'customSiteProvisionedOn' -PropertyValue $provisionedOn -Indexable $true
    }

    SetPropertyBag -Context $context -PropertyName 'customSiteUpdatedOn' -PropertyValue $updatedOn -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customSiteLanguage' -PropertyValue $language -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customRetentionPeriod' -PropertyValue $retentionPeriod -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customSiteOwner' -PropertyValue $siteOwner -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customDeputyAdmin' -PropertyValue $deputyAdmin -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customSensitivityClass' -PropertyValue $sensitivityClass -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customExternalSharingStatus' -PropertyValue $externalSharingStatus -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customOriginType' -PropertyValue $originType -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customDateUpgradedToDMS' -PropertyValue $dateUpgradedToDMS -Indexable $true
    SetPropertyBag -Context $context -PropertyName 'customSoftDeletionDate' -PropertyValue $softDeletionDate -Indexable $true
}

Function ListAllCustomPropertyBagItems($context) {
    $Web = $context.Web
    $context.Load($Web)
    $SiteProperties = $Web.AllProperties
    $context.Load($SiteProperties)
    ExecuteQueryWithRetry -Ctx $Context
    $PropertyBagKeys = $SiteProperties.FieldValues.Keys | Where-Object { $_ -like "custom*" }
    Write-LogINFO "Custom property bags:"
    Foreach ($Key in $PropertyBagKeys) {
        Write-LogINFO "$Key : $($SiteProperties[$Key])"
    }
}

function GetPropertyBag {
    param (
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [string] $PropertyName
    )
    $Web = $context.Web
    $context.Load($Web)
    $SiteProperties = $Web.AllProperties
    $context.Load($SiteProperties)
    ExecuteQueryWithRetry -Ctx $Context # -CallerInvocation $MyInvocation
    return $SiteProperties[$PropertyName]
}

function SetPropertyBag {
    param (
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [string] $PropertyName,
        [string] $PropertyValue = $null,
        [bool] $Indexable = $false
    )
    process {
        # Delegate to batch function for single property (ensures consistency)
        SetPropertyBagBatch -Context $Context -Properties @(@{
            Name = $PropertyName
            Value = $PropertyValue
            Indexable = $Indexable
        })
    }
}

<#
.SYNOPSIS
Batches multiple property bag writes into a single CSOM round-trip.

.DESCRIPTION
Sets multiple properties on the Web's AllProperties in a single ExecuteQueryWithRetry call.
Significantly improves performance when setting 3+ properties (e.g., 7 calls → 1 call).

.PARAMETER Context
The SharePoint client context.

.PARAMETER Properties
Array of hashtables with Name, Value, and Indexable keys.
Example: @(
    @{Name='customECCS'; Value='123'; Indexable=$true},
    @{Name='customSiteType'; Value='E3'; Indexable=$true}
)
#>
function SetPropertyBagBatch {
    param (
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Parameter(Mandatory = $true)] [hashtable[]] $Properties
    )
    process {
        if ($Properties.Count -eq 0) { return }

        $Web = $context.Web
        $context.Load($Web)
        $Context.Load($Web.AllProperties)
        ExecuteQueryWithRetry -Ctx $Context

        # Batch all property modifications
        $indexedPropertiesToAdd = @()
        foreach ($prop in $Properties) {
            $propertyName = $prop.Name
            $propertyValue = $prop.Value
            $isIndexable = $prop.Indexable

            # Remove existing property
            if ($Web.AllProperties.FieldValues.ContainsKey($propertyName)) {
                $web.AllProperties[$propertyName] = $null
                $Web.AllProperties.FieldValues.Remove($propertyName)
            }

            # Track indexable properties
            if ($isIndexable) {
                $propertyNameBytes = [System.Text.Encoding]::Unicode.GetBytes($propertyName)
                $encodedPropertyName = [Convert]::ToBase64String($propertyNameBytes)
                $indexedPropertiesToAdd += $encodedPropertyName
            }

            # Set new property value
            if ($null -ne $propertyValue) {
                $propertyValue = [string] $propertyValue
            }
            $Web.AllProperties[$propertyName] = $propertyValue
        }

        # Handle indexed property keys in batch
        if ($indexedPropertiesToAdd.Count -gt 0) {
            $indexedPropertyBagKey = "vti_indexedpropertykeys"
            $oldIndexedProperties = $Web.AllProperties.FieldValues[$indexedPropertyBagKey]
            if ($null -ne $oldIndexedProperties) {
                $oldIndexedProperties = $oldIndexedProperties.ToString()
            }
            else {
                $oldIndexedProperties = ""
            }

            foreach ($encodedName in $indexedPropertiesToAdd) {
                if ($oldIndexedProperties -notlike "*$encodedName*") {
                    $oldIndexedProperties += "$encodedName|"
                }
            }
            $Web.AllProperties[$indexedPropertyBagKey] = $oldIndexedProperties
        }

        # Single Update() and ExecuteQueryWithRetry
        $Web.Update()
        ExecuteQueryWithRetry -Ctx $Context
    }
}

function SetPropertyBagValues {
    param (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Parameter(Mandatory = $true)] [System.Collections.IDictionary] $Properties,
        [Parameter(Mandatory = $false)] [string[]] $IndexablePropertyNames = @()
    )

    $Web = $Context.Web
    $Context.Load($Web)
    $Context.Load($Web.AllProperties)
    ExecuteQueryWithRetry -Ctx $Context

    $removedExistingProperty = $false
    foreach ($propertyName in $Properties.Keys) {
        if ($Web.AllProperties.FieldValues.ContainsKey($propertyName)) {
            $Web.AllProperties[$propertyName] = $null
            $Web.AllProperties.FieldValues.Remove($propertyName)
            $removedExistingProperty = $true
        }
    }
    if ($removedExistingProperty) {
        $Web.Update()
        ExecuteQueryWithRetry -Ctx $Context
    }

    $indexedPropertyBagKey = "vti_indexedpropertykeys"
    $indexedProperties = $Web.AllProperties.FieldValues[$indexedPropertyBagKey]
    if ($null -eq $indexedProperties) {
        $indexedProperties = ""
    }
    else {
        $indexedProperties = $indexedProperties.ToString()
    }

    foreach ($propertyName in $Properties.Keys) {
        if ($IndexablePropertyNames -contains $propertyName) {
            $propertyNameBytes = [System.Text.Encoding]::Unicode.GetBytes($propertyName)
            $encodedPropertyName = [Convert]::ToBase64String($propertyNameBytes)
            if ($indexedProperties -notlike "*$encodedPropertyName*") {
                $indexedProperties = "$indexedProperties$encodedPropertyName|"
            }
        }

        $propertyValue = $Properties[$propertyName]
        if ($null -ne $propertyValue) {
            $propertyValue = [string] $propertyValue
        }
        $Web.AllProperties[$propertyName] = $propertyValue
    }

    $Web.AllProperties[$indexedPropertyBagKey] = $indexedProperties
    $Web.Update()
    ExecuteQueryWithRetry -Ctx $Context
}

function getRetentionPeriod($companyID) {
    $usCompanyIDs = @('US0003', 'US0006', 'US0009')
    if ($usCompanyIDs -contains $companyID) {
        return '7years'
    } else {
        return '6years'
    }
}

function mapParamsFromUPSToPropertyBag() {
    param (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $context,
        [Parameter(Mandatory = $true)] [psobject] $params
    )
    $siteType = getSiteType $params.IsDMS
    $retentionPeriod = getRetentionPeriod $params.CompanyID
    $siteOwner = $params.Admin1
    $deputyAdmin = $params.Admin2
    $sensitivityClass = $null
    $externalSharingStatus = $null
    if ($params.IsDMS) {
        $originType = 'DMS'
        $dateUpgradedToDMS = $null
    }
    else {
        $originType = 'E3'
        $dateUpgradedToDMS = (Get-Date)
    }
    $softDeletionDate = $null
    WriteSiteInfoToPropertyBag `
        -context $Context `
        -siteType $siteType `
        -eccs $params.CompanyID `
        -version 10 `
        -provisionedOn (Get-Date) `
        -updatedOn (Get-Date) `
        -language $params.Language `
        -retentionPeriod $retentionPeriod `
        -siteOwner $siteOwner `
        -deputyAdmin $deputyAdmin `
        -sensitivityClass $sensitivityClass `
        -externalSharingStatus $externalSharingStatus `
        -originType $originType `
        -dateUpgradedToDMS $dateUpgradedToDMS `
        -softDeletionDate $softDeletionDate

    ListAllCustomPropertyBagItems $Context
}
