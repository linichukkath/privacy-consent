# When loaded as part of the module, all dependencies are already imported by the .psm1
if (-not (Get-Module legacy-sites-update-runbook)) {
    Import-Module "$global:CurrDir\utils\fields\field.ps1"
    Import-Module "$global:CurrDir\utils\fields\choice.ps1"
    Import-Module "$global:CurrDir\utils\fields\boolean.ps1"
    Import-Module "$global:CurrDir\utils\fields\currency.ps1"
    Import-Module "$global:CurrDir\utils\fields\date-time.ps1"
    Import-Module "$global:CurrDir\utils\fields\managed-metadata.ps1"
    Import-Module "$global:CurrDir\utils\fields\note.ps1"
    Import-Module "$global:CurrDir\utils\fields\number.ps1"
    Import-Module "$global:CurrDir\utils\fields\text.ps1"
    Import-Module "$global:CurrDir\utils\fields\user.ps1"
    Import-Module "$global:CurrDir\utils\configuration-item.ps1"
}

Function ProvisionSiteColumns($Context, $Config, $Language, $CompanyId) {
    Write-LogINFO 'Provisioning site columns'
    $Columns = $Config.Columns
    $Fields = $Context.web.Fields
    $Context.Load($Fields)
    ExecuteQueryWithRetry -Ctx $Context
    ProcessSiteColumns -Context $Context -Columns $Columns -Fields $Fields -Language $Language -CompanyId $CompanyId
}

Function ProcessSiteColumns($Context, $Columns, $Fields, $Language, $CompanyId) {
    try {
        $ColumnDefinitions = Get-Content "$global:CurrDir\configs\columns.json" -Raw -encoding utf8 | ConvertFrom-Json
        foreach ($ColumnConfigItem in $Columns) {
            $Action = $ColumnConfigItem.Action
            $InternalName = $ColumnConfigItem.Key
            $ColumnConfig = $ColumnDefinitions.$InternalName;
            overrideSettings $ColumnConfig $ColumnConfigItem.Overrides

            switch ($Action) {
                "CREATE" {
                    CreateField $Context $ColumnConfig $Fields $Language $CompanyId
                }
                "UPDATE" {
                    UpdateField $Context $ColumnConfig $Fields $Language $CompanyId
                }
                "DELETE" {
                    # TODO
                }
                default {
                    throw "Invalid action type: $Action."
                }
            }

        }
    }
    catch {
        Write-LogERR "Error processing site columns " $_.Exception.Message
    }
}

# Util function for cleaning up the columns
Function DeleteColumns($Context, $Config) {
    $Columns = $Config.Columns

    $Fields = $Context.web.Fields
    $Context.Load($Fields)
    ExecuteQueryWithRetry -Ctx $Context

    foreach ($Column in $Columns) {
        # Get the site column by internal name
        $fieldInternalName = $Column.InternalName
        $field = $Fields.GetByInternalNameOrTitle($fieldInternalName)

        # Delete the site column
        $field.DeleteObject()
        ExecuteQueryWithRetry -Ctx $Context
        Write-LogINFO "Site column '$($Column.InternalName)' deleted successfully."
    }
}

Function RenameLegacyColumns($Context, $Config) {
    try {
        $Fields = $Context.web.Fields
        $Context.Load($Fields)
        ExecuteQueryWithRetry -Ctx $Context
        foreach($columnConfig in $Config.Columns){
            foreach($legacyColumnInternalName in $columnConfig.LegacyInternalNames){
                $legacyColumn = $Fields | Where-Object {$_.InternalName -eq $legacyColumnInternalName}
                if(($null -ne $legacyColumn) -and ($legacyColumn.Title -notlike "*_Legacy*")){
                    $legacyColumn.Title = $legacyColumn.Title + "_Legacy"
                    $legacyColumn.UpdateAndPushChanges($true)
                    ExecuteQueryWithRetry -Ctx $Context
                }
            }
        }
    }
    catch {
        Write-LogERR "Error renaming legacy columns " $_.Exception.Message
    }
}
Function GetManagedMetadataDefaultValue {
    param(
        [Parameter(Mandatory=$true)]
        [Microsoft.SharePoint.Client.ClientContext]$Context,
        [Parameter(Mandatory=$true)]
        [Microsoft.SharePoint.Client.List]$Library,
        [Parameter(Mandatory=$false)]
        $PreloadedFields = $null
    )
    try {
        Write-LogINFO "Retrieving managed metadata field default values from library: $($Library.Title)"
        $fields = $PreloadedFields
        if ($null -eq $fields) {
            $fields = $Library.Fields
            $Context.Load($fields)
            ExecuteQueryWithRetry -Ctx $Context
        }
        $defaultValues = @{}
        $taxonomyFields = $fields | Where-Object { 
            $_.TypeAsString -eq "TaxonomyFieldType" -or $_.TypeAsString -eq "TaxonomyFieldTypeMulti" 
        }

        # Cast + queue all taxonomy fields first, then resolve them in a single round-trip
        $castTaxFields = @{}
        foreach ($field in $taxonomyFields) {
            try {
                $taxField = [Microsoft.SharePoint.Client.ClientContext].GetMethod("CastTo").MakeGenericMethod([Microsoft.SharePoint.Client.Taxonomy.TaxonomyField]).Invoke($Context, $field)
                $Context.Load($taxField)
                $castTaxFields[$field.InternalName] = @{ Field = $field; TaxField = $taxField }
            } catch {
                Write-LogWARN "Failed to queue field '$($field.InternalName)' for load: $($_.Exception.Message)"
            }
        }
        if ($castTaxFields.Count -gt 0) {
            ExecuteQueryWithRetry -Ctx $Context
        }
        foreach ($key in $castTaxFields.Keys) {
            try {
                $field = $castTaxFields[$key].Field
                $taxField = $castTaxFields[$key].TaxField
                $defaultValue = $null
                if (-not [string]::IsNullOrEmpty($taxField.DefaultValue)) {
                    $defaultValue = $taxField.DefaultValue
                }
                $defaultValues[$field.InternalName] = [PSCustomObject]@{
                    InternalName = $field.InternalName
                    Title = $field.Title
                    DefaultValue = $defaultValue
                    AnchorId = $taxField.AnchorId
                    TermSetId = $taxField.TermSetId
                    IsMulti = ($field.TypeAsString -eq "TaxonomyFieldTypeMulti")
                }
            } catch {
                Write-LogWARN "Failed to retrieve default value for field '$key': $($_.Exception.Message)"
            }
        }
        Write-LogINFO "Retrieved default values for $($defaultValues.Count) managed metadata fields"
        return $defaultValues
    } catch {
        Write-LogERR "Error retrieving managed metadata default values: $($_.Exception.Message)"
        throw
    }
}