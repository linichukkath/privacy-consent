# Get Azure AD access token using client credentials (app-based authentication)
Function Get-AzureADAccessToken() {
    param(
        [Parameter(Mandatory)][string]$tenantId,
        [Parameter(Mandatory)][string]$clientId,
        [Parameter()][string]$clientSecret,
        [Parameter()][System.Security.Cryptography.X509Certificates.X509Certificate2]$certificate,
        [Parameter(Mandatory)][string]$resourceUrl
    )

    try {
        # Extract the SharePoint URL without the path
        $uri = [System.Uri]$resourceUrl
        $resource = "$($uri.Scheme)://$($uri.Host)"

        # Build MSAL configuration
        $authority = "https://login.microsoftonline.com/$tenantId"
        $scopes = @("$resource/.default")

        $clientApp = $null
        if ($certificate) {
            Write-LogINFO "Using certificate-based authentication..."
            Write-LogINFO "Certificate Thumbprint: $($certificate.Thumbprint)"
            $clientApp = [Microsoft.Identity.Client.ConfidentialClientApplicationBuilder]::Create($clientId).`
                WithCertificate($certificate).`
                WithAuthority($authority).`
                Build()
        }
        elseif ($clientSecret) {
            Write-LogINFO "Using client secret-based authentication..."
            $clientApp = [Microsoft.Identity.Client.ConfidentialClientApplicationBuilder]::Create($clientId).`
                WithClientSecret($clientSecret).`
                WithAuthority($authority).`
                Build()
        }
        else {
            throw "Either certificate or client secret must be provided"
        }

        # Acquire token
        Write-LogINFO "Acquiring access token from: $authority"
        Write-LogINFO "Scopes: $($scopes -join ', ')"
        $authResult = $clientApp.AcquireTokenForClient([string[]]$scopes).ExecuteAsync().GetAwaiter().GetResult()

        if (-not $authResult -or -not $authResult.AccessToken) {
            throw "Failed to acquire access token - null result"
        }

        Write-LogINFO "Access token acquired successfully (length: $($authResult.AccessToken.Length), expires: $($authResult.ExpiresOn))"
        return $authResult.AccessToken
    }
    catch {
        Write-LogERR "Failed to acquire access token: $_"
        Write-LogERR "Error type: $($_.Exception.GetType().FullName)"
        if ($_.Exception.InnerException) {
            Write-LogERR "Inner exception: $($_.Exception.InnerException.Message)"
        }
        throw
    }
}

Function GetSPOContext() {
    param(
        [Parameter(Mandatory)][string]$siteUrl,
        [Parameter(Mandatory)][string]$clientId,
        [Parameter()][string]$clientSecret,
        [Parameter(Mandatory)][string]$tenantId,
        [Parameter()][System.Security.Cryptography.X509Certificates.X509Certificate2]$certificate
    )

    try {
        $Context = New-Object Microsoft.SharePoint.Client.ClientContext($siteUrl)
        if (-not $Context) {
            throw "Failed to create ClientContext for $siteUrl"
        }

        Write-LogINFO "Acquiring access token for: $siteUrl"
        $accessToken = Get-AzureADAccessToken `
            -tenantId $tenantId `
            -clientId $clientId `
            -clientSecret $clientSecret `
            -certificate $certificate `
            -resourceUrl $siteUrl

        if (-not $accessToken) {
            throw "Failed to acquire access token for $siteUrl"
        }

        # Create a hashtable to store token and config for refresh capability
        $authState = @{
            Token = $accessToken
            TenantId = $tenantId
            ClientId = $clientId
            ClientSecret = $clientSecret
            Certificate = $certificate
            SiteUrl = $siteUrl
        }

        # Add as a property to the context so the event handler can access it
        $Context | Add-Member -MemberType NoteProperty -Name AuthState -Value $authState -Force

        # Add ExecutingWebRequest event handler to inject Bearer token
        $Context.add_ExecutingWebRequest({
            param($Source, $EventArgs)
            $state = $Source.AuthState
            if ($state -and $state.Token) {
                $EventArgs.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer $($state.Token)"
            }
            $EventArgs.WebRequestExecutor.WebRequest.UserAgent = "NONISV|Allianz|DMS/9"
        })

        # Add token refresh method
        $refreshScript = {
            Write-LogINFO "Refreshing access token for: $($this.AuthState.SiteUrl)"
            try {
                # Get the function from the parent scope
                $getTokenFunc = Get-Command Get-AzureADAccessToken -ErrorAction Stop

                $newToken = & $getTokenFunc `
                    -tenantId $this.AuthState.TenantId `
                    -clientId $this.AuthState.ClientId `
                    -clientSecret $this.AuthState.ClientSecret `
                    -certificate $this.AuthState.Certificate `
                    -resourceUrl $this.AuthState.SiteUrl

                if ($newToken -and $newToken.Length -gt 0) {
                    $this.AuthState.Token = $newToken
                    Write-LogINFO "Access token refreshed successfully (length: $($newToken.Length))"
                    return $true
                }
                else {
                    throw "Failed to acquire new token - empty or null token returned"
                }
            }
            catch {
                Write-LogERR "Failed to refresh access token: $_"
                Write-LogERR "Stack trace: $($_.ScriptStackTrace)"
                throw
            }
        }
        $Context | Add-Member -MemberType ScriptMethod -Name RefreshAccessToken -Value $refreshScript -Force

        Write-LogINFO "ClientContext created successfully with authentication"
        return $Context
    }
    catch {
        Write-LogERR "Error creating SPO context: $_"
        throw
    }
}

Function LogInToTenant() {
    param(
        [Parameter(Mandatory)][string]$tenant,
        [Parameter(Mandatory)][string]$clientId,
        [Parameter(Mandatory)][string]$tenantId,
        [Parameter()][System.Security.Cryptography.X509Certificates.X509Certificate2]$certificate,
        [Parameter()][string]$clientSecret
    )

    try {
        $adminUrl = "https://$($tenant)-admin.sharepoint.com"
        Write-LogINFO "Connecting to tenant admin: $adminUrl"

        if ($certificate) {
            Write-LogINFO "Using certificate-based authentication for tenant connection..."
            Write-LogINFO "Certificate Thumbprint: $($certificate.Thumbprint)"
            Connect-SPOService -Url $adminUrl -TenantId $tenantId -ClientId $clientId -Certificate $certificate
            Write-LogINFO "Successfully connected to tenant admin using certificate"
        }
        elseif ($clientSecret) {
            Write-LogINFO "Using client secret-based authentication for tenant connection..."
            # Get access token
            $accessToken = Get-AzureADAccessToken `
                -tenantId $tenantId `
                -clientId $clientId `
                -clientSecret $clientSecret `
                -certificate $null `
                -resourceUrl $adminUrl

            # Try to use access token with Connect-SPOService
            try {
                Connect-SPOService -Url $adminUrl -TenantId $tenantId -AccessToken $accessToken
                Write-LogINFO "Successfully connected to tenant admin using access token"
            }
            catch {
                Write-LogWarn "Connect-SPOService with AccessToken not supported, trying ClientSecret parameter..."
                $secureSecret = ConvertTo-SecureString -String $clientSecret -AsPlainText -Force
                Connect-SPOService -Url $adminUrl -ClientId $clientId -ClientSecret $secureSecret
                Write-LogINFO "Successfully connected to tenant admin using ClientSecret parameter"
            }
        }
        else {
            throw "Either certificate or client secret must be provided"
        }
    }
    catch {
        Write-LogERR "Error connecting to tenant: $_"
        throw
    }
}

Function auth($url, $siteCollectionAdminUserName, $tenant, $tenantAdminUserName) {
    try {
        Write-LogINFO "Creating context for: $url"

        # Get configuration
        $clientId = "d4dfa3f9-88ac-4d83-af72-cc72ff128699"
        $clientSecret = ""
        $tenantId = "6e06e42d-6925-47c6-b9e7-9581c7ca302a"

        # Try to get certificate from Azure Automation
        $certificate = $null
        try {
            $certificate = Get-AutomationCertificate -Name "pfx" -ErrorAction Stop
            Write-LogINFO "Certificate retrieved from Azure Automation (Thumbprint: $($certificate.Thumbprint))"
        }
        catch {
            Write-LogWarn "Certificate not available: $_. Will use client secret."
        }

        # Create context
        $context = GetSPOContext `
            -siteUrl $url `
            -clientId $clientId `
            -clientSecret $clientSecret `
            -tenantId $tenantId `
            -certificate $certificate

        # Verify connection
        Write-LogINFO "Loading Web object to verify connectivity..."
        $context.Load($context.Web)
        ExecuteQueryWithRetry -Ctx $context
        Write-LogINFO "Successfully authenticated - Web title: $($context.Web.Title)"

        return $context
    }
    catch {
        Write-LogERR "Error authenticating to the site ${url}: $_"
        return $null
    }
}

Function decorateContextHeaders() {
    param(
        [Parameter(Mandatory)][Microsoft.SharePoint.Client.ClientContext]$context
    )
    # User-Agent header is already added in GetSPOContext
    # This function is kept for backward compatibility
}

Function GetTenantAdminContext() {
    <#
    .SYNOPSIS
        Creates CSOM context for tenant admin site
    #>
    param(
        [Parameter(Mandatory)][string]$tenant,
        [Parameter(Mandatory)][string]$clientId,
        [Parameter(Mandatory)][string]$tenantId,
        [Parameter()][string]$clientSecret,
        [Parameter()][System.Security.Cryptography.X509Certificates.X509Certificate2]$certificate
    )
    try {
        $adminUrl = "https://$($tenant)-admin.sharepoint.com"
        Write-LogINFO "Creating tenant admin context: $adminUrl"

        $context = GetSPOContext `
            -siteUrl $adminUrl `
            -clientId $clientId `
            -clientSecret $clientSecret `
            -tenantId $tenantId `
            -certificate $certificate

        Write-LogINFO "Tenant admin context created successfully"
        return $context
    }
    catch {
        Write-LogERR "Failed to create tenant admin context: $($_.Exception.Message)"
        throw
    }
}

Function SetSiteCollectionAdmin() {
    <#
    .SYNOPSIS
        Sets site collection admin using SPO Management Shell
    #>
    param(
        [Parameter(Mandatory)][string]$siteUrl,
        [Parameter(Mandatory)][string]$userLoginName,
        [Parameter(Mandatory)][bool]$isSiteAdmin
    )
    try {
        Write-LogINFO "Setting site collection admin: $userLoginName to $isSiteAdmin for $siteUrl"
        Set-SPOUser -Site $siteUrl -LoginName $userLoginName -IsSiteCollectionAdmin $isSiteAdmin -ErrorAction Stop
        Write-LogINFO "Successfully set site collection admin status"
    }
    catch {
        Write-LogERR "Failed to set site collection admin: $($_.Exception.Message)"
        throw
    }
}

Function RefreshAccessToken() {
    <#
    .SYNOPSIS
        Refreshes the access token for a SharePoint context
    .DESCRIPTION
        Gets a new access token and updates the context's stored token
    #>
    param(
        [Parameter(Mandatory)][Microsoft.SharePoint.Client.ClientContext]$context
    )
    try {
        if (-not $context.AuthState) {
            Write-LogERR "Context does not contain authentication state. Cannot refresh token."
            return $false
        }

        Write-LogINFO "Refreshing access token for site: $($context.AuthState.SiteUrl)"

        $newToken = Get-AzureADAccessToken `
            -tenantId $context.AuthState.TenantId `
            -clientId $context.AuthState.ClientId `
            -clientSecret $context.AuthState.ClientSecret `
            -certificate $context.AuthState.Certificate `
            -resourceUrl $context.AuthState.SiteUrl

        if ($newToken -and $newToken.Length -gt 0) {
            $context.AuthState.Token = $newToken
            Write-LogINFO "Access token refreshed successfully"
            return $true
        }
        else {
            Write-LogERR "Failed to acquire new token - empty or null token returned"
            return $false
        }
    }
    catch {
        Write-LogERR "Failed to refresh access token: $($_.Exception.Message)"
        return $false
    }
}

Function Get-ConfigFileByUrl() {
    <#
    .SYNOPSIS
        Determines which config file to use based on site URL pattern
    .DESCRIPTION
        Returns "localhost-config.json" for production sites or "localhost-config-test.json" for test sites
    #>
    param(
        [Parameter(Mandatory)][string]$siteUrl
    )
    
    try {
        if ($siteUrl -match "https://(allianzms|allianzmsemea)\.sharepoint\.com") {
            Write-LogINFO "Site URL matches production tenant pattern - using localhost-config.json"
            return "localhost-config.json"
        }
        elseif ($siteUrl -match "https://(allianzmstest|allianzmstestemea)\.sharepoint\.com") {
            Write-LogINFO "Site URL matches test tenant pattern - using localhost-config-test.json"
            return "localhost-config-test.json"
        }
        else {
            Write-LogWarn "Site URL does not match known patterns. Using default localhost-config.json"
            return "localhost-config.json"
        }
    }
    catch {
        Write-LogERR "Error determining config file: $_"
        return "localhost-config.json"
    }
}

Function Load-ConfigByUrl() {
    <#
    .SYNOPSIS
        Loads configuration from appropriate config file based on site URL
    .DESCRIPTION
        Returns a hashtable with Tenant, TenantId, ClientId, ClientSecret, CertificatePath, CertificatePassword
    #>
    param(
        [Parameter(Mandatory)][string]$siteUrl
    )
    
    try {
        $configPath = Get-ConfigFileByUrl -siteUrl $siteUrl
        
        if (-not (Test-Path $configPath)) {
            throw "Config file not found: $configPath"
        }
        
        Write-LogINFO "Loading configuration from: $configPath"
        $config = Get-Content $configPath -Raw | ConvertFrom-Json
        
        # Validate required fields
        $requiredFields = @("Tenant", "TenantId", "ClientId")
        foreach ($field in $requiredFields) {
            if ([string]::IsNullOrEmpty($config.$field)) {
                throw "Required field '$field' is missing or empty in config file"
            }
        }
        
        Write-LogINFO "Configuration loaded successfully from: $configFileName"
        Write-LogINFO "  Tenant: $($config.Tenant)"
        Write-LogINFO "  Client ID: $($config.ClientId)"
        
        return $config
    }
    catch {
        Write-LogERR "Failed to load config: $_"
        throw
    }
}

Function Get-ConfigFileByUrl() {
    <#
    .SYNOPSIS
        Determines which config file to use based on the SharePoint site URL
    .DESCRIPTION
        Returns the path to the appropriate config file:
        - localhost-config.json for production URLs (allianzms*)
        - localhost-config-test.json for test URLs (allianzmstest*)
    .PARAMETER SiteUrl
        The SharePoint site URL to check
    .PARAMETER ConfigDir
        The directory containing config files (default: configs subfolder of $global:CurrDir)
    .OUTPUTS
        [string] - The full path to the appropriate config file
    #>
    param(
        [Parameter(Mandatory)][string]$SiteUrl,
        [Parameter()][string]$ConfigDir = $null
    )

    try {
        if ([string]::IsNullOrEmpty($ConfigDir)) {
            $ConfigDir = Join-Path $global:CurrDir 'configs'
        }

        $host = ([System.Uri]$SiteUrl).Host

        # Determine if this is a test or production URL.
        # Supports regional and environment suffixes such as:
        # allianzmstestaus.sharepoint.com, allianzmstestemea.sharepoint.com,
        # allianzmsaus.sharepoint.com, allianzmsemea.sharepoint.com, etc.
        if ($host -match '^allianzmstest[a-z0-9-]*\.sharepoint\.com$') {
            $configFile = Join-Path $ConfigDir 'localhost-config-test.json'
            Write-LogINFO "Test environment detected - using config file: $configFile"
        }
        elseif ($host -match '^allianzms(?!test)[a-z0-9-]*\.sharepoint\.com$') {
            $configFile = Join-Path $ConfigDir 'localhost-config.json'
            Write-LogINFO "Production environment detected - using config file: $configFile"
        }
        else {
            throw "Unable to determine environment from URL. Expected host pattern: allianzmstest*.sharepoint.com or allianzms*.sharepoint.com"
        }

        if (-not (Test-Path $configFile)) {
            throw "Config file not found: $configFile"
        }

        return $configFile
    }
    catch {
        Write-LogERR "Error determining config file: $_"
        throw
    }
}

Function Get-AuthenticationConfigFromFile() {
    <#
    .SYNOPSIS
        Loads authentication credentials from a config file
    .DESCRIPTION
        Reads the specified config file and returns authentication credentials
        Returns a hashtable with: Tenant, TenantId, ClientId, ClientSecret, CertificatePath, CertificatePassword
    .PARAMETER ConfigFile
        The full path to the config file to load
    .OUTPUTS
        [hashtable] - Authentication configuration from the file
    #>
    param(
        [Parameter(Mandatory)][string]$ConfigFile
    )

    try {
        if (-not (Test-Path $ConfigFile)) {
            throw "Config file not found: $ConfigFile"
        }

        Write-LogINFO "Loading authentication config from: $ConfigFile"
        $config = Get-Content $ConfigFile -Raw | ConvertFrom-Json

        # Validate required fields
        $requiredFields = @('Tenant', 'TenantId', 'ClientId')
        foreach ($field in $requiredFields) {
            if (-not ($config | Get-Member -Name $field)) {
                throw "Required field missing in config: $field"
            }
            if ([string]::IsNullOrEmpty($config.$field)) {
                throw "Required field is empty in config: $field"
            }
        }

        Write-LogINFO "Config loaded successfully"
        Write-LogINFO "  Tenant: $($config.Tenant)"
        Write-LogINFO "  TenantId: $($config.TenantId)"
        Write-LogINFO "  ClientId: $($config.ClientId)"
        if ($config.CertificatePath) {
            Write-LogINFO "  CertificatePath: $($config.CertificatePath)"
        }

        return $config
    }
    catch {
        Write-LogERR "Error loading authentication config: $_"
        throw
    }
}

Function Get-AuthenticationCredentials() {
    <#
    .SYNOPSIS
        Gets authentication credentials for a given site URL
    .DESCRIPTION
        Determines the appropriate config file based on site URL and loads the credentials.
        Returns a hashtable with authentication parameters ready for use with SharePoint functions.
    .PARAMETER SiteUrl
        The SharePoint site URL
    .OUTPUTS
        [hashtable] - With keys: Tenant, TenantId, ClientId, ClientSecret, Certificate, CertificatePath, CertificatePassword
    #>
    param(
        [Parameter(Mandatory)][string]$SiteUrl
    )

    try {
        Write-LogINFO "Determining authentication config for site: $SiteUrl"
        
        # Determine which config file to use
        $configFile = Get-ConfigFileByUrl -SiteUrl $SiteUrl
        
        # Load the config
        $authConfig = Get-AuthenticationConfigFromFile -ConfigFile $configFile
        
        # Prepare the credentials hashtable
        $credentials = @{
            Tenant = $authConfig.Tenant
            TenantId = $authConfig.TenantId
            ClientId = $authConfig.ClientId
            ClientSecret = $authConfig.ClientSecret
            CertificatePath = $authConfig.CertificatePath
            CertificatePassword = $authConfig.CertificatePassword
            Certificate = $null
        }

        Write-LogINFO "Authentication credentials prepared for tenant: $($credentials.Tenant)"
        return $credentials
    }
    catch {
        Write-LogERR "Error getting authentication credentials: $_"
        throw
    }
}
function Get-OAuthToken {
    param(
        [Parameter(Mandatory=$true)] [string] $Scope,
        [Parameter(Mandatory=$true)] [hashtable] $authState
    )
    $response = Invoke-RestMethod `
        -Uri    "https://login.microsoftonline.com/$($authState.TenantId)/oauth2/v2.0/token" `
        -Method Post `
        -Body   @{
            grant_type    = "client_credentials"
            client_id     = $authState.ClientId
            client_secret = "DLX8Q~yxmmOGCR2tYQJF85XrlTHT-OyT-g_88afB"
            scope         = $Scope
        }
    write-LogINFO "OAuth token acquired for scope: $Scope (length: $($response.access_token.Length))"   
    return $response.access_token
}

