# When loaded as part of the module, all dependencies are already imported by the .psm1
if (-not (Get-Module legacy-sites-update-runbook)) {
    Import-Module "$global:CurrDir\utils\selectors.ps1"
    Import-Module "$global:CurrDir\utils\configuration-item.ps1"
}

Function ProvisionLibraries($Context, $Config, $Language) {
    Write-LogINFO 'Provisioning libraries'
    $Libraries = $Config.Libraries
    $LibraryDefinitions = Get-Content "$global:CurrDir\configs\libraries.json" -Raw -encoding utf8 | ConvertFrom-Json
    $ViewDefinitions = Get-Content "$global:CurrDir\configs\views.json" -Raw -encoding utf8 | ConvertFrom-Json
    OverrideViewSettings $ViewDefinitions $Config.Views
    $DefaultLibraryEntityTypeName = "Shared_x0020_Documents"
    foreach ($LibraryConfigItem in $Libraries) {
        $Action = $LibraryConfigItem.Action
        $EntityTypeName = $LibraryConfigItem.Key # TODO work with Ids
        $LibraryConfig = $LibraryDefinitions.$EntityTypeName;
        overrideSettings $LibraryConfig $LibraryConfigItem.Overrides

        switch ($Action) {
            "CREATE" {

            }
            "UPDATE" {
                UpdateLibrary -context $Context -LibraryConfig $LibraryConfig -Library $null -DefaultLibraryEntityTypeName $DefaultLibraryEntityTypeName -ViewDefinitions $ViewDefinitions -ViewsConfig $Config.Views -Language $Language
            }
            "DELETE" {

            }
            default {
                throw "Invalid action type: $Action."
            }
        }
    }
}

Function UpdateLibrary() {
    param (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $context,
        [Parameter(Mandatory = $true)] [Object] $LibraryConfig,
        [Parameter(Mandatory = $false)] [Microsoft.SharePoint.Client.List] $Library,
        [Parameter(Mandatory = $true)] [string] $DefaultLibraryEntityTypeName,
        [Parameter(Mandatory = $true)] [psobject] $ViewDefinitions,
        [Parameter(Mandatory = $true)] [psobject] $ViewsConfig,
        [Parameter(Mandatory = $true)] [string] $Language,
        [Parameter(Mandatory = $false)] [hashtable] $DefaultColumnValues
    )
    try {
        if ($null -eq $Library) {
            $Library = GetListByEntityTypeName $Context $LibraryConfig.EntityTypeName
        }
        if ($Library.EntityTypeName -eq $DefaultLibraryEntityTypeName) {
            # update only Documents library title
            UpdateLibraryName -context $Context -Library $Library -NewName $LibraryConfig.Name.$Language
        }

        # Content Types
        $ContentTypeDefinitions = Get-Content "$global:CurrDir\configs\content-types.json" -Raw -encoding utf8 | ConvertFrom-Json

        #Get all existing content types of the list
        $ListContentTypes = $Library.ContentTypes
        $Context.Load($ListContentTypes)

        #Get the content type to Add to list
        $SiteContentTypes = $Context.Web.ContentTypes
        $Context.Load($SiteContentTypes)
        ExecuteQueryWithRetry -Ctx $Context

        foreach($ListContentType in $ListContentTypes) {
            $Context.Load($ListContentType.Parent)
        }
        ExecuteQueryWithRetry -Ctx $Context

        foreach ($ContentType in $LibraryConfig.ContentTypes) {
            AddContentTypeToList -context $Context -Library $Library -ContentTypeId $ContentType.Id -ContentTypeDefinitions $ContentTypeDefinitions -ListContentTypes $ListContentTypes -SiteContentTypes $SiteContentTypes
        }

        # Views
        CreateOrReplaceViews -context $Context -Library $Library -ViewDefinitions $ViewDefinitions -ViewsConfig $ViewsConfig -Language $Language

        # Set up the new button menu
        AddTemplateToNewButton -Context $Context -Library $Library -ListContentTypesConfig $LibraryConfig.ContentTypes

        # Deleting columns
        deleteColumnsFromLibrary -Context $Context -LibraryConfig $LibraryConfig -Library $Library

        #Hide unwanted columns in Document content type at library level
        HideColumns -Context $Context -LibraryConfig $LibraryConfig -Library $Library

        UpdateContentTypeOrder -Context $Context -LibraryConfig $LibraryConfig -Library $Library -LibraryContentTypes $ListContentTypes

        #Restore managed metadata field default values at library level
        if ($null -ne $DefaultColumnValues) {
            RestoreManagedMetadataDefaultValues -Context $context -Library $library -DefaultColumnValues $DefaultColumnValues
        }
    }
    catch {
        Write-LogERR "Error updating library '$($Library.Title)': $($_.Exception.Message)"
    }
}

Function RestoreManagedMetadataDefaultValues {
    param(
        [Parameter(Mandatory=$true)]
        [Microsoft.SharePoint.Client.ClientContext]$Context,
        [Parameter(Mandatory=$true)]
        [Microsoft.SharePoint.Client.List]$Library,
        [Parameter(Mandatory=$true)]
        [hashtable]$DefaultColumnValues
    )
    try {
        Write-LogINFO "Restoring managed metadata field default values to library: $($Library.Title)"
        $fields = $Library.Fields
        $Context.Load($fields)
        ExecuteQueryWithRetry -Ctx $Context
        $restoredCount = 0
        foreach ($fieldName in $DefaultColumnValues.Keys) {
            $fieldInfo = $DefaultColumnValues[$fieldName]
            # Skip if no default value was stored
            if ([string]::IsNullOrEmpty($fieldInfo.DefaultValue)) {
                Write-LogINFO "  - Skipping $($fieldName): no default value to restore"
                continue
            }
            try {
                $field = $fields | Where-Object { $_.InternalName -eq $fieldName }
                if ($null -eq $field) {
                    Write-LogWARN "  - Field '$fieldName' not found in library"
                    continue
                }
                $taxField = [Microsoft.SharePoint.Client.ClientContext].GetMethod("CastTo").MakeGenericMethod([Microsoft.SharePoint.Client.Taxonomy.TaxonomyField]).Invoke($Context, $field)
                $Context.Load($taxField)
                ExecuteQueryWithRetry -Ctx $Context
                $taxField.DefaultValue = $fieldInfo.DefaultValue
                $taxField.Update()
                ExecuteQueryWithRetry -Ctx $Context
                Write-LogINFO "  - Restored default value for '$($fieldName)': $($fieldInfo.DefaultValue)"
                $restoredCount++
            } catch {
                Write-LogWARN "  - Failed to restore default value for field '$fieldName': $($_.Exception.Message)"
            }
        }
        Write-LogINFO "Successfully restored default values for $restoredCount managed metadata field(s)"
    } catch {
        Write-LogERR "Error restoring managed metadata default values: $($_.Exception.Message)"
        throw
    }
}

Function UpdateContentTypeOrder() {
    param (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $context,
        [Parameter(Mandatory = $true)] [psobject] $LibraryConfig,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $Library,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ContentTypeCollection] $LibraryContentTypes
    )
    $newContentTypeOrder = New-Object System.Collections.Generic.List[Microsoft.SharePoint.Client.ContentTypeId]
    $orderedContentTypes = @()
    if ($LibraryContentTypes.Count -gt 0) {
        $defaultContentType = $LibraryContentTypes[0]
        if ($null -ne $defaultContentType) {
            $orderedContentTypes += $defaultContentType
        }
    }
    foreach ($ContentType in $LibraryConfig.ContentTypes) {
        $ctTobeAdded = $LibraryContentTypes | Where-Object { $_.Parent.Id.StringValue -eq $ContentType.Id }
        if ($null -ne $ctTobeAdded -and $orderedContentTypes -notcontains $ctTobeAdded) {
            $orderedContentTypes += $ctTobeAdded
        }
    }
    foreach ($ct in $orderedContentTypes) {
        $newContentTypeOrder.Add($ct.Id)
    }
    $Library.RootFolder.UniqueContentTypeOrder = $newContentTypeOrder
    $Library.RootFolder.Update()
    ExecuteQueryWithRetry -Ctx $Context
}

Function CreateOrReplaceViews() {
    param (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $context,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $Library,
        [Parameter(Mandatory = $true)] [psobject] $ViewDefinitions,
        [Parameter(Mandatory = $true)] [psobject] $ViewsConfig,
        [Parameter(Mandatory = $true)] [string] $Language
    )
    foreach ($ViewConfig in $ViewsConfig) {
        $Key = $ViewConfig.Key
        $Action = $ViewConfig.Action
        $View = $ViewDefinitions.$Key;

        if ($Action -eq "DELETE") {
            try {
                $ViewToBeDeleted = $Library.Views | Where-Object { $_.Title -eq $View.Name.$Language}
                if($null -ne $ViewToBeDeleted) {
                    Write-LogINFO "Deleting legacy view '$($View.Name.$Language)' from the library '$($Library.Title)'"
                    $ViewToBeDeleted.DeleteObject()
                    ExecuteQueryWithRetry -Ctx $Context
                    Write-LogINFO "Deleted"
                }
            } catch {
                Write-LogERR "Error deleting view '$($View.Name.$Language)' from the library '$($Library.Title)'! $($_.Exception.Message)"
            }
            continue
        }

        $Recursive = $false
        if ($View.Recursive) { $Recursive = $true } # TODO I dont know why the function doesn't want to accept it

        CreateOrReplaceListView `
            -context $Context `
            -Library $Library `
            -ViewName $View.Name.$Language `
            -ViewFields $View.Fields `
            -ViewQuery $View.Query.$Language `
            -ItemLimit $View.ItemLimit `
            -IsDefaultView $View.IsDefaultView `
            -CustomFormat $View.CustomFormat `
            -Recursive $Recursive
    }
}

function deleteColumnsFromLibrary() {
    param(
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Parameter(Mandatory = $true)] [psobject] $LibraryConfig,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $Library
    )
    if ($null -eq $LibraryConfig.DeleteColumns) {
        return
    }
    try{
        $Context.Load($Library.Fields)
        ExecuteQueryWithRetry -Ctx $Context
        $columnsToDelete = @()
        foreach ($ColumnInternalName in $LibraryConfig.DeleteColumns) {
            $Column = $Library.Fields | Where-Object { $_.InternalName -eq $ColumnInternalName}
            if ($null -ne $Column -and $null -ne $Column.InternalName) {
                $columnsToDelete += $Column
            }
        }
        foreach ($Column in $columnsToDelete) {
            if ($Column.CanBeDeleted -and -not $Column.Sealed) {
                $Column.DeleteObject()
                Write-LogINFO "Deleting '$($Column.InternalName)' from the '$($LibraryConfig.Name.$Language)' library"
            }
        }
        if ($columnsToDelete.Count -gt 0) {
            ExecuteQueryWithRetry -Ctx $Context
            Write-LogINFO "Deleted unwanted columns from the Library '$($Library.Title)'!"
        }
    }
    Catch {
        Write-LogERR "Error removing unwanted columns from library '$($Library.Title)'!" $_.Exception.Message
    }

}

function removeLegacyColumnsFromLibrary() {
    param(
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $Library
    )
    try {
        $Context.Load($Library.Fields)
        ExecuteQueryWithRetry -Ctx $Context
        $legacyColumns = $Library.Fields | Where-Object { $_.Title -like "*_Legacy"}
        foreach ($Column in $legacyColumns){
            if ($null -ne $Column.InternalName) {
                $Column.DeleteObject()
                Write-LogINFO "Deleting '$($ColumnInternalName)' from the '$($LibraryConfig.Name.$Language)' library"
            }
        }
        ExecuteQueryWithRetry -Ctx $Context
        Write-LogINFO "Deleted legacy columns from Library - $($Library.Title)"
    }
    catch {
        Write-LogERR "Error deleting legacy columns from library - $($Library.Title)" $_.Exception.Message
    }
}


Function UpdateLibraryName() {
    param
    (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $context,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $Library,
        [Parameter(Mandatory = $true)] [string] $NewName
    )

    Try {
        $OldName = $Library.Title
        $Library.Title = $NewName
        $Library.Update()
        ExecuteQueryWithRetry -Ctx $Context

        Write-LogINFO "Library name '$($OldName)' renamed to '$($NewName)' successfully!"
    }
    Catch {
        Write-LogERR "Error updating library name '$($OldName)'!" $_.Exception.Message
    }
}

Function AddContentTypeToList() {
    param
    (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $context,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $Library,
        [Parameter(Mandatory = $true)] [string] $ContentTypeId,
        [Parameter(Mandatory = $true)] [PSCustomObject] $ContentTypeDefinitions,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ContentTypeCollection] $ListContentTypes,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ContentTypeCollection] $SiteContentTypes
    )

    Try {

        #Enable managemnt of content type in list - if its not enabled already
        If ($Library.ContentTypesEnabled -ne $True) {
            $Library.ContentTypesEnabled = $True
            $Library.Update()
            ExecuteQueryWithRetry -Ctx $Context
            Write-LogINFO "Content Types Enabled in the library!"
        }

        #Check if the content type exists in the site
        $existingSiteContentType = $SiteContentTypes | Where-Object { $_.Id.StringValue -eq $ContentTypeId }
        If ($null -eq $existingSiteContentType) {
            Write-LogINFO "Content Type '$($ContentTypeId)' doesn't exist"
            Return
        }

        foreach($ListContentType in $ListContentTypes) {
            $ParentContentType = $ListContentType.Parent
            If ($ParentContentType.Id.StringValue -eq $ContentTypeId) {
                $existingListContentType = $ListContentType
                break
            }
        }

        If ($null -eq $existingListContentType) {
            #Add content Type to the list or library
            $existingListContentType = $ListContentTypes.AddExistingContentType($existingSiteContentType)
            $Context.Load($existingListContentType)
            ExecuteQueryWithRetry -Ctx $Context
            Write-LogINFO "Content Type '$($ContentTypeId)' added to '$($Library.Title)' successfully!"
        }
        #Setting content type's default template
        $ContentTypeBaseConfig = $ContentTypeDefinitions.$ContentTypeId
        if($null -ne $ContentTypeBaseConfig) {
            SetContentTypeRenderable -context $Context -ContentType $existingListContentType -contentTypeConfig $ContentTypeBaseConfig -Library $Library
            # Capture original field link properties before modifications
            $Context.Load($existingListContentType.FieldLinks)
            ExecuteQueryWithRetry -Ctx $Context
            $originalFieldProperties = @{}
            foreach ($fieldLink in $existingListContentType.FieldLinks) {
                $originalFieldProperties[$fieldLink.Name] = @{
                    Hidden = $fieldLink.Hidden
                    Required = $fieldLink.Required
                }
            }
            HideUnwantedColumns -Context $Context -ContentTypeObject $existingListContentType -ContentTypeConfig $ContentTypeBaseConfig -OriginalFieldProperties $originalFieldProperties
        }
    }
    Catch {
        Write-LogERR "Error Adding Content Type '$ContentTypeId' to the List '$($Library.Title)': $($_.Exception.Message)"
    }
}

Function CreateOrReplaceListView() {
    param
    (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $context,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $Library,
        [Parameter(Mandatory = $true)] [string] $ViewName,
        [Parameter(Mandatory = $true)] [string[]] $ViewFields,
        [Parameter(Mandatory = $true)] [string] $ViewQuery,
        [Parameter(Mandatory = $false)] [int] $ItemLimit = 100,
        [Parameter(Mandatory = $false)] [bool] $IsDefaultView = $false,
        [Parameter(Mandatory = $false)] [string] $CustomFormat,
        [Parameter(Mandatory = $false)] [bool] $Recursive = $false
    )

    Try {
        $fieldColl = $Library.Fields
        $Context.Load($fieldColl)
        ExecuteQueryWithRetry -Ctx $Context

        #Validate and filter view fields
        $fieldsToBeAdded = @()
        foreach ($field in $Viewfields) {
            $fieldExists = $fieldColl | Where-Object { ($_.InternalName -eq $field) }
            if ($null -ne $fieldExists) {
                $fieldsToBeAdded += $field
            }
        }

        #Check if the View exists in list already
        $ViewColl = $Library.Views
        $Context.Load($ViewColl)
        ExecuteQueryWithRetry -Ctx $Context
        $ExistingView = $ViewColl | Where-Object { ($_.Title -eq $ViewName) }

        if($null -ne $ExistingView) {
            Write-LogINFO "View '$ViewName' already exists. Updating properties..."
            $View = $Library.Views.GetByTitle($ViewName)
            $Context.Load($View)
            $Context.Load($View.ViewFields)
            ExecuteQueryWithRetry -Ctx $Context

            #Get existing fields
            $existingFields = @()
            foreach ($existingField in $View.ViewFields) {
                $existingFields += $existingField
            }

            #Merge fields: add new fields that don't already exist
            foreach ($field in $fieldsToBeAdded) {
                if ($existingFields -notcontains $field) {
                    Write-LogINFO "Adding new field '$field' to view '$ViewName'"
                    $View.ViewFields.Add($field)
                }
            }

            #Update view properties
            $View.ViewQuery = $ViewQuery
            $View.Paged = $true
            $View.RowLimit = $ItemLimit

            if ($IsDefaultView) {
                $View.DefaultView = $true
            }

            if ($CustomFormat) {
                $type = $View.GetType()
                $type.GetProperty('CustomFormatter') | Out-Null
                $View.CustomFormatter = $CustomFormat
            }

            if ($Recursive) {
                Write-LogINFO "Setting recursive scope"
                $ViewScope = [Microsoft.SharePoint.Client.ViewScope]::Recursive
                $View.Scope = $ViewScope
            }

            $View.Update()
            ExecuteQueryWithRetry -Ctx $Context
            Write-LogINFO "View '$ViewName' updated successfully!"
            
            return $View
        }
        else {
            Write-LogINFO "View '$ViewName' does not exist. Creating new view..."
            
            $ViewCreationInfo = New-Object Microsoft.SharePoint.Client.ViewCreationInformation
            $ViewCreationInfo.Title = $ViewName
            $ViewCreationInfo.Query = $ViewQuery
            $ViewCreationInfo.Paged = $true
            $ViewCreationInfo.RowLimit = $ItemLimit
            $ViewCreationInfo.ViewFields = $fieldsToBeAdded
            $ViewCreationInfo.SetAsDefaultView = $IsDefaultView

            $NewView = $Library.Views.Add($ViewCreationInfo)
            ExecuteQueryWithRetry -Ctx $Context

            if ($CustomFormat) {
                $type = $NewView.GetType()
                $type.GetProperty('CustomFormatter') | Out-Null
                $NewView.CustomFormatter = $CustomFormat
                $NewView.Update()
                ExecuteQueryWithRetry -Ctx $Context
                Write-LogINFO "Custom View Format added successfully"
            }

            if ($Recursive) {
                Write-LogINFO "Adding recursive scope"
                $ViewScope = [Microsoft.SharePoint.Client.ViewScope]::Recursive
                $NewView.Scope = $ViewScope
                $NewView.Update()
                ExecuteQueryWithRetry -Ctx $Context
            }

            Write-LogINFO "New View '$ViewName' created successfully!"
            return $NewView
        }

    }
    Catch {
        Write-LogERR "Error creating or updating View '$ViewName': $($_.Exception.Message)"
    }
}

Function Get-DefaultMenuItem {
    param($iconVisibility)

    try {
        $DefaultMenuItems = @()
        $DefaultMenuItems += Add-MenuItem -title "Folder" -templateId "NewFolder" -visible $iconVisibility
        $DefaultMenuItems += Add-MenuItem -title "Word document" -templateId "NewDOC" -visible $iconVisibility
        $DefaultMenuItems += Add-MenuItem -title "Excel workbook" -templateId "NewXSL" -visible $iconVisibility
        $DefaultMenuItems += Add-MenuItem -title "PowerPoint presentation" -templateId "NewPPT" -visible $iconVisibility
        $DefaultMenuItems += Add-MenuItem -title "OneNote notebook" -templateId "NewONE" -visible $iconVisibility
        $DefaultMenuItems += Add-MenuItem -title "Visio drawing" -templateId "NewVSDX" -visible $iconVisibility
        $DefaultMenuItems += Add-MenuItem -title "Forms for Excel" -templateId "NewXSLForm" -visible $iconVisibility
        $DefaultMenuItems += Add-MenuItem -title "Link" -templateId "Link" -visible $iconVisibility

        return $DefaultMenuItems
    }
    catch {
        Write-LogERR -Message "$_ issue in function Get-DefaultMenuItem"
    }
}

Function Add-MenuItem {
    param(
        [Parameter(Mandatory)] [string] $title,
        [Parameter(Mandatory)] [bool] $visible,
        [Parameter(Mandatory)] [string] $templateId,
        [Parameter()] [string] $contentTypeId
    )

    try {
        $newChildNode = New-Object System.Object
        $newChildNode | Add-Member -MemberType NoteProperty -name title -value $title
        $newChildNode | Add-Member -MemberType NoteProperty -name visible -value $visible
        $newChildNode | Add-Member -MemberType NoteProperty -name templateId -value $templateId
        if ($null -ne $contentTypeId) {
            $newChildNode | Add-Member -MemberType NoteProperty -name contentTypeId -value $contentTypeId
            $newChildNode | Add-Member -MemberType NoteProperty -name isContentType -value $true
        }
        return $newChildNode
    }
    catch {
        Write-LogERR "$_ issue in function Add-MenuItem"
    }

}

Function AddTemplateToNewButton {
    param(
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $context,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $Library,
        $ListContentTypesConfig
    )
    try {
        Write-LogINFO "Modifying the New button for the library '$($Library.Title)'"
        $Views = $Library.Views
        $Context.Load($Views)
        ExecuteQueryWithRetry -Ctx $Context

        $ListContentTypes = $Library.ContentTypes
        $Context.Load($listContentTypes)
        ExecuteQueryWithRetry -Ctx $Context

        $menuItems = @()
        $ListContentTypes | ForEach-Object {
            $ListContentType = $PSItem
            $Parent = $ListContentType.Parent
            $Context.Load($Parent)
            ExecuteQueryWithRetry -Ctx $Context
            $ParentId = $Parent.Id.StringValue
            $ListContentTypeConfig = $ListContentTypesConfig | Where-Object { $ParentId -eq $_.Id }
            $Visible = if ($ListContentTypeConfig) { $ListContentTypeConfig.ShownInNewButtonMenu } else { $false }
            $menuItems += Add-MenuItem -title $ListContentType.Name -visible $Visible -templateId $ListContentType.StringId -contentTypeId $ListContentType.StringId
        }

        $menuItems += (Get-DefaultMenuItem -iconVisibility $true -items $MenuItems)

        $defaultView = $Views | Where-Object { ($_.DefaultView -eq $true) }
        $defaultView.NewDocumentTemplates = $menuItems | ConvertTo-Json
        $defaultView.update()
        ExecuteQueryWithRetry -Ctx $Context
    }
    catch {
        Write-LogERR -Message "$_ issue in function add-TemplatetoNewButton"
    }
}

function GetListContentTypeByParent ($Context, $contentTypeParentId, $contentTypes) {

    $ct = $null
    foreach ($contentType in $contentTypes) {
        $Context.Load($contentType.Parent)
        ExecuteQueryWithRetry -Ctx $Context
        if ($contentType.Parent.StringId -eq $contentTypeParentId) {
            $ct = $contentType
            break
        }
    }
     # If not found, check second-level parent
    if ($null -eq $ct) {
        foreach ($contentType in $contentTypes) {
            $Context.Load($contentType.Parent)
            ExecuteQueryWithRetry -Ctx $Context
            $parentContentType = $contentType.Parent
            if ($null -ne $parentContentType) {
                $Context.Load($parentContentType.Parent)
                ExecuteQueryWithRetry -Ctx $Context
                if ($parentContentType.Parent.StringId -eq $contentTypeParentId) {
                    $ct = $contentType
                    break
                }
            }
        }
    }

    if ($null -ne $ct) {
        Write-LogINFO "Content Type Name: $($ct.Name)"
    }
    else {
        Write-LogINFO "Content Type not found."
    }
    Return $ct
}

Function HideColumns () {
    param(
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Parameter(Mandatory = $true)] [psobject] $LibraryConfig,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $Library
    )
    try {

        $AllLibraryContentTypes = $library.ContentTypes
        $Context.Load($AllLibraryContentTypes)
        ExecuteQueryWithRetry -Ctx $Context
        foreach($ListContentType in $AllLibraryContentTypes) {
            $Context.Load($ListContentType.Parent)
        }
        ExecuteQueryWithRetry -Ctx $Context

        $AllSiteContentTypes = $Context.Web.ContentTypes
        $Context.Load($AllSiteContentTypes)
        ExecuteQueryWithRetry -Ctx $Context

        #Get the site column to add
        $SiteColumnColl = $Context.Web.Fields
        $Context.Load($SiteColumnColl)
        ExecuteQueryWithRetry -Ctx $Context

        foreach ($ListConfig in $LibraryConfig.ColumnsToHideInContentType) {
            try {
                $ListCT = GetListContentTypeByParent -Context $Context -contentTypes $AllLibraryContentTypes -contentTypeParentId $ListConfig.ParentContentTypeId
                if ($null -eq $ListCT) {
                    Write-LogINFO -Message "Content type with parent ID $($ListConfig.ParentContentTypeId) not found in the library $($Library.Title). Skipping column hiding."
                    continue
                }
                $Context.Load($ListCT)
                $Context.Load($ListCT.FieldLinks)
                ExecuteQueryWithRetry -Ctx $Context

                $AllCTFields = $ListCT.Fields
                $Context.Load($AllCTFields)
                ExecuteQueryWithRetry -Ctx $Context


                foreach ($tempFieldstoHide in $ListConfig.ColumnsToHide) {
                    try {
                        $CTfieldtoHide = $AllCTFields | Where-Object { $_.InternalName -eq $tempFieldstoHide.InternalName }

                        if ($null -eq $CTfieldtoHide) {
                            $SiteColumn = $SiteColumnColl | Where-Object { ($_.InternalName -eq $tempFieldstoHide.InternalName) }
                            if ($null -eq $SiteColumn) {
                                Write-LogINFO -Message "Column $tempFieldstoHide not found in the site columns. Skipping hiding."
                                continue
                            }
                            $FieldLink = New-Object Microsoft.SharePoint.Client.FieldLinkCreationInformation
                            $FieldLink.Field = $SiteColumn
                            [Void]$ListCT.FieldLinks.Add($FieldLink)
                            $ListCT.Update($false)
                            ExecuteQueryWithRetry -Ctx $Context
                        }

                        SetColumnPropertiesOnContentType $Context $ListCT $tempFieldstoHide $false
                        Write-LogINFO -Message "Column $tempFieldstoHide hidden for clean up"

                    }
                    catch {
                        Write-LogERR -Message "Error in hiding column $tempFieldstoHide  for clean up . $($_.Exception.Message)"
                    }
                }
            }
            catch {
                Write-LogERR -Message "$_ issue in function HideColumns"
            }

        }
    }
    catch {
        Write-LogERR -Message "$_ issue in function HideColumns"
    }
}

Function GetAllDocumentLibraries($Ctx, $Web, $Config) {
    Try {
        if ($null -eq $Web) {
            $Web = $Ctx.web
        }

        $Libraries = @()
        $LibsToIgnore = $Config

        # BFS traversal: batch-load every web at the current depth in one round-trip instead of one per web
        $currentLevelWebs = @($Web)
        while ($currentLevelWebs.Count -gt 0) {
            foreach ($w in $currentLevelWebs) {
                $Ctx.Load($w)
                $Ctx.Load($w.Lists)
                $Ctx.Load($w.Webs)
            }
            ExecuteQueryWithRetry -ctx $Ctx #-CallerInvocation $MyInvocation

            $nextLevelWebs = @()
            foreach ($w in $currentLevelWebs) {
                $null = Write-LogINFO "Processing Site: $($w.Url)"
                $Lists = $w.Lists | Where-Object { $_.BaseType -eq "DocumentLibrary" -and $_.Hidden -eq $False -and $LibsToIgnore -notcontains $_.EntityTypeName }
                foreach ($List in $Lists) {
                    $Libraries += $List
                }
                foreach ($Subweb in $w.Webs) {
                    $nextLevelWebs += $Subweb
                }
            }
            $currentLevelWebs = $nextLevelWebs
        }

        return $Libraries
    }
    Catch {
        Write-LogERR "Error Getting Document Libraries!" $_.Exception.Message
    }
}

Function GetCheckedOutAndLockedFiles($context, $List) {

    $CheckedOutFiles = @();
    $Context.Load($List)
    ExecuteQueryWithRetry -Ctx $Context
    $ListItems = $List.GetItems([Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery())
    $Context.Load($ListItems)
    $Context.Load($List.ContentTypes)
    ExecuteQueryWithRetry -Ctx $Context

    ForEach ($Item in $ListItems) {

        $File = $Item.File
        $context.Load($File)
        $context.Load($File.CheckedOutByUser)
        $context.Load($File.LockedByUser)
        ExecuteQueryWithRetry -Ctx $Context

        $checkedOutBy = $File.CheckedOutByUser.UserPrincipalName
        $lockedBy = $File.LockedByUser.UserPrincipalName

        if (($null -ne $checkedOutBy) -or ($null -ne $lockedBy)) {
            $CheckedOutFiles += "$($Web.url)$($Item['FileRef']): Checked-out by: $checkedOutBy or locked by: $lockedBy"
        }
    }

    return $CheckedOutFiles
}

Function SetContentTypeRenderable {
    param(
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $context,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ContentType]$contentType,
        [Parameter(Mandatory = $true)] [PSCustomObject] $contentTypeConfig,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $library
    )

    try {
            if($contentTypeConfig.NonRenderable -eq $true) {
                $contentType.DocumentTemplate =  "/_Layout/15/doc.aspx"
                write-loginfo "Setting the content type $($contentType.Name)'s default template to non-renderable"
            }
            elseif($contentTypeConfig.NonRenderable -eq $false) {
                $contentType.DocumentTemplate = "$($context.Web.Url)/_layouts/NewDocSet.aspx?List=$($library.Id)"
                write-loginfo "Setting the content type $($contentType.Name)'s default template to renderable"
            }
            $contentType.Update($false)
            ExecuteQueryWithRetry -Ctx $Context
        }
        catch {
            Write-LogERR -Message "Unable to update the default content template to renderable/non-renderable. $($_). Content Type: $($contentType.Name)"
        }
}