# This file mitigates UPS server on localhost for the E3 site creation
$global:CurrDir = "."

Import-Module "$global:CurrDir\utils\ups.ps1"
Import-Module "$global:CurrDir\utils\auth.ps1"

$tenant = "allianzms"

# Use ACS OAuth (app-only authentication)
LogInToTenant -tenant $tenant

$sites = @(
    'https://allianzms.sharepoint.com/teams/SK0000-legacy'
    'https://allianzms.sharepoint.com/teams/SK0001-legacy'
    'https://allianzms.sharepoint.com/teams/SK0002-legacy'
);

foreach ($site in $sites) {
    try {
        Write-LogINFO "removing the site: ${site}"
        Remove-SPOSite -Identity $site -Confirm:$false
        Remove-SPODeletedSite -identity $site -Confirm:$false
        Write-LogINFO "removed: ${site}"
    }
    catch {
        Write-Error $_.Exception.Message
    }
}