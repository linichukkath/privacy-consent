# Migration Tracker module - bidirectional communication with SharePoint migration tracker list
# Only used by legacy-sites-update-runbook.ps1 (loaded via .psm1)
# Depends on: Get-AzureADAccessToken from auth.ps1

# --- Module-scoped state ---
$script:trackerEnabled = $false
$script:trackerConfig = @{
    Token       = $null
    Headers     = $null
    ListItemId  = $null
    EntityType  = $null      # resolved lazily on first PATCH
    FieldTypes  = @{}
    ErrorBuffer = [System.Collections.ArrayList]::new()
}

# --- Constants ---
$script:TrackerSiteUrl = "https://allianzms.sharepoint.com/teams/DE1214-12422097"
$script:TrackerListId  = "c66e0c4d-cdb8-47b5-bb42-d705f551722b"

# --- Functions ---

Function Get-MigrationTrackerSiteUrl {
    return $script:TrackerSiteUrl
}

Function Get-MigrationTrackerRestErrorBody {
    param(
        [Parameter(Mandatory = $true)] [object] $ErrorRecord
    )

    try {
        $response = $ErrorRecord.Exception.Response
        if (-not $response) { return $ErrorRecord.Exception.Message }
        $stream = $response.GetResponseStream()
        $stream.Position = 0
        $reader = New-Object System.IO.StreamReader($stream)
        $body = $reader.ReadToEnd()
        if ([string]::IsNullOrWhiteSpace($body)) { return $ErrorRecord.Exception.Message }
        return $body
    }
    catch {
        return $ErrorRecord.Exception.Message
    }
}

Function Get-MigrationTrackerFieldType {
    param(
        [Parameter(Mandatory = $true)] [string] $InternalName,
        [Parameter(Mandatory = $true)] [hashtable] $Headers
    )

    if ($script:trackerConfig.FieldTypes.ContainsKey($InternalName)) {
        return $script:trackerConfig.FieldTypes[$InternalName]
    }

    $fieldUrl = "$($script:TrackerSiteUrl)/_api/web/lists(guid'$($script:TrackerListId)')/fields/getbyinternalnameortitle('$InternalName')?`$select=TypeAsString"
    $fieldInfo = Invoke-RestMethod -Uri $fieldUrl -Method GET -Headers $Headers -ErrorAction Stop
    $script:trackerConfig.FieldTypes[$InternalName] = $fieldInfo.d.TypeAsString
    return $script:trackerConfig.FieldTypes[$InternalName]
}

Function ConvertTo-MigrationTrackerFieldValue {
    param(
        [Parameter(Mandatory = $true)] [string] $InternalName,
        [Parameter(Mandatory = $false)] [object] $Value,
        [Parameter(Mandatory = $true)] [hashtable] $Headers
    )

    $fieldType = Get-MigrationTrackerFieldType -InternalName $InternalName -Headers $Headers
    if ($fieldType -eq "URL") {
        return @{
            "__metadata" = @{ "type" = "SP.FieldUrlValue" }
            Url          = [string]$Value
            Description  = [string]$Value
        }
    }

    if ($fieldType -eq "Choice") {
        return [string]$Value
    }

    return $Value
}

Function Initialize-MigrationTracker {
    param(
        [Parameter(Mandatory = $false)] [object] $ListItemId,
        [Parameter(Mandatory = $true)]  [string] $ClientId,
        [Parameter(Mandatory = $false)] [string] $ClientSecret,
        [Parameter(Mandatory = $true)]  [string] $TenantId,
        [Parameter(Mandatory = $false)] [System.Security.Cryptography.X509Certificates.X509Certificate2] $Certificate
    )

    try {
        # No-op mode for manual / test runs
        if ($null -eq $ListItemId -or $ListItemId -eq 0) {
            $script:trackerEnabled = $false
            Write-LogINFO "Migration tracker disabled (no listItemId provided)"
            return
        }

        # Acquire access token for the tracker site
        $token = Get-AzureADAccessToken `
            -tenantId $TenantId `
            -clientId $ClientId `
            -clientSecret $ClientSecret `
            -certificate $Certificate `
            -resourceUrl $script:TrackerSiteUrl

        $script:trackerConfig.Token      = $token
        $script:trackerConfig.ListItemId = $ListItemId
        $script:trackerConfig.Headers    = @{
            Authorization    = "Bearer $token"
            "Content-Type"   = "application/json;odata=verbose"
            Accept           = "application/json;odata=verbose"
            "IF-MATCH"       = "*"
            "X-HTTP-Method"  = "MERGE"
        }
        $script:trackerConfig.FieldTypes.Clear()
        $script:trackerConfig.ErrorBuffer.Clear()

        $script:trackerEnabled = $true
        Write-LogINFO "Migration tracker initialized for list item $ListItemId"

        # Write job ID immediately
        $jobId = ""
        try {
            $jobId = $PSPrivateMetadata.JobId.Guid
        } catch {
            $jobId = "unknown"
        }
        Update-MigrationTrackerField -Fields @{ tr_MigrationJobId = $jobId }
    }
    catch {
        $script:trackerEnabled = $false
        Write-LogWarn "Migration tracker initialization failed: $($_.Exception.Message). Tracking disabled."
    }
}

Function Update-MigrationTrackerField {
    param(
        [Parameter(Mandatory = $true)] [hashtable] $Fields
    )

    if (-not $script:trackerEnabled) { return }

    try {
        # Lazy-resolve entity type on first call
        if ($null -eq $script:trackerConfig.EntityType) {
            $getUrl = "$($script:TrackerSiteUrl)/_api/web/lists(guid'$($script:TrackerListId)')?`$select=ListItemEntityTypeFullName"
            $getHeaders = @{
                Authorization  = "Bearer $($script:trackerConfig.Token)"
                Accept         = "application/json;odata=verbose"
            }
            $listInfo = Invoke-RestMethod -Uri $getUrl -Method GET -Headers $getHeaders -ErrorAction Stop
            $script:trackerConfig.EntityType = $listInfo.d.ListItemEntityTypeFullName
            Write-LogINFO "Migration tracker entity type resolved: $($script:trackerConfig.EntityType)"
        }

        # Build body
        $body = @{
            "__metadata" = @{ "type" = $script:trackerConfig.EntityType }
        }
        foreach ($key in $Fields.Keys) {
            $body[$key] = ConvertTo-MigrationTrackerFieldValue `
                -InternalName $key `
                -Value $Fields[$key] `
                -Headers $script:trackerConfig.Headers
        }
        $jsonBody = $body | ConvertTo-Json -Depth 5

        $patchUrl = "$($script:TrackerSiteUrl)/_api/web/lists(guid'$($script:TrackerListId)')/items($($script:trackerConfig.ListItemId))"

        # Retry with exponential backoff: 2s, 4s, 8s
        $maxAttempts = 3
        for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
            try {
                Invoke-RestMethod -Uri $patchUrl -Method POST -Headers $script:trackerConfig.Headers -Body $jsonBody -ErrorAction Stop | Out-Null
                Write-LogINFO "Migration tracker updated: $($Fields.Keys -join ', ')"
                return
            }
            catch {
                if ($attempt -eq $maxAttempts) {
                    Write-LogWarn "Migration tracker update failed after $maxAttempts attempts: $(Get-MigrationTrackerRestErrorBody $_)"
                    return
                }
                $backoff = [math]::Pow(2, $attempt)
                Write-LogWarn "Migration tracker update attempt $attempt failed, retrying in ${backoff}s..."
                Start-Sleep -Seconds $backoff
            }
        }
    }
    catch {
        Write-LogWarn "Migration tracker field update error: $($_.Exception.Message)"
    }
}

Function Set-MigrationTrackerStatus {
    param(
        [Parameter(Mandatory = $true)] [string] $Status
    )

    if (-not $script:trackerEnabled) { return }

    if ($Status -eq "Migration failed") {
        try {
            # GET current item to read tr_RetryCount
            $getUrl = "$($script:TrackerSiteUrl)/_api/web/lists(guid'$($script:TrackerListId)')/items($($script:trackerConfig.ListItemId))?`$select=tr_RetryCount"
            $getHeaders = @{
                Authorization  = "Bearer $($script:trackerConfig.Token)"
                Accept         = "application/json;odata=verbose"
            }
            $item = Invoke-RestMethod -Uri $getUrl -Method GET -Headers $getHeaders -ErrorAction Stop
            $currentRetry = if ($null -ne $item.d.tr_RetryCount) { [int]$item.d.tr_RetryCount } else { 0 }

            Update-MigrationTrackerField -Fields @{
                tr_Status     = $Status
                tr_RetryCount = ($currentRetry + 1)
            }
        }
        catch {
            Write-LogWarn "Failed to read retry count, setting status without increment: $($_.Exception.Message)"
            Update-MigrationTrackerField -Fields @{ tr_Status = $Status }
        }
    }
    else {
        Update-MigrationTrackerField -Fields @{ tr_Status = $Status }
    }
}

Function Add-MigrationTrackerError {
    param(
        [Parameter(Mandatory = $true)] [string] $Message
    )

    if (-not $script:trackerEnabled) { return }

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $script:trackerConfig.ErrorBuffer.Add("[$timestamp] $Message") | Out-Null
}

Function Set-MigrationTrackerQCResult {
    param(
        [Parameter(Mandatory = $true)]  [bool]   $Passed,
        [Parameter(Mandatory = $false)] [string] $Findings = ""
    )

    if (-not $script:trackerEnabled) { return }

    Update-MigrationTrackerField -Fields @{
        tr_QCResults  = if ($Passed) { "Pass" } else { "Fail" }
        tr_QCFindings = $Findings
    }
}

Function New-MigrationTrackerEntryForChannel {
    param(
        [Parameter(Mandatory = $true)]  [string] $ChannelUrl,
        [Parameter(Mandatory = $true)]  [bool]   $QCPassed,
        [Parameter(Mandatory = $false)] [string] $QCFindings = ""
    )

    if (-not $script:trackerEnabled) { return }

    try {
        $getHeaders = @{
            Authorization = "Bearer $($script:trackerConfig.Token)"
            Accept        = "application/json;odata=verbose"
        }

        # Lazy-resolve entity type on first call (same as Update-MigrationTrackerField)
        if ($null -eq $script:trackerConfig.EntityType) {
            $listUrl = "$($script:TrackerSiteUrl)/_api/web/lists(guid'$($script:TrackerListId)')?`$select=ListItemEntityTypeFullName"
            $listInfo = Invoke-RestMethod -Uri $listUrl -Method GET -Headers $getHeaders -ErrorAction Stop
            $script:trackerConfig.EntityType = $listInfo.d.ListItemEntityTypeFullName
        }

        # Read only the fields that are safe to copy into a new tracker row.
        # tr_SiteOwner/tr_Deputy are Person fields - use the *Id suffix to get the raw lookup id instead of an empty object
        $parentFieldSelect = "tr_MigrationJobId,tr_SiteOwnerId,tr_DeputyId,tr_DateToMigrate"
        $itemUrl = "$($script:TrackerSiteUrl)/_api/web/lists(guid'$($script:TrackerListId)')/items($($script:trackerConfig.ListItemId))?`$select=$parentFieldSelect"
        $parentItem = Invoke-RestMethod -Uri $itemUrl -Method GET -Headers $getHeaders -ErrorAction Stop

        $body = @{ "__metadata" = @{ "type" = $script:trackerConfig.EntityType } }
        foreach ($fieldName in $parentFieldSelect.Split(',')) {
            if ($null -ne $parentItem.d.$fieldName) {
                $body[$fieldName] = $parentItem.d.$fieldName
            }
        }
        $body["tr_SiteUrl"]    = ConvertTo-MigrationTrackerFieldValue -InternalName "tr_SiteUrl" -Value $ChannelUrl -Headers $getHeaders
        $body["tr_QCResults"]  = if ($QCPassed) { "Pass" } else { "Fail" }
        $body["tr_QCFindings"] = $QCFindings
        $body["tr_Status"]     = if ($QCPassed) { "Owner approved" } else { "QC failed" }

        $createHeaders = @{
            Authorization  = "Bearer $($script:trackerConfig.Token)"
            "Content-Type" = "application/json;odata=verbose"
            Accept         = "application/json;odata=verbose"
        }
        $createUrl = "$($script:TrackerSiteUrl)/_api/web/lists(guid'$($script:TrackerListId)')/items"
        Invoke-RestMethod -Uri $createUrl -Method POST -Headers $createHeaders -Body ($body | ConvertTo-Json -Depth 5) -ErrorAction Stop | Out-Null
        Write-LogINFO "Migration tracker entry created for private channel: $ChannelUrl"
    }
    catch {
        Write-LogWarn "Failed to create migration tracker entry for private channel $($ChannelUrl): $(Get-MigrationTrackerRestErrorBody $_)"
    }
}

Function Set-MigrationTrackerFixInstructions {
    param(
        [Parameter(Mandatory = $true)] [string] $Instructions
    )

    if (-not $script:trackerEnabled) { return }

    Update-MigrationTrackerField -Fields @{
        tr_FixInstructions = $Instructions
    }
}

Function Complete-MigrationTracker {
    param(
        [Parameter(Mandatory = $true)]  [bool]   $Success,
        [Parameter(Mandatory = $false)] [string] $FailureStatus = "Migration failed"
    )

    if (-not $script:trackerEnabled) { return }

    # Flush error buffer - truncate to 60KB if needed
    $logText = $script:trackerConfig.ErrorBuffer -join "`n"
    $maxBytes = 60 * 1024
    if ([System.Text.Encoding]::UTF8.GetByteCount($logText) -gt $maxBytes) {
        while ([System.Text.Encoding]::UTF8.GetByteCount($logText) -gt $maxBytes) {
            $logText = $logText.Substring(0, [math]::Floor($logText.Length * 0.9))
        }
        $logText += "`n[TRUNCATED - log exceeded 60KB]"
    }

    Update-MigrationTrackerField -Fields @{
        tr_MigrationResult = if ($Success) { "Success" } else { "Fail" }
        tr_MigrationLog    = $logText
    }

    if ($Success) {
        Set-MigrationTrackerStatus -Status "Completed"
    }
    else {
        Set-MigrationTrackerStatus -Status $FailureStatus
    }
}

