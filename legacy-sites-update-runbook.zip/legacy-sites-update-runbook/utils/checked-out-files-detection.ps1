
function Get-RestErrorBody($ErrorRecord) {
    # Invoke-RestMethod exceptions only expose "(400) Bad Request" - the actual SharePoint
    # odata.error message is in the response body and must be read from the stream.
    try {
        $response = $ErrorRecord.Exception.Response
        if (-not $response) { return $ErrorRecord.Exception.Message }
        $stream = $response.GetResponseStream()
        $stream.Position = 0
        $reader = New-Object System.IO.StreamReader($stream)
        $body = $reader.ReadToEnd()
        if ([string]::IsNullOrWhiteSpace($body)) { return $ErrorRecord.Exception.Message }
        return $body
    }
    catch {
        return $ErrorRecord.Exception.Message
    }
}

function Get-ContentTypeParentMap($libraryId, $url, $headers) {
    $map = @{}
    try {
        $ctResponse = Invoke-RestMethod `
            -Uri "$url/_api/web/lists(guid'$libraryId')/contenttypes?`$select=StringId,Parent/StringId&`$expand=Parent" `
            -Method Get -Headers $headers
        foreach ($ct in $ctResponse.d.results) {
            if ($ct.Parent -and $ct.Parent.StringId) {
                $map[$ct.StringId] = $ct.Parent.StringId
            }
        }
        Write-LogINFO "Loaded $($map.Count) content types with parent info for library $libraryId"
    }
    catch {
        Write-LogINFO "Could not retrieve content type parent map for library ${libraryId}: $($_.Exception.Message)"
    }
    return $map
}

function Invoke-CheckedOutFileRestGetWithRetry {
    param (
        [Parameter(Mandatory = $true)] [string] $Uri,
        [Parameter(Mandatory = $true)] [hashtable] $Headers,
        [Parameter(Mandatory = $false)] [int] $MaxAttempts = 5
    )

    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            $response = Invoke-RestMethod -Uri $Uri -Method Get -Headers $Headers
            if ($null -ne $response -and ($response | Out-String) -like '*"Id"*') {
            $responseData = $response.Replace("""Id""", "ItemId") | ConvertFrom-Json
            return @{
                Items = $responseData.d.results
                NextUrl = $responseData.d.__next
            }
        }
        }
        catch {
            $response = $_.Exception.Response
            $statusCode = $null
            if ($response) {
                try { $statusCode = [int] $response.StatusCode } catch { $statusCode = $null }
            }

            $webExceptionStatus = $null
            if ($_.Exception -is [System.Net.WebException]) {
                $webExceptionStatus = $_.Exception.Status
            }
            $isTransient = $statusCode -in @(408, 429, 503) -or
                $webExceptionStatus -in @(
                    [System.Net.WebExceptionStatus]::Timeout,
                    [System.Net.WebExceptionStatus]::ConnectionClosed,
                    [System.Net.WebExceptionStatus]::ConnectFailure
                )

            if (-not $isTransient -or $attempt -eq $MaxAttempts) {
                Write-LogERR "Checked-out file request failed for '$Uri': $(Get-RestErrorBody $_)"
                throw
            }

            $retryAfterSeconds = 0
            if ($response -and $response.Headers) {
                $retryAfterHeader = $response.Headers['Retry-After']
                if ($retryAfterHeader) {
                    [void] [int]::TryParse([string] $retryAfterHeader, [ref] $retryAfterSeconds)
                }
            }
            if ($retryAfterSeconds -le 0) {
                $retryAfterSeconds = [Math]::Min([Math]::Pow(2, $attempt) + (Get-Random -Minimum 0 -Maximum 2), 60)
            }

            Write-LogWARN "Checked-out file page request failed with HTTP $statusCode. Retrying in $retryAfterSeconds second(s) (attempt $attempt/$MaxAttempts)."
            Start-Sleep -Seconds $retryAfterSeconds
        }
    }
}

Function Get-AllCheckedOutFilesREST($siteUrl, $libraryGUID, $headers) {
    $allItems = @()
    $nextUrl = "$siteUrl/_api/web/lists(guid'$libraryGUID')/items?`$select=File/Name,File/ServerRelativeUrl,CheckoutUser/Title,CheckoutUser/EMail&`$expand=File,CheckoutUser&`$filter=CheckoutUser ne null"

    do {
        try {
            $response = Invoke-RestMethod -Uri $nextUrl -Method Get -Headers $headers
            $allItems += $response.d.results

            # Check if there is a next page of results
            if ($response.d.__next) {
                $nextUrl = $response.d.__next
            } else {
                $nextUrl = $null
            }
        }
        catch {
            Write-LogINFO $_.Exception.Message
            break
        }
    } while ($nextUrl)

    # Process the results
    $CheckedOutFiles = @()
    ForEach ($item in $allItems) {
        $CheckedOutFiles += New-Object -TypeName PSObject -Property @{
            FileName     = $item.File.Name
            URL          = $siteUrl + $item.File.ServerRelativeUrl
            CheckedOutBy = $item.CheckoutUser.Title
            Email        = $item.CheckoutUser.Email
        }
    }

    return $CheckedOutFiles
}


Function getAllCheckedOutFiles() {

    param (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List[]] $libraries,
        [Parameter(Mandatory = $true)] [string] $siteUrl,
        [Parameter(Mandatory = $true)] [hashtable] $headers,
        [Parameter(Mandatory = $true)] [psobject] $contentTypeDefinitions,
        [Parameter(Mandatory = $false)] [hashtable] $contentTypeParentMaps = $null,
        [Parameter(Mandatory = $false)] [string] $language = "en-US",
        [Parameter(Mandatory = $false)] [psobject] $viewDefinitions = $null
    )

    try {
        $wantedContentTypeIds = $contentTypeDefinitions |
            Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
        $checkedOutFilesViews = @()
        #Iterate through each document library in the web
        ForEach ($library in ($libraries | Where-Object { $_.BaseTemplate -eq 101 }) ) {
            $url = $siteUrl
            $CheckedOutFiles = @()
            $libraryEntityTypeName = $library.EntityTypeName
            if ($url -notlike "*$($library.ParentWebUrl)*") {
                # Extract the pathname from the full URL (removes domain)
                $basePath = $url -replace "^https?://[^/]+", ""
                # Remove the common part from $ListParentWebUrl
                if ($library.ParentWebUrl -like "$basePath*") {
                    $uniquePath = $library.ParentWebUrl.Substring($basePath.Length)
                } else {
                    $uniquePath = $library.ParentWebUrl
                }

                # Construct the final URL
                $url = "$url$uniquePath"

            }
            Write-LogINFO "Checking checked-out files in Document Library: $($library.Title)"
            
            $sitePath = ($url -replace "^https?://[^/]+", "")
            $libraryId = $library.Id.ToString()
            $nextUrl = "$url/_api/web/lists(guid'$libraryId')/items?`$select=ID,FileLeafRef,Modified,ContentTypeId,File/Name,File/ServerRelativeUrl,CheckoutUser/Title,CheckoutUser/EMail&`$expand=File,CheckoutUser&`$orderby=ID&`$top=5000"
            $checkedOutItems = New-Object 'System.Collections.Generic.List[object]'
            #Exclude System Lists
            Try {
            If ($library.Hidden -eq $False) {
                do {
                    $response = Invoke-CheckedOutFileRestGetWithRetry -Uri $nextUrl -Headers $headers
                    $checkedOutItems += @($response.Items | Where-Object { $_.File.PSObject.Properties.Name -ne '__deferred' -and $null -ne $_.CheckoutUser -and $null -ne $_.CheckoutUser.Title })
                    $nextUrl = $response.NextUrl
                } while ($nextUrl)

                $checkedOutItems = @($checkedOutItems | Where-Object {
                    $itemContentTypeId = [string]$_.ContentTypeId
                    $matchesWantedType = $false

                    foreach ($wantedId in $wantedContentTypeIds) {
                        $matchesWantedType = if ($wantedId -eq "0x0101") {
                            # Check if the content type's parent is 0x0101 (Document)
                            $contentTypeParentMap = if ($contentTypeParentMaps -and $contentTypeParentMaps.ContainsKey($library.Id.ToString())) {
                                $contentTypeParentMaps[$library.Id.ToString()]
                            } else {
                                Get-ContentTypeParentMap -libraryId $library.Id.ToString() -url $url -headers $headers
                            }
                            $parentId = $contentTypeParentMap[$itemContentTypeId]
                            $parentId -eq $wantedId
                        } else {
                            $itemContentTypeId -like "$wantedId*"
                        }

                        if ($matchesWantedType) { break }
                    }

                    -not $matchesWantedType
                })

                $CheckedOutFiles = New-Object 'System.Collections.Generic.List[object]'
                ForEach ($item in $checkedOutItems) {
                    $fileServerRelativeUrl = $item.File.ServerRelativeUrl
                    if ($fileServerRelativeUrl.StartsWith($sitePath)) {
                        $fileServerRelativeUrl = $fileServerRelativeUrl.Substring($sitePath.Length)
                    }
                    $CheckedOutFiles.Add([PSCustomObject]@{
                        FileName     = $item.File.Name
                        FileLeafRef  = $item.File.Name
                        URL          = $url + $fileServerRelativeUrl
                        CheckedOutBy = $item.CheckoutUser.Title
                        CheckoutUser = $item.CheckoutUser
                        Email        = $item.CheckoutUser.Email
                        Modified     = $item.Modified
                    })
                }
            }
            if($CheckedOutFiles.Count -gt 0) {
                $checkedOutFilesViews += createCheckedOutFilesView `
                -Context $library.Context `
                -Library $library `
                -libraryEntityTypeName $libraryEntityTypeName `
                -checkedOutItems $checkedOutItems `
                -CheckedOutFiles $CheckedOutFiles `
                -Language $language `
                -ViewDefinitions $viewDefinitions
            }
            }
            Catch {
                # Don't let one bad library (e.g. malformed REST query, throttling) abort the whole site report
                Write-LogERR "Skipping checked-out files for library '$($library.Title)' ($nextUrl): $($_.Exception.Message)"
            }
        }
        return $checkedOutFilesViews
    }
    Catch {
        Write-LogERR "Error collecting checked-out files report! $(Get-RestErrorBody $_)"
        throw "Error collecting checked-out files report! $($_.Exception.Message)"
    }
}

function createCheckedOutFilesView($Context, $library, $libraryEntityTypeName, $checkedOutItems, $CheckedOutFiles, $Language, $ViewDefinitions) {
    # Load ViewDefinitions if not provided
    if ($null -eq $ViewDefinitions) {
        $ViewDefinitions = Get-Content "$global:CurrDir\configs\views.json" -Raw -Encoding utf8 | ConvertFrom-Json
    }

    # Use default language if not provided
    if ([string]::IsNullOrEmpty($Language)) {
        $Language = "en-US"
    }

    $ViewDef = $ViewDefinitions.AllCheckedOutFiles
    $ViewName = $ViewDef.Name.$Language

    # Validate ViewName is not empty
    if ([string]::IsNullOrEmpty($ViewName)) {
        Write-LogWarn "ViewName is empty for language: $Language. Using fallback."
        $ViewName = "Checked Out Files"
    }

    $View = CreateOrReplaceListView `
        -context $context `
        -Library $library `
        -ViewName $ViewName `
        -ViewFields $ViewDef.Fields `
        -ViewQuery $ViewDef.Query.$Language `
        -ItemLimit $ViewDef.ItemLimit `
        -IsDefaultView $ViewDef.IsDefaultView `
        -CustomFormat $ViewDef.CustomFormat `
        -Recursive $ViewDef.Recursive
    $Context.Load($View)
    ExecuteQueryWithRetry -Ctx $Context
    if ($url -match "^(https?://[^/]+)") {
        $baseUrl = $matches[1]
        $viewUrl = "$baseUrl$($View.ServerRelativeUrl)"
    } else {
        $viewUrl = $url + $View.ServerRelativeUrl
    }
    $checkedOutFilesView = [PSCustomObject]@{
        LibraryName = $library.Title
        LibraryUrl = "$url/$libraryEntityTypeName"
        ViewUrl = $viewUrl
        ViewName = $View.Name.$Language
        FileCount = $checkedOutItems.Count
        Files = $checkedOutFiles | ForEach-Object {
            [PSCustomObject]@{
                FileName = $_.FileLeafRef
                CheckedOutBy = if ($_.CheckoutUser) { $_.CheckoutUser.Title } else { "Unknown" }
                Modified = $_.Modified
            }
        }
    }
    return $checkedOutFilesView
}

Function getAllFilesWithComplianceTags() {

    param (
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List[]] $libraries,
        [Parameter(Mandatory = $true)] [string] $siteUrl,
        [Parameter(Mandatory = $true)] [hashtable] $headers,
        [Parameter(Mandatory = $false)] [string] $language = "en-US",
        [Parameter(Mandatory = $false)] [psobject] $viewDefinitions = $null,
        [Parameter(Mandatory = $false)] [psobject] $contentTypeDefinitions = $null,
        [Parameter(Mandatory = $false)] [hashtable] $contentTypeParentMaps = $null
    )

    try {
        $complianceTaggedFilesViews = @()
        $rowLimit = 500

        ForEach ($library in ($libraries | Where-Object { $_.BaseTemplate -eq 101 })) {
            $url = $siteUrl
            if ($url -notlike "*$($library.ParentWebUrl)*") {
                $basePath = $url -replace "^https?://[^/]+", ""
                if ($library.ParentWebUrl -like "$basePath*") {
                    $uniquePath = $library.ParentWebUrl.Substring($basePath.Length)
                } else {
                    $uniquePath = $library.ParentWebUrl
                }
                $url = "$url$uniquePath"
            }

            If ($library.Hidden -eq $False) {
                Write-LogINFO "Checking compliance-tagged files in Document Library: $($library.Title)"

                # Load RootFolder so ServerRelativeUrl is available (CSOM lazy property)
                $libraryContext = $library.Context
                $libraryContext.Load($library.RootFolder)
                ExecuteQueryWithRetry -Ctx $libraryContext
                $libraryServerRelativeUrl = $library.RootFolder.ServerRelativeUrl

                if ([string]::IsNullOrEmpty($libraryServerRelativeUrl)) {
                    Write-LogINFO "Could not resolve server-relative URL for library $($library.Title) - skipping compliance tag check"
                    continue
                }

                if ($url -match "^(https?://[^/]+)") {
                    $hostUrl = $matches[1]
                } else {
                    $hostUrl = $url
                }
                $fullLibraryPath = "$hostUrl$libraryServerRelativeUrl"
                Write-LogINFO "Library path for KQL: $fullLibraryPath"

                $ComplianceTaggedFiles = [System.Collections.Generic.List[object]]::new()
                $startRow = 0
                $totalRows = $null
                $maxResults = 5000

                do {
                    try {
                        $kqlQuery = "Path:`"$fullLibraryPath*`" AND IsDocument:true AND ComplianceTag:Record"
                        $selectProperties = "Title,Path,Filename,ComplianceTag,ContentTypeId,SPWebUrl"
                        $searchUrl = "$url/_api/search/query?querytext='$kqlQuery'&selectproperties='$selectProperties'&rowlimit=$rowLimit&startrow=$startRow&trimduplicates=false"

                        $response = Invoke-RestMethod -Uri $searchUrl -Method Get -Headers $headers
                        $relevantResults = $response.d.query.PrimaryQueryResult.RelevantResults

                        if ($null -eq $totalRows) {
                            $totalRows = [Math]::Min($relevantResults.TotalRows, $maxResults)
                            Write-LogINFO "Total compliance-tagged files found: $($relevantResults.TotalRows) (capped at $totalRows for processing)"
                        }

                        foreach ($row in $relevantResults.Table.Rows.results) {
                            $cellMap = @{}
                            foreach ($cell in $row.Cells.results) {
                                $cellMap[$cell.Key] = $cell.Value
                            }
                            $ComplianceTaggedFiles.Add([PSCustomObject]@{
                                FileName      = $cellMap["Filename"]
                                URL           = $cellMap["Path"]
                                ComplianceTag = $cellMap["ComplianceTag"]
                                ContentTypeId = $cellMap["ContentTypeId"]
                            })
                        }

                        $startRow += $rowLimit
                    }
                    catch {
                        Write-LogINFO "Error querying compliance tags in library $($library.Title): $($_.Exception.Message)"
                        break
                    }
                } while ($startRow -lt $totalRows)

                Write-LogINFO "[$($library.Title)] Compliance-tagged files retrieved from search API: $($ComplianceTaggedFiles.Count)"

                if ($null -ne $contentTypeDefinitions -and $ComplianceTaggedFiles.Count -gt 0) {
                    $wantedContentTypeIds = $contentTypeDefinitions |
                        Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name

                    Write-LogINFO "[$($library.Title)] Wanted content type IDs ($($wantedContentTypeIds.Count)): $($wantedContentTypeIds -join ', ')"

                    $contentTypeParentMap = if ($contentTypeParentMaps -and $contentTypeParentMaps.ContainsKey($library.Id.ToString())) {
                        $contentTypeParentMaps[$library.Id.ToString()]
                    } else {
                        Get-ContentTypeParentMap -libraryId $library.Id.ToString() -url $url -headers $headers
                    }

                    Write-LogINFO "[$($library.Title)] Content type parent map has $($contentTypeParentMap.Count) entries"

                    $beforeFilterCount = $ComplianceTaggedFiles.Count
                    $ComplianceTaggedFiles = @($ComplianceTaggedFiles | Where-Object {
                        $itemContentTypeId = $_.ContentTypeId
                        $matchesWantedType = $false
                        foreach ($wantedId in $wantedContentTypeIds) {
                            if ($wantedId -eq "0x0101") { continue }
                            if ($itemContentTypeId -like "$wantedId*") {
                                $matchesWantedType = $true
                                break
                            }
                        }
                        $parentId = $contentTypeParentMap[$itemContentTypeId]
                        $hasDocumentParent = $parentId -eq "0x0101"
                        -not $matchesWantedType -and -not $hasDocumentParent
                    })
                    Write-LogINFO "[$($library.Title)] Compliance-tagged files after content type filter: $($ComplianceTaggedFiles.Count) (removed $($beforeFilterCount - $ComplianceTaggedFiles.Count) of $beforeFilterCount)"
                }

                if ($ComplianceTaggedFiles.Count -gt 0) {
                    $libraryEntityTypeName = $library.EntityTypeName
                    $complianceTaggedFilesViews += createComplianceTaggedFilesView `
                        -Context $library.Context `
                        -Library $library `
                        -libraryEntityTypeName $libraryEntityTypeName `
                        -ComplianceTaggedFiles $ComplianceTaggedFiles `
                        -Language $language `
                        -ViewDefinitions $viewDefinitions
                }
            }
        }
        return $complianceTaggedFilesViews
    }
    Catch {
        Write-LogERR "Error collecting compliance-tagged files report! $($_.Exception.Message)"
        throw "Error collecting compliance-tagged files report! $($_.Exception.Message)"
    }
}

function createComplianceTaggedFilesView($Context, $library, $libraryEntityTypeName, $ComplianceTaggedFiles, $Language, $ViewDefinitions) {
    if ($null -eq $ViewDefinitions) {
        $ViewDefinitions = Get-Content "$global:CurrDir\configs\views.json" -Raw -Encoding utf8 | ConvertFrom-Json
    }

    if ([string]::IsNullOrEmpty($Language)) {
        $Language = "en-US"
    }

    $ViewDef = $ViewDefinitions.AllComplianceTaggedFiles
    $ViewName = $ViewDef.Name.$Language

    if ([string]::IsNullOrEmpty($ViewName)) {
        Write-LogWarn "ViewName is empty for language: $Language. Using fallback."
        $ViewName = "Compliance Tagged Files"
    }

    $View = CreateOrReplaceListView `
        -context $Context `
        -Library $library `
        -ViewName $ViewName `
        -ViewFields $ViewDef.Fields `
        -ViewQuery $ViewDef.Query.$Language `
        -ItemLimit $ViewDef.ItemLimit `
        -IsDefaultView $ViewDef.IsDefaultView `
        -CustomFormat $ViewDef.CustomFormat `
        -Recursive $ViewDef.Recursive
    $Context.Load($View)
    ExecuteQueryWithRetry -Ctx $Context

    $url = $library.ParentWebUrl
    if ($url -match "^(https?://[^/]+)") {
        $baseUrl = $matches[1]
        $viewUrl = "$baseUrl$($View.ServerRelativeUrl)"
    } else {
        $viewUrl = $url + $View.ServerRelativeUrl
    }

    $complianceTaggedFilesView = [PSCustomObject]@{
        LibraryName = $library.Title
        LibraryUrl  = "$url/$libraryEntityTypeName"
        ViewUrl     = $viewUrl
        ViewName    = $ViewName
        FileCount   = $ComplianceTaggedFiles.Count
        Files       = $ComplianceTaggedFiles
    }
    return $complianceTaggedFilesView
}

function exportCheckedOutFilesAsCsv($CheckedOutFiles) {

    if ($CheckedOutFiles.Count -eq 0) {
        return
    }

    Write-LogINFO "Exporting Checked Out Files to CSV File..."
    $ReportOutput = Join-Path (Get-RunbookTempDir) 'checked-out-files.csv'
    #Delete the Output Report, if exists
    if (Test-Path $ReportOutput) { Remove-Item $ReportOutput }
    #Export the Findings to CSV File
    $CheckedOutFiles | Export-CSV $ReportOutput -NoTypeInformation -Append
}
