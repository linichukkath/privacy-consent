# like the ups.ps1 this is just a mock file for a runbook environment for the migration

$script:logBuffer = [System.Text.StringBuilder]::new()

function Write-LogINFO {
    param($message)
    Write-Warning ('INFO: ' + $message)
    # $script:logBuffer is undefined when this function runs inside a runspace (e.g. private-channel QC workers) - init defensively so logging never throws
    if ($null -eq $script:logBuffer) { $script:logBuffer = [System.Text.StringBuilder]::new() }
    $script:logBuffer.AppendLine("[INFO]  $(Get-Date -Format 'HH:mm:ss') $message") | Out-Null
}

function Write-LogWarn {
    param($message)
    # Write-Warning goes to Warning stream, not output stream
    # No pipeline pollution
    Write-Warning ('WARN: ' + $message)
    if ($null -eq $script:logBuffer) { $script:logBuffer = [System.Text.StringBuilder]::new() }
    $script:logBuffer.AppendLine("[WARN]  $(Get-Date -Format 'HH:mm:ss') $message") | Out-Null
}

function Write-LogERR {
    param($message)
    # Write-Error goes to Error stream, not output stream
    # No pipeline pollution
    Write-Error ('ERROR: ' + $message)
    if ($null -eq $script:logBuffer) { $script:logBuffer = [System.Text.StringBuilder]::new() }
    $script:logBuffer.AppendLine("[ERROR] $(Get-Date -Format 'HH:mm:ss') $message") | Out-Null
}

function Get-RunbookTempDir {
    <#
    .SYNOPSIS
    Returns a writable scratch directory for reports and logs.

    .DESCRIPTION
    Never write beside the module. In an Azure Automation cloud sandbox the module is unpacked
    into a writable temp path, so "$global:CurrDir\temp" happened to work - but on a Hybrid
    Runbook Worker the module lives under C:\Program Files\WindowsPowerShell\Modules, which a
    non-admin RunAs account cannot write to. Prefer the process TEMP, fall back to the module
    directory, and probe each candidate with a real write because Test-Path succeeds on
    directories that still refuse writes.
    #>
    if ($script:runbookTempDir -and (Test-Path $script:runbookTempDir)) {
        return $script:runbookTempDir
    }

    $candidates = @()
    if ($env:TEMP) { $candidates += (Join-Path $env:TEMP 'dms-migration') }
    $candidates += (Join-Path ([System.IO.Path]::GetTempPath()) 'dms-migration')
    if ($global:CurrDir) { $candidates += (Join-Path $global:CurrDir 'temp') }

    foreach ($candidate in $candidates) {
        try {
            if (-not (Test-Path $candidate)) {
                New-Item -ItemType Directory -Path $candidate -Force -ErrorAction Stop | Out-Null
            }
            $probe = Join-Path $candidate ".write-probe-$PID"
            Set-Content -Path $probe -Value 'ok' -ErrorAction Stop
            Remove-Item $probe -Force -ErrorAction SilentlyContinue
            $script:runbookTempDir = $candidate
            return $candidate
        }
        catch {
            continue
        }
    }

    throw "No writable scratch directory available. Tried: $($candidates -join '; ')"
}

function Save-RunbookLog {
    param(
        [Parameter(Mandatory = $true)] [string]$JobId
    )
    try {
        $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
        $fileName = "RunbookLog-$JobId-$timestamp.txt"
        $tempDir = Get-RunbookTempDir
        $filePath = "$tempDir\$fileName"
        $script:logBuffer.ToString() | Out-File -FilePath $filePath -Encoding UTF8
        return @{ FilePath = $filePath; FileName = $fileName }
    }
    catch {
        Write-Warning "Failed to save runbook log: $($_.Exception.Message)"
        return $null
    }
}

function Get-CompanyIdFromUrl {
    <#
    .SYNOPSIS
    Extracts CompanyID (ECCS code) from SharePoint site URL.

    .DESCRIPTION
    Parses the SharePoint site URL to extract the CompanyID/ECCS code.
    Example: https://allianzms.sharepoint.com/teams/DE1214-8356243 -> DE1214

    .PARAMETER siteUrl
    The SharePoint site URL to parse.

    .EXAMPLE
    Get-CompanyIdFromUrl -siteUrl "https://allianzms.sharepoint.com/teams/DE1214-8356243"
    Returns: "DE1214"
    #>
    param (
        [Parameter(Mandatory = $true)]
        [string]$siteUrl
    )

    try {
        # Split URL by "/" and get the site name part (index 4)
        # Example: https://allianzms.sharepoint.com/teams/DE1214-8356243
        # Split result: ["https:", "", "allianzms.sharepoint.com", "teams", "DE1214-8356243"]
        $urlParts = $siteUrl.Split("/")

        if ($urlParts.Count -lt 5) {
            $null = Write-LogWarn "URL format is not as expected. Cannot extract CompanyID from: $siteUrl"
            return $null
        }

        # Get the site identifier part (e.g., "DE1214-8356243")
        $siteIdentifier = $urlParts[4]

        # Split by "-" and take the first part (CompanyID/ECCS)
        $companyId = $siteIdentifier.Split("-")[0]

        $null = Write-LogINFO "Extracted CompanyID from URL: $companyId"
        return $companyId
    }
    catch {
        $null = Write-LogERR "Error extracting CompanyID from URL: $($_.Exception.Message)"
        return $null
    }
}

function Get-CompanyId {
    <#
    .SYNOPSIS
    Retrieves CompanyID from SharePoint site property bag or URL.

    .DESCRIPTION
    First attempts to retrieve CompanyID from the site's property bag (customECCS).
    If not found, falls back to parsing the CompanyID from the site URL.

    .PARAMETER context
    The SharePoint ClientContext object.

    .PARAMETER siteUrl
    The SharePoint site URL (used as fallback if property bag doesn't contain CompanyID).

    .EXAMPLE
    Get-CompanyId -context $context -siteUrl "https://allianzms.sharepoint.com/teams/DE1214-8356243"
    #>
    param (
        [Parameter(Mandatory = $true)]
        [Microsoft.SharePoint.Client.ClientContext]$context,
        [Parameter(Mandatory = $true)]
        [string]$siteUrl
    )

    # First, try to get CompanyID from the property bag
    $null = Write-LogINFO "Attempting to retrieve CompanyID from site property bag (customECCS)..."
    $companyId = GetPropertyBag -Context $context -PropertyName 'customECCS'

    if ($null -ne $companyId -and $companyId -ne '') {
        $null = Write-LogINFO "CompanyID retrieved from property bag: $companyId"
        return $companyId
    }

    # If not found in property bag, parse it from the URL
    $null = Write-LogWarn "CompanyID not found in property bag. Parsing from URL..."
    $companyId = Get-CompanyIdFromUrl -siteUrl $siteUrl

    if ($null -eq $companyId -or $companyId -eq '') {
        $null = Write-LogERR "Could not retrieve CompanyID from property bag or parse from URL: $siteUrl"
        throw "COMPANY_ID_NOT_FOUND: Could not retrieve CompanyID from property bag or parse from URL: $siteUrl"
    }

    return $companyId
}

function Get-IsDMS {
    <#
    .SYNOPSIS
    Determines if a SharePoint site is a DMS site.

    .DESCRIPTION
    Retrieves the customSiteType property from the site's property bag.
    Returns $true if the site type is 'DMS', $false if it's 'E3' or not set.

    .PARAMETER context
    The SharePoint ClientContext object.

    .EXAMPLE
    $isDMS = Get-IsDMS -context $context
    #>
    param (
        [Parameter(Mandatory = $true)]
        [Microsoft.SharePoint.Client.ClientContext]$context
    )

    $null = Write-LogINFO "Attempting to retrieve site type from property bag (customSiteType)..."
    $siteType = GetPropertyBag -Context $context -PropertyName 'customSiteType'

    if ($null -ne $siteType -and $siteType -ne '') {
        $null = Write-LogINFO "Site type retrieved from property bag: $siteType"

        if ($siteType -eq 'DMS') {
            $null = Write-LogINFO "Site is a DMS site."
            return $true
        }
        elseif ($siteType -eq 'E3') {
            $null = Write-LogINFO "Site is an E3 site."
            return $false
        }
        else {
            $null = Write-LogWarn "Unknown site type: $siteType. Defaulting to E3 (not DMS)."
            return $false
        }
    }

    $null = Write-LogWarn "Site type not found in property bag. Defaulting to E3 (not DMS)."
    return $false
}

function Get-Language {
    <#
    .SYNOPSIS
    Retrieves the site language from SharePoint site property bag or uses heuristic detection.

    .DESCRIPTION
    First attempts to retrieve the customSiteLanguage property from the site's property bag.
    If not found, uses heuristic approach by checking the Document_Class field display name.
    Maps field display names to language codes:
    - 'Document Class' -> en-US
    - 'Classe de document' -> fr-FR
    - 'Categoria del documento' -> es-ES
    - 'Tipo di documento' -> it-IT
    - 'Dokumentenkategorie' or 'Dokumentenklasse' -> de-DE
    Defaults to 'en-US' if detection fails.

    .PARAMETER context
    The SharePoint ClientContext object.

    .EXAMPLE
    $language = Get-Language -context $context
    #>
    param (
        [Parameter(Mandatory = $true)]
        [Microsoft.SharePoint.Client.ClientContext]$context
    )

    # First try to search it in the property bag
    $null = Write-LogINFO "Attempting to retrieve site language from property bag (customSiteLanguage)..."
    $customSiteLanguage = GetPropertyBag -Context $context -PropertyName 'customSiteLanguage'

    if ($null -ne $customSiteLanguage -and $customSiteLanguage -ne '') {
        $null = Write-LogINFO "Language retrieved from property bag: $customSiteLanguage"
        return $customSiteLanguage
    }

    # If not found, try the heuristic approach to detect the language based on Document_Class column Display name
    $null = Write-LogWarn "Language not found in property bag. Using heuristic approach based on Document_Class field..."

    try {
        $web = $context.Web
        $fields = $web.Fields
        $context.Load($web)
        $context.Load($fields)
        ExecuteQueryWithRetry -Ctx $context
    }
    catch {
        $null = Write-LogWarn "Unable to identify site language via heuristic. $($_.Exception.Message)"
        $null = Write-LogINFO "Defaulting to 'en-US'."
        return 'en-US'
    }

    # Look for Document_Class or DocumentClass field
    $DocumentClassField = $fields | Where-Object -FilterScript { $_.InternalName -eq "Document_Class" }
    if ($null -eq $DocumentClassField) {
        $DocumentClassField = $fields | Where-Object -FilterScript { $_.InternalName -eq "DocumentClass" }
    }

    if ($null -eq $DocumentClassField) {
        $DisplayName = 'Document Class'
        $null = Write-LogWarn "Document_Class field not found. Using default display name: $DisplayName"
    }
    else {
        $DisplayName = $DocumentClassField.Title
        $null = Write-LogINFO "Document_Class field display name: $DisplayName"
    }

    # Map display name to language code
    $language = switch ($DisplayName) {
        'Document Class'            { "en-US"; break; }
        'Classe de document'        { "fr-FR"; break; }
        'Categoria del documento'   { "es-ES"; break; }
        'Tipo di documento'         { "it-IT"; break; }
        'Dokumentenkategorie'       { "de-DE"; break; }
        'Dokumentenklasse'          { "de-DE"; break; }
        default                     { "en-US"; break; }
    }

    $null = Write-LogINFO "Language identified for site: $language"
    return $language
}

function Get-ProvisioningParameters {
    <#
    .SYNOPSIS
    Returns a provisioning parameters hashtable for site provisioning runbooks.
    #>
    return @{
        RequestorEMail     = ''
        ResponseType       = ''
        SPO_CHANGE_LIBRARY = 'update_all_libraries'
        RequestorID        = ''
        RequestID          = ''
        OrdererEMail       = ''
        LogicalObject      = ''
        OE                 = ''
        OriginalRequest    = ''
        ProviderItem       = ''
        ManagerEMail       = ''
        RequestOperation   = ''
        SPOURL             = ''
        O365Admin          = ''
        ServiceInstanceID  = ''
        JobResubmitCount   = ''
        Port               = ''
        TransactionID      = ''
        Admin1             = ''
        Admin2             = ''
        Title              = 'Legacy E3 Site'
        CompanyID          = ''
        ProvisioningStatus = @('WorkloadCreated')
        Language           = 'en-US'
        CollabType         = ''
        IsDMS              = $true
    }
}

function Update-DBProvisioningParameter {
    [CmdletBinding(SupportsShouldProcess=$true)]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSReviewUnusedParameter', '', Justification = 'Parameter is used in UPS')]
    param([Parameter(Mandatory)]$JobParameters)

    if ($PSCmdlet.ShouldProcess("Database", "Update provisioning parameters")) {
        # no action needed for local testing
        # when used in Production, this function will replace the parameters in DB
    }
}

function Get-Password {
    <#
    .SYNOPSIS
    Retrieves password from Azure Automation Credential assets for Azure Runbook execution.

    .DESCRIPTION
    Retrieves credentials stored as Automation Credential assets in the Automation Account.
    This avoids DLL conflicts with Az modules and is the recommended approach for Azure Automation.

    .PARAMETER userName
    The username for which to retrieve the password. This will be used as the credential asset name.

    .PARAMETER PWOnly
    If specified, returns only the password string. Otherwise returns a PSCredential object.

    .PARAMETER vaultName
    Deprecated. Kept for backward compatibility but not used.

    .EXAMPLE
    Get-Password -userName "spo-ipg-pwd"
    Returns a PSCredential object from Automation Credential asset.

    .EXAMPLE
    Get-Password -userName "spo-ipg-pwd" -PWOnly
    Returns the password as a plain text string.

    .NOTES
    Requires Automation Credential asset with the name matching userName parameter.
    Create credentials in: Automation Account > Credentials > Add credential
    #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingConvertToSecureStringWithPlainText', '', Justification = 'Password is retrieved from Automation Credential')]
    param (
        [Parameter(Mandatory=$true)]
        [string]$userName,
        [Parameter(Mandatory=$false)]
        [string]$vaultName = 'dms-kv',  # Kept for backward compatibility
        [switch]$PWOnly
    )

    try {
        # userName is used as the Automation Credential asset name
        $credentialName = $userName
        Write-LogINFO "Retrieving credentials from Automation Credential asset: '$credentialName'..."
        Write-LogINFO "Calling Get-AutomationPSCredential with Name='$credentialName'..."

        # Retrieve credential from Automation Account
        try {
            $credentialResult = Get-AutomationPSCredential -Name $credentialName -ErrorAction Stop
            Write-LogINFO "Get-AutomationPSCredential returned: $($credentialResult.GetType().FullName)"

            # Handle case where Get-AutomationPSCredential returns an array
            if ($credentialResult -is [System.Array]) {
                Write-LogINFO "Result is an array with $($credentialResult.Count) elements. Taking first element."
                $credential = $credentialResult[0]
            } else {
                $credential = $credentialResult
            }

            Write-LogINFO "Credential object type: $($credential.GetType().FullName)"
        }
        catch {
            Write-LogERR "Error calling Get-AutomationPSCredential: $($_.Exception.Message)"
            Write-LogERR "Error Type: $($_.Exception.GetType().FullName)"
            throw
        }

        if ($null -eq $credential) {
            Write-LogERR "Credential '$credentialName' not found in Automation Account."
            throw "CREDENTIAL_NOT_FOUND: Automation Credential '$credentialName' not found. Please create it in Automation Account > Credentials."
        }

        # Validate credential object
        if ($credential -isnot [System.Management.Automation.PSCredential]) {
            Write-LogERR "Get-AutomationPSCredential returned unexpected type after array handling: $($credential.GetType().FullName)"
            Write-LogERR "Expected: System.Management.Automation.PSCredential"
            throw "INVALID_CREDENTIAL_TYPE: Unexpected credential type returned."
        }

        Write-LogINFO "Successfully retrieved credentials from Automation Credential asset."
        Write-LogINFO "Credential UserName: $($credential.UserName)"
        Write-LogINFO "Credential Password is SecureString: $($credential.Password -is [System.Security.SecureString])"

        if ($PWOnly.IsPresent) {
            # Extract password as plain text
            Write-LogINFO "Extracting password as plain text..."
            $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($credential.Password)
            try {
                $password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
                Write-LogINFO "Password extracted successfully (length: $($password.Length) characters)"
                return $password
            }
            finally {
                [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
            }
        }

        # Return the PSCredential object
        Write-LogINFO "Returning PSCredential object"
        return $credential
    }
    catch {
        $errorDetails = @"
Failed to retrieve credentials from Automation Account
Credential Name: $userName
Error: $($_.Exception.Message)
Error Type: $($_.Exception.GetType().FullName)
Stack Trace: $($_.ScriptStackTrace)

Note: Ensure Automation Credential asset named '$userName' exists in:
Automation Account > Credentials > Add credential
"@
        Write-LogERR $errorDetails
        throw
    }
}
