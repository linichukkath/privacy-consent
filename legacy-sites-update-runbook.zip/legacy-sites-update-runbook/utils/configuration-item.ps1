class ConfigurationItem {
    [string]$Key
    [string]$Action

    ConfigurationItem([string]$key, [string]$action) {
        $this.Key = $key
        $this.Action = $action
    }
}

function ConvertFromJson($items) {
    $configurationItems = @()
    foreach ($item in $items) {
        $configurationItem = [ConfigurationItem]::new($item.Key, $item.Action)
        $configurationItems += $configurationItem
    }
    return $configurationItems
}

Function overrideSettings($Config, $Overrides) {
    try {
        if ($null -ne $Overrides) {
            $Overrides.PSObject.Properties | ForEach-Object {
                $prop = $_.Name
                if (-not $Config.PSObject.Properties.Name.Contains($prop)) {
                    $Config | Add-Member -MemberType NoteProperty -Name $prop -Value $_.Value
                } else {
                    $Config.$prop = $_.Value
                }
            }
        }
    }
    catch {
        Write-LogERR "Error in overriding config settings " $_.Exception.Message
    }
}

Function overrideViewSettings($SiteViewConfig, $ViewOverrides) {
    foreach ($ConfigItem in $ViewOverrides) {
        if ($null -ne $ConfigItem.Overrides) {
            $viewName = $ConfigItem.Key
            $ConfigItem.Overrides.PSObject.Properties | ForEach-Object {
                $prop = $_.Name
                $SiteViewConfig.$viewName.$prop = $_.Value
            }
        }
    }
}