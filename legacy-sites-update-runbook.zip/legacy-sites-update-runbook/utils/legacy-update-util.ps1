# When loaded as part of the module, all dependencies are already imported by the .psm1
# Only import when running standalone (e.g., from UPS workflows)
if (-not (Get-Module legacy-sites-update-runbook)) {
    Import-Module "$global:CurrDir\utils\interceptor.ps1"
    Import-Module "$global:CurrDir\utils\auth.ps1"
    Import-Module "$global:CurrDir\utils\site.ps1"
    Import-Module "$global:CurrDir\utils\columns.ps1"
    Import-Module "$global:CurrDir\utils\content-types.ps1"
    Import-Module "$global:CurrDir\utils\library.ps1"
    Import-Module "$global:CurrDir\utils\property-bag.ps1"
    Import-Module "$global:CurrDir\utils\update-utils.ps1"
    Import-Module "$global:CurrDir\utils\checked-out-files-detection.ps1"

    # Import integration test (ValidateSite). In the runbook environment this is
    # loaded by the .psm1; when running standalone (UPS workflows) we load it here.
    $integrationTestPath = "$global:CurrDir\tests\integration-test.ps1"
    if (Test-Path $integrationTestPath) {
        Import-Module $integrationTestPath
    }
}
Function updateSite($context, $languageUPS, $updateConfig, $contentTypeDefinitions, $LibraryDefinitions, $ViewDefinitions, $SiteConfigPath, $libraryUrl, $companyID, $siteType) {
    $url = $context.Web.Url
    $beforeUpdateRows = @()
    $afterUpdateRows = @()
    $result = [PSCustomObject]@{
        Success = $true
        SiteUrl = $url
        CheckedOutFilesReport = $null
        ComplianceTaggedFilesReport = $null
        ContentTypeCountReportRows = @()
        ItemChanges = @()
        BeforeCtCounts = @{}
        UpdatedCount = 0
        FailedCount = 0
        CountsIncomplete = $false
        ItemMigrationReportUrl = $null
        ContentTypeSummaryReportUrl = $null
        Message = ""
        Errors = @()
    }

    try {
        # Enable custom scripting FIRST (required before any view creation or site modifications)
        if ($tenantConnected) {
            try {
                SetSiteScripting $true $url
                Write-LogINFO "Custom scripting enabled successfully"
            }
            catch {
                Write-LogWARN "Could not enable custom scripting: $($_.Exception.Message)"
                Write-LogWARN "View creation and site modifications may fail with 'Additions blocked' error"
            }
        } else {
            Write-LogWARN "Not connected to SharePoint tenant - cannot enable custom scripting"
            Write-LogWARN "View creation and site modifications may fail with 'Additions blocked' error"
        }

        Write-LogINFO "Looking for all the updatable document libraries..."
        if (-not[string]::IsNullOrEmpty($libraryUrl)) {
            $Libraries = getLibraryByUrl -libraryUrl $libraryUrl -url $url -tenant $tenant
        }
        else {
            $libraryIgnoreConfigPath = "$global:CurrDir\configs\library-ignore.json"
            $libraryIgnoreConfig = Get-Content $libraryIgnoreConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $Libraries = GetAllDocumentLibraries -Ctx $context -Config $libraryIgnoreConfig
            Write-LogINFO "Number of updatable document libraries found: $($Libraries.Count)"
        }

        $beforeUpdateRows = @(GetLibraryContentTypeDocumentCountRows -libraries $Libraries -phase "Before" -checkedDate (Get-Date))
        $result.ContentTypeCountReportRows = $beforeUpdateRows

        # QC (checked-out files / compliance tags) is already run upfront in startLegacyUpdate; not repeated here
        Write-LogINFO "Renaming legacy content types at site level"
        $contentTypes = $context.Web.ContentTypes
        $Context.Load($ContentTypes)
        ExecuteQueryWithRetry -ctx $Context
        RenameLegacyContentTypes -context $context -updateConfig $updateConfig -contentTypes $contentTypes
        RenameContentTypesWithoutWantedIDs -context $context -contentTypeDefinitions $contentTypeDefinitions -language $language -contentTypes $contentTypes

        $LibraryDefaultValues = @{}
        foreach ($Library in $Libraries) {
            Write-LogINFO "Renaming all the legacy content types in library - $($Library.Title)"
            $libraryContentTypes = $Library.ContentTypes
            $LibraryContext = $Library.Context
            $LibraryContext.Load($libraryContentTypes)
            ExecuteQueryWithRetry -ctx $LibraryContext
            $LibraryDefaultValues[$Library.Id.ToString()] = GetManagedMetadataDefaultValue -Context $LibraryContext -Library $Library
            RenameLegacyContentTypes -context $LibraryContext -updateConfig $updateConfig -contentTypes $libraryContentTypes
            RenameContentTypesWithoutWantedIDs -context $LibraryContext -contentTypeDefinitions $contentTypeDefinitions -language $language -contentTypes $libraryContentTypes
        }

        RenameLegacyColumns -context $context -updateConfig $updateConfig
        EnableSPOFeatures -context $Context
        ProvisionSiteColumns -context $Context -Config $updateConfig -language $language -companyID $companyID
        ProvisionSiteContentTypes -context $Context -Config $updateConfig -language $language

        # Views and library content types
        Write-LogINFO 'Provisioning libraries'
        $DefaultLibraryEntityTypeName = $updateConfig.DefaultLibraryConfigKey
        $LibraryConfig = $LibraryDefinitions.$DefaultLibraryEntityTypeName

        $SiteConfig = Get-Content $SiteConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $LibraryConfigItem = $SiteConfig.Libraries[0]

        overrideSettings $LibraryConfig $LibraryConfigItem.Overrides

        # temporarily remove the DeleteColumns from the library config to avoid data loss (during items updating)
        $DeleteColumns = [System.Management.Automation.PSSerializer]::Deserialize([System.Management.Automation.PSSerializer]::Serialize($LibraryConfig.DeleteColumns))
        $LibraryConfig.DeleteColumns = $null

        foreach ($Library in $Libraries) {
            $LibraryContext = $Library.Context
            $DefaultColumnValues = $LibraryDefaultValues[$Library.Id.ToString()]
            UpdateLibrary -context $LibraryContext -libraryConfig $LibraryConfig -library $Library -defaultLibraryEntityTypeName $DefaultLibraryEntityTypeName -viewDefinitions $ViewDefinitions -ViewsConfig $updateConfig.Views -language $language -DefaultColumnValues $DefaultColumnValues
        }

        # restore the DeleteColumns to the library config
        $LibraryConfig.DeleteColumns = $DeleteColumns

        # items updating
        $documentClassTerms = getDocumentClassTerms -context $context
        $timeZoneOffset = getTimezoneOffset -ctx $context
        $exceptions = @()
        $allItemChanges = @()
        $allBeforeCtCounts = @{}
        # Counts are tracked separately from ItemChanges because the webhook dispatch path returns
        # totals without per-item records - the children hold those.
        $siteUpdatedCount = 0
        $siteFailedCount = 0
        $siteCountsIncomplete = $false
        # Per-library consolidated report URLs, merged into one site-level report after the loop.
        $libraryItemReportUrls = @()
        $libraryCtReportUrls = @()
        foreach ($Library in $Libraries) {
            Write-LogINFO "Updating items in library - $($Library.Title)"
            $parentWebUrl = $Library.ParentWebUrl
            $siteUrlOfLibrary = "https://$tenant.sharepoint.com$parentWebUrl"

            $updateResult = updateItems `
                -siteUrl $siteUrlOfLibrary `
                -libraryGUID $Library.Id.ToString() `
                -libraryTitle $Library.Title `
                -contentTypesConfig $contentTypeDefinitions `
                -documentClassTerms $documentClassTerms `
                -updateConfig $updateConfig `
                -language $language `
                -timeZoneOffset $timeZoneOffset `
                -context $context `
                -maxParallelThreads 8
            $exceptions += $updateResult.Exceptions
            $allItemChanges += $updateResult.ItemChanges
            MergeCtCounts -target $allBeforeCtCounts -source $updateResult.BeforeCtCounts

            # In-process path: counts come from the records. Webhook path: from the child totals.
            if ($null -ne $updateResult.WebhookDispatch) {
                $siteUpdatedCount += [int]$updateResult.UpdatedCount
                $siteFailedCount += [int]$updateResult.FailedCount
                if (@($updateResult.WebhookDispatch.JobsWithoutResult).Count -gt 0) { $siteCountsIncomplete = $true }
                if ($updateResult.WebhookDispatch.ItemReportUrl) { $libraryItemReportUrls += [string]$updateResult.WebhookDispatch.ItemReportUrl }
                if ($updateResult.WebhookDispatch.ContentTypeReportUrl) { $libraryCtReportUrls += [string]$updateResult.WebhookDispatch.ContentTypeReportUrl }
            }
            else {
                $siteUpdatedCount += @($updateResult.ItemChanges).Count
                $siteFailedCount += @($updateResult.Exceptions).Count
            }

            $LibraryContext = $Library.Context
            deleteColumnsFromLibrary -context $LibraryContext -libraryConfig $LibraryConfig -library $Library # here the not needed columns are deleted from the library, which is normally done during the library updating
            removeLegacyColumnsFromLibrary -context $LibraryContext -library $Library # here the not needed columns are deleted from the library, which is normally done during the library updating
        }

        Write-LogINFO "=== Item update summary for $url ==="
        Write-LogINFO "  Libraries processed : $(@($Libraries).Count)"
        Write-LogINFO "  Items updated       : $siteUpdatedCount"
        Write-LogINFO "  Items failed        : $siteFailedCount"
        if ($siteCountsIncomplete) {
            Write-LogWarn "  Totals are incomplete - at least one batch job reported no result. See the per-batch lines above."
        }

        # Merge the per-library reports into one file per site. Libraries on subsites keep their
        # report in their own SiteAssets, so the sources span several webs - the consolidation
        # helpers resolve each source's web from its URL. Reporting must never fail a migration
        # whose items are already updated, so the whole block is non-fatal.
        if ($libraryItemReportUrls.Count -gt 0 -or $libraryCtReportUrls.Count -gt 0) {
            try {
                $siteReportTimestamp = Get-Date -Format 'dd-MM-yyyy_HH-mm-ss'
                $siteReportToken = Get-AzureADAccessToken `
                    -tenantId $context.AuthState.TenantId `
                    -clientId $context.AuthState.ClientId `
                    -clientSecret $context.AuthState.ClientSecret `
                    -certificate $context.AuthState.Certificate `
                    -resourceUrl $url
                $siteReportHeaders = @{
                    Authorization = "Bearer $siteReportToken"
                    Accept        = "application/json;odata=verbose"
                    ContentType   = "application/json;odata=verbose"
                }

                if ($libraryItemReportUrls.Count -gt 0) {
                    $siteItemReportUrl = New-UpdateItemsConsolidatedItemReport `
                        -SourceUrls $libraryItemReportUrls -TargetSiteUrl $url -Headers $siteReportHeaders `
                        -TargetFileName "DMS-Item-Migration-Report-$companyId-$siteReportTimestamp.csv" `
                        -Context $context
                    if ($siteItemReportUrl) {
                        Write-LogINFO "  Site item migration report: $siteItemReportUrl"
                        $result.ItemMigrationReportUrl = $siteItemReportUrl
                        foreach ($reportUrl in $libraryItemReportUrls) {
                            if ($reportUrl -eq $siteItemReportUrl) { continue }
                            $location = Get-UpdateItemsSiteAssetLocation -Url $reportUrl
                            if ($null -ne $location) { $null = Remove-UpdateItemsSiteAssetFile -SiteUrl $location.SiteUrl -Headers $siteReportHeaders -FileName $location.FileName }
                        }
                    }
                }

                if ($libraryCtReportUrls.Count -gt 0) {
                    $siteCtReportUrl = New-UpdateItemsConsolidatedContentTypeReport `
                        -SourceUrls $libraryCtReportUrls -TargetSiteUrl $url -Headers $siteReportHeaders `
                        -TargetFileName "DMS-ContentType-Summary-Report-$companyId-$siteReportTimestamp.csv" `
                        -Context $context
                    if ($siteCtReportUrl) {
                        Write-LogINFO "  Site content type summary report: $siteCtReportUrl"
                        $result.ContentTypeSummaryReportUrl = $siteCtReportUrl
                        foreach ($reportUrl in $libraryCtReportUrls) {
                            if ($reportUrl -eq $siteCtReportUrl) { continue }
                            $location = Get-UpdateItemsSiteAssetLocation -Url $reportUrl
                            if ($null -ne $location) { $null = Remove-UpdateItemsSiteAssetFile -SiteUrl $location.SiteUrl -Headers $siteReportHeaders -FileName $location.FileName }
                        }
                    }
                }
            }
            catch {
                Write-LogWarn "  Could not build the site-level reports: $($_.Exception.Message)"
                foreach ($reportUrl in $libraryItemReportUrls) { Write-LogINFO "    $reportUrl" }
                foreach ($reportUrl in $libraryCtReportUrls) { Write-LogINFO "    $reportUrl" }
            }
        }

        if ($exceptions.Count -gt 0) {
            printExceptions -exceptions $exceptions
            saveExceptionsToFile -exceptions $exceptions

            # Re-acquire token - the original one from line 59 may have expired during long-running CSOM operations
            $freshToken = Get-AzureADAccessToken `
                -tenantId $context.AuthState.TenantId `
                -clientId $context.AuthState.ClientId `
                -clientSecret $context.AuthState.ClientSecret `
                -certificate $context.AuthState.Certificate `
                -resourceUrl $context.AuthState.SiteUrl
            $headers = @{
                Authorization = "Bearer $freshToken"
                Accept        = "application/json;odata=verbose"
                ContentType   = "application/json;odata=verbose"
            }

            uploadFileToSiteAssets `
                -siteUrl $url `
                -headers $headers `
                -sourceFilePath (Join-Path (Get-RunbookTempDir) 'exceptions.csv') `
                -targetFileName "UpdateErrorReport-$(Get-Date -Format 'dd-MM-yyyy HH-mm-ss').csv" `
                -context $context
        }

        foreach ($Library in $Libraries) {
            Write-LogINFO "Removing all the legacy content types in library - $($Library.Title)"
            $LibraryContext = $Library.Context
            $libraryContentTypes = $Library.ContentTypes
            $LibraryContext.Load($libraryContentTypes)
            ExecuteQueryWithRetry -ctx $LibraryContext
            RemoveLegacyContentTypes -context $LibraryContext -contentTypes $libraryContentTypes
        }

        Write-LogINFO "Removing legacy content types at site level"
        $contentTypes = $context.Web.ContentTypes
        $Context.Load($ContentTypes)
        ExecuteQueryWithRetry -ctx $Context
        RemoveLegacyContentTypes -context $Context -contentTypes $contentTypes

        # TODO map the new property bags
        $retentionPeriod = getRetentionPeriod -companyID $companyId
        $propertyBagValues = @{
            customECCS            = $companyId
            customSiteUpdatedOn   = Get-Date
            customSiteLanguage    = $language
            customRetentionPeriod = $retentionPeriod
            customOriginType      = 'E3'
            customSiteVersion     = 10
            customSiteType        = $siteType
        }
        SetPropertyBagValues `
            -Context $Context `
            -Properties $propertyBagValues `
            -IndexablePropertyNames @($propertyBagValues.Keys)

        ListAllCustomPropertyBagItems -context $context

        $afterUpdateRows = @(GetLibraryContentTypeDocumentCountRows -libraries $Libraries -phase "After" -checkedDate (Get-Date))
        $result.ContentTypeCountReportRows = @(MergeContentTypeCountRows -beforeRows $beforeUpdateRows -afterRows $afterUpdateRows)
        $result.ItemChanges = $allItemChanges
        $result.BeforeCtCounts = $allBeforeCtCounts
        $result.UpdatedCount = $siteUpdatedCount
        $result.FailedCount = $siteFailedCount
        $result.CountsIncomplete = $siteCountsIncomplete

        # Re-disable custom scripting (requires tenant connection)
        if ($tenantConnected) {
            try {
                SetSiteScripting -isAllowed $false -url $url
                Write-LogINFO "Custom scripting disabled (site secured)"
            }
            catch {
                Write-LogWARN "Could not re-disable custom scripting"
                Write-LogWARN "Note: Site will remain with custom scripting enabled"
                Write-LogWARN "Error: $($_.Exception.Message)"
            }
        } else {
            Write-LogWARN "Skipping custom scripting disable (not connected to tenant)"
            Write-LogWARN "Note: Site will remain with custom scripting enabled"
        }
        Write-LogInfo "Successfully updated SP Site: $url"
        return $result
    }
    catch {
        Write-LogERR "Error updating SP Site: $url : $($_.Exception.Message) at line $($_.InvocationInfo.ScriptLineNumber): $($_.InvocationInfo.Line)"
        $result.Success = $false
        return $result
    }
}

Function Test-SiteQualityCheck($context, $contentTypeDefinitions, $libraryUrl, $tenant) {
    $url = $context.Web.Url
    if ([string]::IsNullOrEmpty($url)) {
        # Context was just created (e.g. fresh per-runspace context) and Web was never loaded from the server
        $context.Load($context.Web)
        ExecuteQueryWithRetry -ctx $context
        $url = $context.Web.Url
    }
    $result = [PSCustomObject]@{
        Success                     = $true
        SiteUrl                     = $url
        CheckedOutFilesReport       = $null
        ComplianceTaggedFilesReport = $null
    }

    try {
        if (-not[string]::IsNullOrEmpty($libraryUrl)) {
            $Libraries = getLibraryByUrl -libraryUrl $libraryUrl -url $url -tenant $tenant
        }
        else {
            $libraryIgnoreConfigPath = "$global:CurrDir\configs\library-ignore.json"
            $libraryIgnoreConfig = Get-Content $libraryIgnoreConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $Libraries = GetAllDocumentLibraries -Ctx $context -Config $libraryIgnoreConfig
        }

        $accessToken = Get-AzureADAccessToken `
            -tenantId $context.AuthState.TenantId `
            -clientId $context.AuthState.ClientId `
            -clientSecret $context.AuthState.ClientSecret `
            -certificate $context.AuthState.Certificate `
            -resourceUrl $context.AuthState.SiteUrl

        $headers = @{
            Authorization = "Bearer $accessToken"
            Accept        = "application/json;odata=verbose"
            ContentType   = "application/json;odata=verbose"
        }

        $contentTypeParentMaps = @{}
        foreach ($library in ($Libraries | Where-Object { $_.BaseTemplate -eq 101 -and $_.Hidden -eq $false })) {
            $libUrl = $url
            if ($libUrl -notlike "*$($library.ParentWebUrl)*") {
                $basePath = $libUrl -replace "^https?://[^/]+", ""
                $uniquePath = if ($library.ParentWebUrl -like "$basePath*") {
                    $library.ParentWebUrl.Substring($basePath.Length)
                } else { $library.ParentWebUrl }
                $libUrl = "$libUrl$uniquePath"
            }
            $contentTypeParentMaps[$library.Id.ToString()] = Get-ContentTypeParentMap `
                -libraryId $library.Id.ToString() -url $libUrl -headers $headers
        }

        $checkedOutFilesViews = @(getAllCheckedOutFiles `
            -libraries $Libraries -siteUrl $url -headers $headers `
            -contentTypeDefinitions $contentTypeDefinitions `
            -contentTypeParentMaps $contentTypeParentMaps)
        $complianceTaggedFilesViews = @(getAllFilesWithComplianceTags `
            -libraries $Libraries -siteUrl $url -headers $headers `
            -contentTypeDefinitions $contentTypeDefinitions `
            -contentTypeParentMaps $contentTypeParentMaps)

        $siteType = if ($context.Web.WebTemplate -eq "TEAMCHANNEL") { "Private Channel" } else { "Site" }

        if ($checkedOutFilesViews.Count -gt 0) {
            $totalCheckedOut = ($checkedOutFilesViews | Measure-Object -Property FileCount -Sum).Sum
            $result.CheckedOutFilesReport = [PSCustomObject]@{
                SiteUrl        = $url
                SiteType       = $siteType
                TotalFileCount = $totalCheckedOut
                LibraryCount   = $checkedOutFilesViews.Count
                GeneratedDate  = Get-Date
                Views          = $checkedOutFilesViews
            }
        }

        if ($complianceTaggedFilesViews.Count -gt 0) {
            $totalTagged = ($complianceTaggedFilesViews | Measure-Object -Property FileCount -Sum).Sum
            $result.ComplianceTaggedFilesReport = [PSCustomObject]@{
                SiteUrl        = $url
                SiteType       = $siteType
                TotalFileCount = $totalTagged
                LibraryCount   = $complianceTaggedFilesViews.Count
                GeneratedDate  = Get-Date
                Views          = $complianceTaggedFilesViews
            }
        }

        $result.Success = (-not $result.CheckedOutFilesReport) -and (-not $result.ComplianceTaggedFilesReport)
        return $result
    }
    catch {
        Write-LogERR "Error running quality check for site: $url : $($_.Exception.Message)"
        $result.Success = $false
        return $result
    }
}

Function getLibraryByUrl($libraryUrl, $url, $tenant) {
    try{
        $libraryUrl = [System.Web.HttpUtility]::UrlDecode($libraryUrl)
        $urlParts = $libraryUrl.Replace($url + "/", '').split('/')
        $parentWebUrl = $libraryUrl.Remove($libraryUrl.IndexOf($urlParts[0])).Replace("https://$tenant.sharepoint.com", '').TrimEnd('/')
        $siteUrlOfLibrary = "https://$tenant.sharepoint.com$parentWebUrl"
        if ($urlParts.Count -gt 3) {
            $siteUrlOfLibrary = "https://$tenant.sharepoint.com$parentWebUrl/" + $urlParts[0]
        }
        $LibraryEntityTypeName = $urlParts[$urlParts.Count - 3]
        # Use ACS OAuth authentication (client secret) instead of IDCRL
        $librarySiteContext = GetSPOContext -siteUrl $siteUrlOfLibrary
        return GetListByEntityTypeName -Context $librarySiteContext -EntityTypeName $LibraryEntityTypeName
    } catch {
        Write-LogERR "Error getting library by URL: $libraryUrl : $($_.Exception.Message)"
        return $null
    }
}

Function startLegacyUpdate($url, $context, $languageUPS, $LibraryDefinitions, $ViewDefinitions, $isSourceDMSUpgrade, $libraryUrl, $companyID, $tenant, $isDMSUPS, $tenantConnected = $false) {

    $isPrivateChannelSite = $false

    if ($isSourceDMSUpgrade) {
        $configPath = "$global:CurrDir\configs\e3.json"
        $updateConfigPath = "$global:CurrDir\configs\legacy-to-e3-update.json"
        $updateConfig = Get-Content $updateConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($null -ne $updateConfig.Views) {
            OverrideViewSettings $ViewDefinitions $updateConfig.Views
        }
    }
    else {
        $context.Load($context.Web)
        ExecuteQueryWithRetry -ctx $Context
        $rootSiteContext = $context
        if ($context.Web.WebTemplate -eq "TEAMCHANNEL") {
            $isPrivateChannelSite = $true
            Write-LogINFO "Private channel detected. Getting the parent site details."
            $parentUrl = GetParentTeamSiteUrl -privateChannelUrl $url
            if($null -ne $parentUrl) {
                $rootSiteContext = GetSPOContext -siteUrl $parentUrl `
                    -clientId $context.AuthState.ClientId `
                    -clientSecret $context.AuthState.ClientSecret `
                    -tenantId $context.AuthState.TenantId `
                    -certificate $context.AuthState.Certificate
            }
        }
        $siteType = GetPropertyBag -Context $rootSiteContext -PropertyName 'customSiteType'
        if ($siteType -eq "DMS") {
            $configPath = "$global:CurrDir\configs\e5.json"
            $updateConfigPath = "$global:CurrDir\configs\legacy-to-e5-update.json"
            Write-LogInfo "DMS site detected. Using e5 config."
        }
        else {
            $configPath = "$global:CurrDir\configs\e3.json"
            $updateConfigPath = "$global:CurrDir\configs\legacy-to-e3-update.json"
            Write-LogInfo "E3 site detected. Using e3 config."
        }
        $updateConfig = Get-Content $updateConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if($null -eq $languageUPS) {
            $language = GetSiteLanguage -context $rootSiteContext -web $context.Web
        }
        else {
            $language = $languageUPS
        }
        $LibraryDefinitions = Get-Content "$global:CurrDir\configs\libraries.json" -Raw -encoding utf8 | ConvertFrom-Json
        $ViewDefinitions = Get-Content "$global:CurrDir\configs\views.json" -Raw -encoding utf8 | ConvertFrom-Json
        if ($null -ne $updateConfig.Views) {
            OverrideViewSettings $ViewDefinitions $updateConfig.Views
        }
    }
    $contentTypeDefinitions = Get-Content "$global:CurrDir\configs\content-types.json" -Raw -Encoding UTF8 | ConvertFrom-Json

    $contentTypeCountReportRows = @()
    $allItemChanges = @()
    $allBeforeCtCounts = @{}

    # Discover private channels up-front and verify each one is reachable (read-only; never updated).
    # The actual ClientContext used for quality-checking is created fresh per-runspace below - CSOM's
    # ClientContext is not thread-safe, so a context created here on the main thread must never be handed
    # into a runspace-pool worker thread (doing so previously caused concurrent QC runs to cross-contaminate
    # each other's Web/Lists data, e.g. one channel's scan reporting libraries that belong to a different channel).
    # Skipped entirely when $url is itself a private channel - private channels have no channels of their own
    $PrivateChannels = @()
    if (($null -eq $libraryUrl) -and ($isSourceDMSUpgrade -eq $false) -and (-not $isPrivateChannelSite)) {
        try {
            $PrivateChannels = GetPrivateChannels -url $url -context $context
        }
        catch {
            Write-LogWarn "Could not retrieve private channels: $($_.Exception.Message)"
            $PrivateChannels = @()
        }
        $reachableChannels = @()
        foreach ($channel in $PrivateChannels) {
            try {
                $channelContext = GetSPOContext -siteUrl $channel.Url `
                    -clientId $context.AuthState.ClientId `
                    -clientSecret $context.AuthState.ClientSecret `
                    -tenantId $context.AuthState.TenantId `
                    -certificate $context.AuthState.Certificate
                $channelContext.Load($channelContext.Web)
                ExecuteQueryWithRetry -ctx $channelContext
                $reachableChannels += $channel
            } catch {
                Write-LogERR "Error creating context for $($channel.Url): $_"
            }
        }
        $PrivateChannels = $reachableChannels
    }

    # Run quality checks on the main site and all private channels in parallel.
    # Only the main site's result gates the update below; private channels are checked but never updated.
    $qcTargets = @([PSCustomObject]@{ Url = $url; LibraryUrl = $libraryUrl; Label = "Main site"; IsMain = $true })
    foreach ($channel in $PrivateChannels) {
        $qcTargets += [PSCustomObject]@{ Url = $channel.Url; LibraryUrl = $null; Label = "Private channel"; IsMain = $false }
    }

    # Every function Test-SiteQualityCheck (transitively) calls must be shipped into the worker runspaces
    $qcFunctionNames = @(
        'Test-SiteQualityCheck', 'getLibraryByUrl', 'GetSPOContext', 'GetListByEntityTypeName',
        'GetAllDocumentLibraries', 'Get-AzureADAccessToken', 'Get-ContentTypeParentMap',
        'getAllCheckedOutFiles', 'getAllFilesWithComplianceTags', 'Invoke-CheckedOutFileRestGetWithRetry',
        'Get-RestErrorBody', 'createCheckedOutFilesView', 'createComplianceTaggedFilesView',
        'CreateOrReplaceListView', 'ExecuteQueryWithRetry', 'Write-LogINFO', 'Write-LogWarn', 'Write-LogERR',
        'Get-RunbookTempDir'
    )
    $qcIss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    foreach ($fnName in $qcFunctionNames) {
        $fnCommand = Get-Command -Name $fnName -CommandType Function -ErrorAction SilentlyContinue
        if ($fnCommand) {
            $qcIss.Commands.Add([System.Management.Automation.Runspaces.SessionStateFunctionEntry]::new($fnName, $fnCommand.Definition))
        }
    }
    $qcIss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('CurrDir', $global:CurrDir, $null))

    $qcScript = {
        param($TargetUrl, $ClientId, $ClientSecret, $TenantId, $Certificate, $ContentTypeDefinitions, $TargetLibraryUrl, $Tenant)
        # ClientContext must be created on this same worker thread - never pass a context built on another thread into a runspace
        $freshContext = GetSPOContext -siteUrl $TargetUrl -clientId $ClientId -clientSecret $ClientSecret -tenantId $TenantId -certificate $Certificate
        Test-SiteQualityCheck -context $freshContext -contentTypeDefinitions $ContentTypeDefinitions -libraryUrl $TargetLibraryUrl -tenant $Tenant
    }

    # Never hand $Host to the pool. In Azure Automation $Host is the sandbox host that relays
    # every record to the Automation job stream; pool runspaces share that single object, and a
    # write from a worker thread kills the relay for the rest of the job - the runbook keeps
    # running but nothing more appears in the job output. Use the (iss) overload, which gives the
    # pool a private default host, and widen min/max afterwards.
    $qcPool = [RunspaceFactory]::CreateRunspacePool($qcIss)
    $null = $qcPool.SetMaxRunspaces([Math]::Min($qcTargets.Count, 8))
    $null = $qcPool.SetMinRunspaces(1)
    $qcPool.ApartmentState = "MTA"
    $qcPool.Open()

    $qcRunResults = @()
    try {
        $qcRunspaces = @()
        foreach ($target in $qcTargets) {
            Write-LogINFO "Dispatching quality check for $($target.Label): $($target.Url)"
            $runspace = [PowerShell]::Create()
            $runspace.RunspacePool = $qcPool
            $null = $runspace.AddScript($qcScript).
                AddArgument($target.Url).
                AddArgument($context.AuthState.ClientId).
                AddArgument($context.AuthState.ClientSecret).
                AddArgument($context.AuthState.TenantId).
                AddArgument($context.AuthState.Certificate).
                AddArgument($contentTypeDefinitions).
                AddArgument($target.LibraryUrl).
                AddArgument($tenant)
            $qcRunspaces += [PSCustomObject]@{ Target = $target; Pipe = $runspace; Status = $runspace.BeginInvoke() }
        }

        # Drain each worker's streams WHILE it runs instead of blocking on EndInvoke first.
        # A worker's Write-Log* calls land in its own runspace's Warning/Error streams, and
        # replaying them only after the pipeline finished meant the master job printed nothing at
        # all for the whole QC phase. On a small site that is a 15 second gap nobody notices; on a
        # large one the QC enumerates every item in every library and the silence lasts long enough
        # to be indistinguishable from a hang.
        foreach ($run in $qcRunspaces) {
            $run | Add-Member -NotePropertyName WarningCursor -NotePropertyValue 0 -Force
            $run | Add-Member -NotePropertyName ErrorCursor -NotePropertyValue 0 -Force
        }
        $pendingRuns = [System.Collections.Generic.List[object]]::new()
        foreach ($run in $qcRunspaces) { $pendingRuns.Add($run) }

        $drainQcStreams = {
            param($Run)
            $label = "[$($Run.Target.Label): $($Run.Target.Url)]"
            # Indexing a live PSDataCollection can race with the worker appending to it; a missed
            # record must never abort the migration, so failures here are swallowed and picked up
            # on the next pass.
            try {
                $warningStream = $Run.Pipe.Streams.Warning
                while ($Run.WarningCursor -lt $warningStream.Count) {
                    Write-LogWarn "$label $($warningStream[$Run.WarningCursor].Message)"
                    $Run.WarningCursor++
                }
                $errorStream = $Run.Pipe.Streams.Error
                while ($Run.ErrorCursor -lt $errorStream.Count) {
                    Write-LogERR "$label $($errorStream[$Run.ErrorCursor].Exception.Message)"
                    $Run.ErrorCursor++
                }
            }
            catch {
                Write-LogWarn "$label could not read worker stream this pass: $($_.Exception.Message)"
            }
        }

        $qcWaitStarted = Get-Date
        $lastQcHeartbeat = Get-Date
        while ($pendingRuns.Count -gt 0) {
            for ($runIndex = $pendingRuns.Count - 1; $runIndex -ge 0; $runIndex--) {
                $run = $pendingRuns[$runIndex]
                . $drainQcStreams -Run $run

                if (-not $run.Status.IsCompleted) { continue }

                try {
                    $qcResult = $run.Pipe.EndInvoke($run.Status) | Select-Object -First 1
                }
                catch {
                    Write-LogERR "Quality check failed for $($run.Target.Url): $($_.Exception.Message)"
                    $qcResult = $null
                }
                finally {
                    . $drainQcStreams -Run $run
                    $run.Pipe.Dispose()
                }

                $qcRunResults += [PSCustomObject]@{ Target = $run.Target; Result = $qcResult }
                $pendingRuns.RemoveAt($runIndex)
                Write-LogINFO "Quality check finished for $($run.Target.Label): $($run.Target.Url) after $([int]((Get-Date) - $qcWaitStarted).TotalSeconds)s; $($pendingRuns.Count) still running."
            }

            if ($pendingRuns.Count -gt 0) {
                if (((Get-Date) - $lastQcHeartbeat).TotalSeconds -ge 60) {
                    $pendingLabels = @($pendingRuns | ForEach-Object { $_.Target.Url })
                    Write-LogINFO "Quality check still running after $([int]((Get-Date) - $qcWaitStarted).TotalMinutes) minute(s) for: $($pendingLabels -join ', ')"
                    $lastQcHeartbeat = Get-Date
                }
                Start-Sleep -Seconds 5
            }
        }
    }
    finally {
        $qcPool.Close()
        $qcPool.Dispose()
    }

    $mainSiteQC = @($qcRunResults | Where-Object { $_.Target.IsMain }) | Select-Object -First 1
    $channelQCRuns = @($qcRunResults | Where-Object { -not $_.Target.IsMain })

    # EndInvoke above has completed every private-channel QC job before their results are reported.
    # Private channels are never updated - just report their QC findings and mirror a tracker entry.
    foreach ($run in $channelQCRuns) {
        $channelResult = $run.Result
        $channelPassed = ($null -ne $channelResult) -and $channelResult.Success
        $channelReportUrl = $null

        if ($channelResult -and ($channelResult.CheckedOutFilesReport -or $channelResult.ComplianceTaggedFilesReport)) {
            $channelReportUrl = newConsolidatedQCFailureReport `
                -CheckedOutFilesReports @(if ($channelResult.CheckedOutFilesReport) { $channelResult.CheckedOutFilesReport }) `
                -ComplianceTaggedFilesReports @(if ($channelResult.ComplianceTaggedFilesReport) { $channelResult.ComplianceTaggedFilesReport }) `
                -MainSiteUrl $run.Target.Url `
                -context $context
        }

        $channelFindings = if ($channelReportUrl) { "Report: $channelReportUrl" }
                           elseif (-not $channelPassed) { "Quality check could not be completed for this site" }
                           else { "" }

        New-MigrationTrackerEntryForChannel -ChannelUrl $run.Target.Url -QCPassed $channelPassed -QCFindings $channelFindings
    }

    # Report every private-channel QC outcome before blocking the main-site migration on its own QC result.
    $mainSiteQCFailed = ($null -eq $mainSiteQC.Result) -or (-not $mainSiteQC.Result.Success)
    if ($mainSiteQCFailed) {
        $consolidatedReportUrl = newConsolidatedQCFailureReport `
            -CheckedOutFilesReports @(if ($mainSiteQC.Result -and $mainSiteQC.Result.CheckedOutFilesReport) { $mainSiteQC.Result.CheckedOutFilesReport }) `
            -ComplianceTaggedFilesReports @(if ($mainSiteQC.Result -and $mainSiteQC.Result.ComplianceTaggedFilesReport) { $mainSiteQC.Result.ComplianceTaggedFilesReport }) `
            -MainSiteUrl $url `
            -context $context
        $exception = [System.Exception]::new("Error updating Site: QC checks failed. Check report before retrying.")
        $exception.Data.Add("ConsolidatedReportUrl", $consolidatedReportUrl)
        $exception.Data.Add("ErrorType", "QCFailed")
        throw $exception
    }

    # Signal QC passed - triggers tracker status transition in the runbook
    if ($global:OnMigrationPhaseChange) { & $global:OnMigrationPhaseChange "QCPassed" | Out-Null }

    # Update main site only - private channels are intentionally left untouched
    Write-LogINFO "Updating main site: $url"
    $mainSiteResult = updateSite `
        -context $context `
        -languageUPS $language `
        -updateConfig $updateConfig `
        -contentTypeDefinitions $contentTypeDefinitions `
        -LibraryDefinitions $LibraryDefinitions `
        -ViewDefinitions $ViewDefinitions `
        -SiteConfigPath $configPath `
        -companyID $companyID `
        -libraryUrl $libraryUrl `
        -siteType $siteType

    if ($mainSiteResult.ContentTypeCountReportRows -and $mainSiteResult.ContentTypeCountReportRows.Count -gt 0) {
        $contentTypeCountReportRows += $mainSiteResult.ContentTypeCountReportRows
    }
    if ($mainSiteResult.ItemChanges -and $mainSiteResult.ItemChanges.Count -gt 0) {
        $allItemChanges += $mainSiteResult.ItemChanges
    }
    if ($mainSiteResult.BeforeCtCounts -and $mainSiteResult.BeforeCtCounts.Count -gt 0) {
        MergeCtCounts -target $allBeforeCtCounts -source $mainSiteResult.BeforeCtCounts
    }

    $isParentSiteUpdated = $mainSiteResult.Success

    $contentTypeCountReportUrl = $null
    if ($contentTypeCountReportRows.Count -gt 0) {
        $contentTypeCountReportUrl = NewLibraryContentTypeCountReport `
            -rows $contentTypeCountReportRows `
            -mainSiteUrl $url `
            -context $context
        if ($contentTypeCountReportUrl) {
            Write-LogINFO "Library content type count report generated: $contentTypeCountReportUrl"
        }
    }

    if ($allItemChanges.Count -gt 0) {
        $itemMigrationReportUrl = NewItemMigrationReport `
            -itemChanges $allItemChanges `
            -mainSiteUrl $url `
            -context $context
        if ($itemMigrationReportUrl) {
            Write-LogINFO "Item migration report generated: $itemMigrationReportUrl"
        }

        $ctSummaryReportUrl = NewContentTypeSummaryReport `
            -beforeCtCounts $allBeforeCtCounts `
            -itemChanges $allItemChanges `
            -mainSiteUrl $url `
            -context $context
        if ($ctSummaryReportUrl) {
            Write-LogINFO "Content type summary report generated: $ctSummaryReportUrl"
        }
    }

    $isParentSiteValid = $true
    if (($null -eq $libraryUrl) -and ($isSourceDMSUpgrade -eq $false) -and $isParentSiteUpdated) {
        # Reclaim memory before integration test - migration accumulates large CSOM object graphs
        [System.GC]::Collect()
        [System.GC]::WaitForPendingFinalizers()

        # Create a fresh context for validation to avoid carrying migration's accumulated objects
        $validationContext = GetSPOContext -siteUrl $url `
            -clientId $context.AuthState.ClientId `
            -clientSecret $context.AuthState.ClientSecret `
            -tenantId $context.AuthState.TenantId `
            -certificate $context.AuthState.Certificate

        $isParentSiteValid = ValidateSite -siteUrl $url -tenant $tenant -isDMSUPS $isDMSUPS -languageUPS $languageUPS -siteType $siteType -context $validationContext -companyId $companyID
        if($isParentSiteValid) {
            Write-LogInfo "Site $($url) template is valid"
        } else {
            Write-LogERR "Site $($url) template is invalid"
            Add-MigrationTrackerError -Message "Integration test failed: site $($url) template is invalid"
        }
    }
    return $isParentSiteUpdated -and $isParentSiteValid
}

function printExceptions() {
    param (
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [object[]] $exceptions
    )
    Write-LogINFO "Exceptions count: $($exceptions.Count)"
    <# foreach ($exception in $exceptions) {
        Write-LogERR "Item ID: $($exception.ItemId)"
        foreach ($error in $exception.Errors) {
            Write-LogERR "Error: $error"
        }
        Write-LogERR ""
    } #>
}

function saveExceptionsToFile() {
    param (
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [object[]] $exceptions
    )
    $directoryPath = Get-RunbookTempDir
    $exceptions | ForEach-Object {
        $_.Errors = $_.Errors -join "`r`n"
        $_
    } | Export-Csv -Path "$directoryPath\exceptions.csv" -NoTypeInformation -Delimiter ';'
}

function GetLibraryContentTypeDocumentCountRows {
    param(
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [object[]] $libraries,
        [Parameter(Mandatory = $true)] [string] $phase,
        [Parameter(Mandatory = $true)] [datetime] $checkedDate
    )

    $rows = @()
    foreach ($library in ($libraries | Where-Object { $_.BaseTemplate -eq 101 -and $_.Hidden -eq $false })) {
        try {
            $libraryContext = $library.Context
            if ($null -eq $libraryContext) {
                Write-LogWARN "Skipping library '$($library.Title)' because no context is available"
                continue
            }

            $libraryContext.Load($library)
            $libraryContext.Load($library.ContentTypes)
            ExecuteQueryWithRetry -Ctx $libraryContext

            $hostUrl = $null
            if ($libraryContext.Url) {
                $contextUri = [System.Uri]$libraryContext.Url
                $hostUrl = "$($contextUri.Scheme)://$($contextUri.Host)"
            }

            $librarySiteUrl = if ($hostUrl -and $library.ParentWebUrl) {
                "$hostUrl$($library.ParentWebUrl)"
            } else {
                $libraryContext.Url
            }

            $countsByContentTypeId = GetDocumentCountsByContentType -libraryContext $libraryContext -library $library

            foreach ($contentType in $library.ContentTypes) {
                $contentTypeId = $contentType.StringId
                $documentCount = if ($countsByContentTypeId.ContainsKey($contentTypeId)) { $countsByContentTypeId[$contentTypeId] } else { 0 }

                $rows += [PSCustomObject]@{
                    SiteUrl        = $librarySiteUrl
                    LibraryName    = $library.Title
                    ContentType    = $contentType.Name
                    ContentTypeId  = $contentTypeId
                    DocumentsCount = $documentCount
                    CheckedDate    = $checkedDate.ToString("yyyy-MM-dd HH:mm:ss")
                    CheckPhase     = $phase
                }
            }
        }
        catch {
            Write-LogWARN "Failed to collect content type counts for library '$($library.Title)': $($_.Exception.Message)"
        }
    }

    return $rows
}

function MergeContentTypeCountRows {
    param(
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [object[]] $beforeRows,
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [object[]] $afterRows
    )

    $afterLookup = @{}
    foreach ($row in $afterRows) {
        $key = "$($row.SiteUrl)|$($row.LibraryName)|$($row.ContentTypeId)"
        $afterLookup[$key] = $row
    }

    $matchedAfterKeys = @{}
    $merged = @()

    foreach ($beforeRow in $beforeRows) {
        $key = "$($beforeRow.SiteUrl)|$($beforeRow.LibraryName)|$($beforeRow.ContentTypeId)"
        $afterRow = $afterLookup[$key]
        $matchedAfterKeys[$key] = $true
        $merged += [PSCustomObject]@{
            SiteUrl           = $beforeRow.SiteUrl
            LibraryName       = $beforeRow.LibraryName
            ContentType       = $beforeRow.ContentType
            ContentTypeId     = $beforeRow.ContentTypeId
            BeforeCount       = $beforeRow.DocumentsCount
            AfterCount        = if ($afterRow) { $afterRow.DocumentsCount } else { $null }
            BeforeCheckedDate = $beforeRow.CheckedDate
            AfterCheckedDate  = if ($afterRow) { $afterRow.CheckedDate } else { $null }
        }
    }

    # Include after-only rows (content types that didn't exist before the update)
    foreach ($afterRow in $afterRows) {
        $key = "$($afterRow.SiteUrl)|$($afterRow.LibraryName)|$($afterRow.ContentTypeId)"
        if (-not $matchedAfterKeys.ContainsKey($key)) {
            $merged += [PSCustomObject]@{
                SiteUrl           = $afterRow.SiteUrl
                LibraryName       = $afterRow.LibraryName
                ContentType       = $afterRow.ContentType
                ContentTypeId     = $afterRow.ContentTypeId
                BeforeCount       = $null
                AfterCount        = $afterRow.DocumentsCount
                BeforeCheckedDate = $null
                AfterCheckedDate  = $afterRow.CheckedDate
            }
        }
    }

    return $merged
}

function GetDocumentCountsByContentType {
    param(
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.ClientContext] $libraryContext,
        [Parameter(Mandatory = $true)] [Microsoft.SharePoint.Client.List] $library
    )

    $counts = @{}
    $position = $null

    do {
        $query = New-Object Microsoft.SharePoint.Client.CamlQuery
        $query.ListItemCollectionPosition = $position
        $query.ViewXml = @"
<View Scope='RecursiveAll'>
  <ViewFields>
    <FieldRef Name='FSObjType' />
    <FieldRef Name='ContentTypeId' />
  </ViewFields>
  <RowLimit Paged='TRUE'>2000</RowLimit>
</View>
"@

        $items = $library.GetItems($query)
        $libraryContext.Load($items)
        ExecuteQueryWithRetry -Ctx $libraryContext

        foreach ($item in $items) {
            try {
                if ($item["FSObjType"] -ne 0) {
                    continue
                }

                $itemContentTypeId = [string]$item["ContentTypeId"]
                if ([string]::IsNullOrEmpty($itemContentTypeId)) {
                    continue
                }

                if ($counts.ContainsKey($itemContentTypeId)) {
                    $counts[$itemContentTypeId]++
                }
                else {
                    $counts[$itemContentTypeId] = 1
                }
            }
            catch {
                # Ignore malformed items and continue counting remaining rows.
                continue
            }
        }

        $position = $items.ListItemCollectionPosition
    } while ($null -ne $position)

    return $counts
}

function NewLibraryContentTypeCountReport {
    param(
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [PSCustomObject[]] $rows,
        [Parameter(Mandatory = $true)] [string] $mainSiteUrl,
        [Parameter(Mandatory = $false)] [object] $context
    )

    if ($rows.Count -eq 0) {
        return $null
    }

    $timestamp = Get-Date -Format 'dd-MM-yyyy_HH-mm-ss'
    $reportFileName = "DMS-Library-ContentType-Counts-$timestamp.csv"
    $localReportPath = Join-Path (Get-RunbookTempDir) $reportFileName

    # Normalize rows so both merged (BeforeCount/AfterCount) and before-only
    # (DocumentsCount) payloads are exported with the same schema.
    $normalizedRows = foreach ($row in $rows) {
        $hasBeforeCount = $null -ne ($row.PSObject.Properties['BeforeCount'])
        $hasAfterCount = $null -ne ($row.PSObject.Properties['AfterCount'])

        if ($hasBeforeCount -or $hasAfterCount) {
            [PSCustomObject]@{
                SiteUrl           = $row.SiteUrl
                LibraryName       = $row.LibraryName
                ContentType       = $row.ContentType
                ContentTypeId     = $row.ContentTypeId
                BeforeMigrationCount       = $row.BeforeCount
                AfterMigrationCount        = $row.AfterCount
                BeforeMigrationDate = $row.BeforeCheckedDate
                AfterMigrationDate  = $row.AfterCheckedDate
            }
            continue
        }

        [PSCustomObject]@{
            SiteUrl           = $row.SiteUrl
            LibraryName       = $row.LibraryName
            ContentType       = $row.ContentType
            ContentTypeId     = $row.ContentTypeId
            BeforeMigrationCount       = if ($null -ne ($row.PSObject.Properties['DocumentsCount'])) { $row.DocumentsCount } else { $null }
            AfterMigrationCount        = $null
            BeforeMigrationDate = if ($null -ne ($row.PSObject.Properties['CheckedDate'])) { $row.CheckedDate } else { $null }
            AfterMigrationDate  = $null
        }
    }

    $rowsToExport = @(
        $normalizedRows | Where-Object {
            # Export row only when the content type exists in the library
            # in at least one phase.
            ($null -ne $_.BeforeCount) -or ($null -ne $_.AfterCount)
        }
    )

    if ($rowsToExport.Count -eq 0) {
        return $null
    }

    $rowsToExport |
        Select-Object SiteUrl, LibraryName, ContentType, ContentTypeId, BeforeCount, AfterCount, BeforeCheckedDate, AfterCheckedDate |
        Export-Csv -Path $localReportPath -NoTypeInformation -Encoding UTF8

    if ($null -eq $context -or $null -eq $context.AuthState) {
        Write-LogWARN "Context/AuthState unavailable. Content type count report saved locally at $localReportPath"
        return $localReportPath
    }

    try {
        $reportToken = Get-AzureADAccessToken `
            -tenantId $context.AuthState.TenantId `
            -clientId $context.AuthState.ClientId `
            -clientSecret $context.AuthState.ClientSecret `
            -certificate $context.AuthState.Certificate `
            -resourceUrl $context.AuthState.SiteUrl
        $headers = @{
            Authorization = "Bearer $reportToken"
            Accept        = "application/json;odata=verbose"
            ContentType   = "application/json;odata=verbose"
        }

        $uploaded = uploadFileToSiteAssets `
            -siteUrl $mainSiteUrl `
            -headers $headers `
            -sourceFilePath $localReportPath `
            -targetFileName $reportFileName `
            -context $context

        if ($uploaded) {
            return "$mainSiteUrl/SiteAssets/$reportFileName"
        }
    }
    catch {
        Write-LogWARN "Could not upload content type count report to Site Assets: $($_.Exception.Message)"
    }

    return $localReportPath
}

function ensureSiteAssetsLibrary() {
    param (
        [Parameter(Mandatory = $true)] [string] $siteUrl,
        [Parameter(Mandatory = $true)] [hashtable] $headers,
        [Parameter(Mandatory = $false)] [object] $context
    )
    try {
        Write-LogINFO "Checking if SiteAssets library exists at $siteUrl"
        # Filter by EntityTypeName (stable internal name, unaffected by site locale) rather than the localized Title
        $getListsUrl = "$siteUrl/_api/web/lists?`$filter=EntityTypeName eq 'SiteAssets'"
        $response = Invoke-RestMethod -Uri $getListsUrl -Method GET -Headers $headers
        if ($response.d.results.Count -gt 0) {
            Write-LogINFO "SiteAssets library exists"
            return $true
        }

        # EntityTypeName filter can miss the library on some tenants (e.g. localized/renamed title) -
        # confirm by server-relative URL before attempting creation to avoid a duplicate-title conflict.
        $webRelativeUrl = ([System.Uri]$siteUrl).AbsolutePath.TrimEnd('/')
        $getListByUrlUrl = "$siteUrl/_api/web/GetList('$webRelativeUrl/SiteAssets')"
        try {
            $urlResponse = Invoke-RestMethod -Uri $getListByUrlUrl -Method GET -Headers $headers
            if ($null -ne $urlResponse.d.Id) {
                Write-LogINFO "SiteAssets library exists (found by URL)"
                return $true
            }
        } catch {
            # 404 expected when no list exists at this URL - fall through to create it
            Write-LogINFO "No existing SiteAssets library found by URL: $($_.Exception.Message)"
        }

        Write-LogINFO "SiteAssets library not found. Creating SiteAssets library..."
        if ($null -ne $context) {
            try {
                $listCreationInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
                $listCreationInfo.Title = "Site Assets"
                $listCreationInfo.Url = "SiteAssets"  # This ensures the URL path is 'SiteAssets'
                $listCreationInfo.Description = "Use this library to store files which are included on pages within this site, such as images on Wiki pages."
                $listCreationInfo.TemplateType = 101  # Document Library
                $siteAssetsList = $context.Web.Lists.Add($listCreationInfo)
                $context.Load($siteAssetsList)
                ExecuteQueryWithRetry -Ctx $context
                # Set as site assets library
                $siteAssetsList.ImageUrl = "/_layouts/15/images/itdl.png?rev=47"
                $siteAssetsList.IsSiteAssetsLibrary = $true
                $siteAssetsList.Update()
                ExecuteQueryWithRetry -Ctx $context
                Write-LogINFO "SiteAssets library created successfully"
                return $true
            }
            catch {
                # A list/folder at the 'SiteAssets' URL can already exist under a localized title that the
                # EntityTypeName filter above missed on some tenants - treat "already exists" as success.
                if ($_.Exception.Message -like "*already exists*" -or $_.Exception.Message -like "*duplicate*") {
                    Write-LogWARN "SiteAssets library already exists at $siteUrl (creation conflict) - treating as existing"
                    return $true
                }
                throw
            }
        } else {
            throw "Unable to create context"
        }
    }
    catch {
        Write-LogERR "Failed to ensure SiteAssets library exists: $($_.Exception.Message)"
        return $false
    }
}

function uploadFileToSiteAssets() {
    param (
        [Parameter(Mandatory = $true)] [string] $siteUrl,
        [Parameter(Mandatory = $true)] [hashtable] $headers,
        [Parameter(Mandatory = $true)] [string] $sourceFilePath,
        [Parameter(Mandatory = $true)] [string] $targetFileName,
        [Parameter(Mandatory = $false)] [object] $context
    )
    try {
        $sourceFilePath = (Resolve-Path -Path $sourceFilePath).Path
        $fileContent = [System.IO.File]::ReadAllBytes($sourceFilePath)
        $libraryExists = ensureSiteAssetsLibrary -siteUrl $siteUrl -headers $headers -context $context
        if (-not $libraryExists) {
            Write-LogERR "Cannot upload file - SiteAssets library does not exist and could not be created"
            return $null
        }
        $webServerRelativeUrl = ([System.Uri]$siteUrl).AbsolutePath.TrimEnd('/')
        $siteAssetsServerRelativeUrl = "$webServerRelativeUrl/SiteAssets"
        $encodedFileName = [System.Uri]::EscapeDataString($targetFileName).Replace("'", "''")
        $uploadUrl = "$siteUrl/_api/web/GetFolderByServerRelativeUrl('$siteAssetsServerRelativeUrl')/Files/add(url='$encodedFileName',overwrite=true)"
        Invoke-RestMethod -Uri $uploadUrl -Method POST -Headers $headers -Body $fileContent -ContentType "application/octet-stream" | Out-Null
        Write-LogINFO "File uploaded successfully to SiteAssets library at $siteUrl"
        Remove-Item -Path $sourceFilePath -ErrorAction SilentlyContinue
        return $true
    }
    catch {
        Write-LogERR "Failed to upload file to $siteUrl : $($_.Exception.Message)"
        Write-LogINFO "File saved locally: $sourceFilePath"
        return $null
    }
}


function NewItemMigrationReport {
    param(
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [PSCustomObject[]] $itemChanges,
        [Parameter(Mandatory = $true)] [string] $mainSiteUrl,
        [Parameter(Mandatory = $false)] [object] $context,
        # Set by webhook batch jobs so concurrent children do not overwrite each other's report -
        # the timestamp alone collides when two batches finish in the same second.
        [Parameter(Mandatory = $false)] [string] $fileNameSuffix
    )

    if ($itemChanges.Count -eq 0) {
        return $null
    }

    $timestamp = Get-Date -Format 'dd-MM-yyyy_HH-mm-ss'
    $reportFileName = "DMS-Item-Migration-Report-$timestamp$fileNameSuffix.csv"
    $localReportPath = Join-Path (Get-RunbookTempDir) $reportFileName

    $itemChanges |
        Select-Object SiteUrl, LibraryName, LibraryId, ItemId, FileName, FilePath,
                      BeforeContentTypeId, BeforeContentTypeName,
                      AfterContentTypeId, AfterContentTypeName, MigrationDate |
        Export-Csv -Path $localReportPath -NoTypeInformation -Encoding UTF8

    if ($null -eq $context -or $null -eq $context.AuthState) {
        Write-LogWARN "Context/AuthState unavailable. Item migration report saved locally at $localReportPath"
        return $localReportPath
    }

    try {
        $reportToken = Get-AzureADAccessToken `
            -tenantId $context.AuthState.TenantId `
            -clientId $context.AuthState.ClientId `
            -clientSecret $context.AuthState.ClientSecret `
            -certificate $context.AuthState.Certificate `
            -resourceUrl $context.AuthState.SiteUrl
        $headers = @{
            Authorization = "Bearer $reportToken"
            Accept        = "application/json;odata=verbose"
            ContentType   = "application/json;odata=verbose"
        }

        $uploaded = uploadFileToSiteAssets `
            -siteUrl $mainSiteUrl `
            -headers $headers `
            -sourceFilePath $localReportPath `
            -targetFileName $reportFileName `
            -context $context

        if ($uploaded) {
            return "$mainSiteUrl/SiteAssets/$reportFileName"
        }
    }
    catch {
        Write-LogWARN "Could not upload item migration report to Site Assets: $($_.Exception.Message)"
    }

    return $localReportPath
}
function NewExceptionsReport {
    param(
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [PSCustomObject[]] $exceptions,
        [Parameter(Mandatory = $true)] [string] $mainSiteUrl,
        [Parameter(Mandatory = $false)] [object] $context,
        # Set by webhook batch jobs so concurrent children do not overwrite each other's report -
        # the timestamp alone collides when two batches finish in the same second.
        [Parameter(Mandatory = $false)] [string] $fileNameSuffix
    )

    if ($exceptions.Count -eq 0) {
        return $null
    }

    $timestamp = Get-Date -Format 'dd-MM-yyyy_HH-mm-ss'
    $reportFileName = "DMS-Item-Exceptions-Report-$timestamp$fileNameSuffix.csv"
    $localReportPath = Join-Path (Get-RunbookTempDir) $reportFileName

ItemId   = $failedItem.ItemId
                            Errors   = $result.Errors
                            FileName = $failedItem.File.Name
                            Path     = $failedItem.File.ServerRelativeUrl
                            Url      = $failedItem.File.LinkingUri

    $exceptions |
        Select-Object ItemId, FileName, Path, Url, Errors |
        Export-Csv -Path $localReportPath -NoTypeInformation -Encoding UTF8

    if ($null -eq $context -or $null -eq $context.AuthState) {
        Write-LogWARN "Context/AuthState unavailable. Item exception report saved locally at $localReportPath"
        return $localReportPath
    }

    try {
        $reportToken = Get-AzureADAccessToken `
            -tenantId $context.AuthState.TenantId `
            -clientId $context.AuthState.ClientId `
            -clientSecret $context.AuthState.ClientSecret `
            -certificate $context.AuthState.Certificate `
            -resourceUrl $context.AuthState.SiteUrl
        $headers = @{
            Authorization = "Bearer $reportToken"
            Accept        = "application/json;odata=verbose"
            ContentType   = "application/json;odata=verbose"
        }

        $uploaded = uploadFileToSiteAssets `
            -siteUrl $mainSiteUrl `
            -headers $headers `
            -sourceFilePath $localReportPath `
            -targetFileName $reportFileName `
            -context $context

        if ($uploaded) {
            return "$mainSiteUrl/SiteAssets/$reportFileName"
        }
    }
    catch {
        Write-LogWARN "Could not upload item migration report to Site Assets: $($_.Exception.Message)"
    }

    return $localReportPath
}

function MergeCtCounts {
    param(
        [Parameter(Mandatory = $true)] [hashtable] $target,
        [Parameter(Mandatory = $true)] [hashtable] $source
    )
    foreach ($key in $source.Keys) {
        if (-not $target.ContainsKey($key)) {
            $src = $source[$key]
            $target[$key] = [PSCustomObject]@{
                SiteUrl         = $src.SiteUrl
                LibraryName     = $src.LibraryName
                ContentTypeId   = $src.ContentTypeId
                ContentTypeName = $src.ContentTypeName
                Count           = $src.Count
            }
        } else {
            $target[$key].Count += $source[$key].Count
        }
    }
}

function NewContentTypeSummaryReport {
    param(
        [Parameter(Mandatory = $true)] [hashtable] $beforeCtCounts,
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [PSCustomObject[]] $itemChanges,
        [Parameter(Mandatory = $true)] [string] $mainSiteUrl,
        [Parameter(Mandatory = $false)] [object] $context,
        # See NewItemMigrationReport - keeps concurrent batch jobs from overwriting each other.
        [Parameter(Mandatory = $false)] [string] $fileNameSuffix
    )

    if ($beforeCtCounts.Count -eq 0) {
        return $null
    }

    $sep = [char]0

    # Build after counts by applying $itemChanges as a delta onto $beforeCtCounts.
    # Each migrated item decrements its old CT and increments its new CT.
    $afterCtCounts = @{}
    foreach ($key in $beforeCtCounts.Keys) {
        $src = $beforeCtCounts[$key]
        $afterCtCounts[$key] = [PSCustomObject]@{
            SiteUrl         = $src.SiteUrl
            LibraryName     = $src.LibraryName
            ContentTypeId   = $src.ContentTypeId
            ContentTypeName = $src.ContentTypeName
            Count           = $src.Count
        }
    }
    foreach ($change in $itemChanges) {
        $beforeKey = "$($change.SiteUrl)$sep$($change.LibraryName)$sep$($change.BeforeContentTypeId)"
        $afterKey  = "$($change.SiteUrl)$sep$($change.LibraryName)$sep$($change.AfterContentTypeId)"
        if ($afterCtCounts.ContainsKey($beforeKey)) { $afterCtCounts[$beforeKey].Count-- }
        if (-not $afterCtCounts.ContainsKey($afterKey)) {
            $afterCtCounts[$afterKey] = [PSCustomObject]@{
                SiteUrl         = $change.SiteUrl
                LibraryName     = $change.LibraryName
                ContentTypeId   = $change.AfterContentTypeId
                ContentTypeName = $change.AfterContentTypeName
                Count           = 0
            }
        }
        $afterCtCounts[$afterKey].Count++
    }

    $allKeys = @{}
    foreach ($key in $beforeCtCounts.Keys) { $allKeys[$key] = $true }
    foreach ($key in $afterCtCounts.Keys)  { $allKeys[$key] = $true }

    $rows = foreach ($key in ($allKeys.Keys | Sort-Object)) {
        $before = $beforeCtCounts[$key]
        $after  = $afterCtCounts[$key]
        $ref    = if ($before) { $before } else { $after }
        [PSCustomObject]@{
            SiteUrl              = $ref.SiteUrl
            LibraryName          = $ref.LibraryName
            ContentTypeId        = $ref.ContentTypeId
            ContentTypeName      = $ref.ContentTypeName
            BeforeMigrationCount = if ($before) { $before.Count } else { 0 }
            AfterMigrationCount  = if ($after)  { $after.Count  } else { 0 }
        }
    }

    $timestamp = Get-Date -Format 'dd-MM-yyyy_HH-mm-ss'
    $reportFileName = "DMS-ContentType-Summary-Report-$timestamp$fileNameSuffix.csv"
    $localReportPath = Join-Path (Get-RunbookTempDir) $reportFileName

    $rows |
        Select-Object SiteUrl, LibraryName, ContentTypeId, ContentTypeName,
                      BeforeMigrationCount, AfterMigrationCount |
        Export-Csv -Path $localReportPath -NoTypeInformation -Encoding UTF8

    if ($null -eq $context -or $null -eq $context.AuthState) {
        Write-LogWARN "Context/AuthState unavailable. Content type summary report saved locally at $localReportPath"
        return $localReportPath
    }

    try {
        $reportToken = Get-AzureADAccessToken `
            -tenantId $context.AuthState.TenantId `
            -clientId $context.AuthState.ClientId `
            -clientSecret $context.AuthState.ClientSecret `
            -certificate $context.AuthState.Certificate `
            -resourceUrl $context.AuthState.SiteUrl
        $headers = @{
            Authorization = "Bearer $reportToken"
            Accept        = "application/json;odata=verbose"
            ContentType   = "application/json;odata=verbose"
        }

        $uploaded = uploadFileToSiteAssets `
            -siteUrl $mainSiteUrl `
            -headers $headers `
            -sourceFilePath $localReportPath `
            -targetFileName $reportFileName `
            -context $context

        if ($uploaded) {
            return "$mainSiteUrl/SiteAssets/$reportFileName"
        }
    }
    catch {
        Write-LogWARN "Could not upload content type summary report to Site Assets: $($_.Exception.Message)"
    }

    return $localReportPath
}

Function newConsolidatedQCFailureReport {
    param(
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [PSCustomObject[]]$CheckedOutFilesReports,
        [Parameter(Mandatory = $true)] [AllowEmptyCollection()] [PSCustomObject[]]$ComplianceTaggedFilesReports,
        [Parameter(Mandatory = $true)] [string]$MainSiteUrl,
        [Parameter(Mandatory = $false)] [object]$context
    )
    try {
        $timestamp = Get-Date -Format 'dd-MM-yyyy_HH-mm-ss'
        $consolidatedReportName = "DMS-Legacy-Update-QC-Failure-Report-$timestamp.html"
        $localReportPath = Join-Path (Get-RunbookTempDir) $consolidatedReportName

        # Calculate totals
        $totalCheckedOutFiles = 0
        $totalCheckedOutLibraries = 0
        foreach ($report in $CheckedOutFilesReports) {
            if ($report.TotalFileCount) { $totalCheckedOutFiles += $report.TotalFileCount }
            if ($report.LibraryCount) { $totalCheckedOutLibraries += $report.LibraryCount }
        }

        $totalComplianceTaggedFiles = 0
        $totalComplianceTaggedLibraries = 0
        foreach ($report in $ComplianceTaggedFilesReports) {
            if ($report.TotalFileCount) { $totalComplianceTaggedFiles += $report.TotalFileCount }
            if ($report.LibraryCount) { $totalComplianceTaggedLibraries += $report.LibraryCount }
        }

        $generatedDate = Get-Date -Format 'dd/MM/yyyy HH:mm:ss'

        $htmlContent = @"
<!DOCTYPE html>
<html>
<head>
    <title>DMS/Library Update - QC Failure Report</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; background-color: #f5f5f5; }
        .container { max-width: 1400px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        h1 { color: #d73502; text-align: center; margin-bottom: 10px; }
        h2.section-title { color: #d73502; margin-top: 30px; margin-bottom: 10px; border-bottom: 2px solid #d73502; padding-bottom: 5px; }
        .alert { background-color: #fff3cd; border: 2px solid #ffc107; padding: 20px; border-radius: 8px; margin-bottom: 30px; }
        .alert h2 { margin-top: 0; color: #856404; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }
        .stat-card.compliance { background: linear-gradient(135deg, #f6a623 0%, #d73502 100%); }
        .stat-number { font-size: 2.5em; font-weight: bold; }
        .stat-label { font-size: 0.9em; opacity: 0.9; margin-top: 5px; }
        .site-section { margin-bottom: 30px; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; }
        .site-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 20px; }
        .site-header.compliance { background: linear-gradient(135deg, #f6a623 0%, #d73502 100%); }
        .site-header h2 { margin: 0; font-size: 1.3em; }
        .site-info { background: #f8f9fa; padding: 15px 20px; border-bottom: 1px solid #e0e0e0; }
        .library-section { padding: 20px; }
        .library-item { background: #ffffff; border: 1px solid #dee2e6; border-radius: 6px; padding: 15px; margin-bottom: 15px; transition: box-shadow 0.3s; }
        .library-item:hover { box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        .library-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .library-name { font-weight: bold; font-size: 1.1em; color: #333; }
        .file-count { background: #d73502; color: white; padding: 5px 15px; border-radius: 20px; font-weight: bold; }
        .view-link { display: inline-block; background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 10px; transition: background-color 0.3s; }
        .view-link:hover { background: #218838; }
        .action-items { background: #e7f3ff; border: 2px solid #0078d4; padding: 20px; border-radius: 8px; margin-top: 30px; }
        .action-items h2 { color: #0078d4; margin-top: 0; }
        .action-items h3 { color: #0078d4; margin-bottom: 5px; }
        .action-items ol { padding-left: 20px; }
        .action-items li { margin-bottom: 10px; }
        .timestamp { text-align: center; color: #666; font-size: 0.9em; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="alert">
            <h2>&#9888;&#65039; Update Process Halted</h2>
            <p>The site update has been stopped because QC checks detected issues in the site collection. All issues listed below must be resolved before the update process can continue.</p>
        </div>
        <div class="stats">
"@

        if ($totalCheckedOutFiles -gt 0) {
            $htmlContent += @"
            <div class="stat-card">
                <div class="stat-number">$totalCheckedOutFiles</div>
                <div class="stat-label">Checked-Out Files ($totalCheckedOutLibraries libraries)</div>
            </div>
"@
        }
        if ($totalComplianceTaggedFiles -gt 0) {
            $htmlContent += @"
            <div class="stat-card compliance">
                <div class="stat-number">$totalComplianceTaggedFiles</div>
                <div class="stat-label">Compliance-Tagged Files ($totalComplianceTaggedLibraries libraries)</div>
            </div>
"@
        }

        $htmlContent += @"
        </div>
        <p class="timestamp">Report generated: $generatedDate</p>
"@

        # Checked-out files section
        if ($CheckedOutFilesReports.Count -gt 0) {
            $htmlContent += @"
        <h2 class="section-title">&#128274; Checked-Out Files</h2>
"@
            foreach ($report in $CheckedOutFilesReports) {
                $reportSiteType = $report.SiteType
                $reportSiteUrl = $report.SiteUrl
                $reportTotalFiles = $report.TotalFileCount
                $reportLibCount = $report.LibraryCount
                $reportGenDate = $report.GeneratedDate.ToString('dd/MM/yyyy HH:mm:ss')

                $htmlContent += @"
        <div class="site-section">
            <div class="site-header">
                <h2>$reportSiteType`: $reportSiteUrl</h2>
            </div>
            <div class="site-info">
                <strong>Total Files:</strong> <span style="color: #d73502; font-weight: bold;">$reportTotalFiles</span> |
                <strong>Libraries:</strong> $reportLibCount |
                <strong>Generated:</strong> $reportGenDate
            </div>
            <div class="library-section">
"@
                if ($report.Views -and $report.Views.Count -gt 0) {
                    foreach ($view in $report.Views) {
                        $libName = $view.LibraryName
                        $fileCount = $view.FileCount
                        $viewUrl = $view.ViewUrl
                        $htmlContent += @"
                <div class="library-item">
                    <div class="library-header">
                        <div class="library-name">&#128218; $libName</div>
                        <div class="file-count">$fileCount file(s)</div>
                    </div>
                    <a href="$viewUrl" target="_blank" class="view-link">&#128269; View Checked-Out Files</a>
                </div>
"@
                    }
                } else {
                    $htmlContent += @"
                <p><em>No view details available</em></p>
"@
                }
                $htmlContent += @"
            </div>
        </div>
"@
            }
        }

        # Compliance-tagged files section
        if ($ComplianceTaggedFilesReports.Count -gt 0) {
            $htmlContent += @"
        <h2 class="section-title">&#127381; Compliance-Tagged Files</h2>
"@
            foreach ($report in $ComplianceTaggedFilesReports) {
                $reportSiteType = $report.SiteType
                $reportSiteUrl = $report.SiteUrl
                $reportTotalFiles = $report.TotalFileCount
                $reportLibCount = $report.LibraryCount
                $reportGenDate = $report.GeneratedDate.ToString('dd/MM/yyyy HH:mm:ss')

                $htmlContent += @"
        <div class="site-section">
            <div class="site-header compliance">
                <h2>$reportSiteType`: $reportSiteUrl</h2>
            </div>
            <div class="site-info">
                <strong>Total Files:</strong> <span style="color: #d73502; font-weight: bold;">$reportTotalFiles</span> |
                <strong>Libraries:</strong> $reportLibCount |
                <strong>Generated:</strong> $reportGenDate
            </div>
            <div class="library-section">
"@
                if ($report.Views -and $report.Views.Count -gt 0) {
                    foreach ($view in $report.Views) {
                        $libName = $view.LibraryName
                        $fileCount = $view.FileCount
                        $viewUrl = $view.ViewUrl
                        $htmlContent += @"
                <div class="library-item">
                    <div class="library-header">
                        <div class="library-name">&#128218; $libName</div>
                        <div class="file-count">$fileCount file(s)</div>
                    </div>
                    <a href="$viewUrl" target="_blank" class="view-link">&#128269; View Compliance-Tagged Files</a>
                </div>
"@
                    }
                } else {
                    $htmlContent += @"
                <p><em>No view details available</em></p>
"@
                }
                $htmlContent += @"
            </div>
        </div>
"@
            }
        }

        $actionItems = ""
        if ($totalCheckedOutFiles -gt 0) {
            $actionItems += @"

                <h3>Checked-Out Files</h3>
                <ol>
                    <li><strong>Review the views:</strong> Click on the "View Checked-Out Files" links above to see which files are checked out</li>
                    <li><strong>Contact file owners:</strong> Identify who has checked out the files and request they check them in</li>
                    <li><strong>Check in files:</strong> Ensure all files are checked back into the libraries</li>
                </ol>
"@
        }
        if ($totalComplianceTaggedFiles -gt 0) {
            $actionItems += @"

                <h3>Compliance-Tagged Files</h3>
                <ol>
                    <li><strong>Review the views:</strong> Click on the "View Compliance-Tagged Files" links above to see which files have retention labels applied</li>
                    <li><strong>Contact compliance/records team:</strong> Consult your compliance or records management team to assess whether the retention labels must be removed before migration</li>
                    <li><strong>Remove or adjust labels if required:</strong> Remove or modify labels as advised by the compliance team</li>
                </ol>
"@
        }

        $htmlContent += @"
        <div class="action-items">
            <h2>&#128203; Required Actions</h2>
            $actionItems
            <p><strong>Once all issues are resolved, re-submit the migration request from ServiceNow.</strong></p>
        </div>

        <div class="timestamp">
            <p>This report was automatically generated by the DMS Update System</p>
        </div>
    </div>
</body>
</html>
"@

        # Save HTML report
        $htmlContent | Out-File -FilePath $localReportPath -Encoding UTF8

        # Upload to main site's Site Assets
        $accessToken = Get-AzureADAccessToken `
            -tenantId $context.AuthState.TenantId `
            -clientId $context.AuthState.ClientId `
            -clientSecret $context.AuthState.ClientSecret `
            -certificate $context.AuthState.Certificate `
            -resourceUrl $context.AuthState.SiteUrl
        $headers = @{
            Authorization = "Bearer $accessToken"
            Accept        = "application/json;odata=verbose"
            ContentType   = "application/json;odata=verbose"
        }

        $uploadSuccess = uploadFileToSiteAssets `
            -siteUrl $MainSiteUrl `
            -headers $headers `
            -sourceFilePath $localReportPath `
            -targetFileName $consolidatedReportName `
            -context $context

        if ($uploadSuccess) {
            Write-LogINFO "Consolidated QC report created: $MainSiteUrl/SiteAssets/$consolidatedReportName"
            return "$MainSiteUrl/SiteAssets/$consolidatedReportName"
        } else {
            Write-LogERR "Failed to upload consolidated QC report to SharePoint"
            return $localReportPath
        }
    }
    catch {
        Write-LogERR "Failed to create consolidated QC report: $($_.Exception.Message)"
        return $null
    }
}