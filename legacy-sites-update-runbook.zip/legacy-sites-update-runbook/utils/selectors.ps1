Function EncodeEntityTypeName($EntityTypeName) {
    $encoded = ''
    foreach ($char in $EntityTypeName.ToCharArray()) {
        if ($char -match '[A-Za-z0-9]') {
            $encoded += $char
        }
        else {
            $hexValue = [System.String]::Format('{0:x4}', [int]$char)
            $encoded += "_x$hexValue" + "_"
        }
    }
    return $encoded
}

Function GetListByEntityTypeName($Context, $EntityTypeName) {
    $Lists = $Context.Web.Lists
    try{
        $Context.Load($Lists)
        ExecuteQueryWithRetry -Ctx $Context
    }
    catch{
        Write-LogERR $_
    }
    # Encode the input EntityTypeName to match SharePoint's encoding
    $EncodedEntityTypeName = EncodeEntityTypeName $EntityTypeName
    $List = $Lists | Where-Object { $EncodedEntityTypeName -eq $_.EntityTypeName }
    return $List
}