[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseApprovedVerbs', '', Justification = 'Field is a valid class name')]
class TextField : Field {

    [string]$DefaultValue

    TextField(
        [string]$Group,
        [string]$InternalName,
        [string]$DisplayName,
        [string]$Description,
        [bool]$Required,
        [bool]$EnforceUniqueValues,
        [string]$DefaultValue) : base(
            $Group,
            $InternalName,
            $DisplayName,
            $Description,
            $Required,
            $EnforceUniqueValues
        ) {
            $this.DefaultValue = $DefaultValue
        }

    [string]GetFieldSchema() {
        $schema = ([Field]$this).GetBasicFieldSchema('Text')

        if($this.DefaultValue) {
            $schema += "><Default>$($this.DefaultValue)</Default></Field>"
        } else {
            $schema += "/>";
        }

        return $schema
    }

    [void]CreateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.FieldCollection] $Fields
    ) {
        ([Field]$this).CreateSharePointField($Context, $Fields)
    }
}