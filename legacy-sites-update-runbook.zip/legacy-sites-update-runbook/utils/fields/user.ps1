[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseApprovedVerbs', '', Justification = 'Field is a valid class name')]
class UserField : Field {
    [bool]$AllowMultipleSelections
    [bool]$AllowSelectionOfPeopleAndGroups

    UserField(
        [string]$Group,
        [string]$InternalName,
        [string]$DisplayName,
        [string]$Description,
        [bool]$Required,
        [bool]$EnforceUniqueValues,
        [bool]$AllowMultipleSelections,
        [bool]$AllowSelectionOfPeopleAndGroups
    ) : base(
        $Group,
        $InternalName,
        $DisplayName,
        $Description,
        $Required,
        $EnforceUniqueValues
    ) {
        $this.AllowMultipleSelections = $AllowMultipleSelections
        $this.AllowSelectionOfPeopleAndGroups = $AllowSelectionOfPeopleAndGroups
    }

    [string]GetFieldSchema() {
        $schema = ([Field]$this).GetBasicFieldSchema('User')

        if ($this.AllowMultipleSelections) {
            $schema += " Mult='TRUE'"
        }

        $schema += " UserSelectionMode='$(BooleanToInt -Value $this.AllowSelectionOfPeopleAndGroups)'"

        $schema += "/>"

        return $schema
    }

    [void]CreateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.FieldCollection] $Fields
    ) {
        ([Field]$this).CreateSharePointField($Context, $Fields)
    }
}