# this documentation was very useful while creating these classes
# https://learn.microsoft.com/en-us/sharepoint/dev/schema/field-element-field

class Field {
    [string]$Group
    [string]$InternalName
    [string]$DisplayName
    [string]$Description
    [bool]$Required
    [bool]$EnforceUniqueValues

    Field([string]$Group, [string]$InternalName, [string]$DisplayName, [string]$Description, [bool]$Required, [bool]$EnforceUniqueValues) {
        $this.Group = $Group
        $this.InternalName = $InternalName
        $this.DisplayName = $DisplayName
        $this.Description = $Description
        $this.Required = $Required
        $this.EnforceUniqueValues = $EnforceUniqueValues
    }

    [string]GetBasicFieldSchema($Type) {
        return "
        <Field
            Type='$($Type)'
            Group='$($this.Group)'
            DisplayName=`"$($this.DisplayName)`"
            Name='$($this.InternalName)'
            Description=`"$($this.Description)`"
            Required='$(BooleanToString -Value $this.Required)'
            EnforceUniqueValues='$(BooleanToString -Value $this.EnforceUniqueValues)'
        "
    }

    [Microsoft.SharePoint.Client.Field]CreateSharePointField($Context, $Fields) {
        $FieldSchema = $this.GetFieldSchema()
        $Field = $Fields.AddFieldAsXml($FieldSchema, $True, [Microsoft.SharePoint.Client.AddFieldOptions]::AddFieldToDefaultView)
        ExecuteQueryWithRetry -Ctx $Context
        return $Field;
    }

    [Microsoft.SharePoint.Client.Field]UpdateSharePointField($Context, $Field) {
        $FieldSchema = $this.GetFieldSchema()
        $Field.SchemaXml = $FieldSchema
        return $Field;
    }

}

Function CreateField($Context, $Column, $Fields, $Language, $CompanyId) {
    try {
        Write-LogINFO "Creating site column '$($Column.InternalName)'..."
        $FieldObject = GetFieldObjectByType -Column $Column -Language $Language -CompanyId $CompanyId
        $FieldObject.CreateField($Context, $Fields)
        Write-LogINFO "Site column '$($Column.InternalName)' created successfully."
    } catch {
        Write-LogERR "Error creating field '$($Column.InternalName)': $($_.Exception.Message)"
    }
}

Function UpdateField($Context, $Column, $Fields, $Language, $CompanyId) {
    try {
        $field = $Fields | Where-Object {$_.InternalName -eq $Column.InternalName}
        if($null -eq $field){
            CreateField -Context $Context -Column $Column -Fields $Fields -Language $Language -CompanyId $CompanyId
        }
        else{
            Write-LogINFO "Updating site column '$($Column.InternalName)'..."
            if($null -ne $Column.DefaultValue){
                $field.DefaultValue = $Column.DefaultValue
            }
            if($null -ne $Column.DisplayName){
                $field.Title = $Column.DisplayName.$Language
            }
            if($null -ne $Column.Description){
                $field.Description = $Column.Description.$Language
            }
            if($null -ne $Column.Required){
                $field.Required = $Column.Required
            }
            if($Column.Type -eq 'Choice'){
                $field.Choices = $Column.Choices.$Language
            }
            elseif($column.Type -eq 'ManagedMetadata'){
                $FieldObject = GetFieldObjectByType -Column $Column -Language $Language -CompanyId $CompanyId
                $FieldObject.UpdateField($Context, $Field)
            }
            elseif($column.Type -eq 'Note'){
                $FieldObject = GetFieldObjectByType -Column $Column -Language $Language -CompanyId $CompanyId
                $FieldObject.UpdateField($Context, $Field)
            }
            $field.UpdateAndPushChanges($true)
            ExecuteQueryWithRetry -Ctx $Context
            Write-LogINFO "Site column '$($Column.InternalName)' updated successfully."
        }
    } catch {
        Write-LogINFO "Error updating field '$($Column.InternalName)': $($_.Exception.Message)"
    }
}

Function GetFieldObjectByType($Column, $Language, $CompanyId) {

    $Type = $Column.Type
    $Group = $Column.Group
    $InternalName = $Column.InternalName
    $DisplayName = $Column.DisplayName.$Language
    $Description = $Column.Description.$Language
    $DefaultValue = $Column.DefaultValue
    $Required = $Column.Required
    $EnforceUniqueValues = $Column.EnforceUniqueValues

    # Note field type
    $NumLines = $Column.NumLines
    $RichText = $Column.RichText
    $AllowHyperlink = $Column.AllowHyperlink
    $RichTextMode = $Column.RichTextMode
    $UnlimitedLengthInDocumentLibrary = $Column.UnlimitedLengthInDocumentLibrary
    $AppendOnly = $Column.AppendOnly

    # Choice field type
    $AllowMultipleValues = $Column.AllowMultipleValues
    $Choices = $Column.Choices.$Language

    # Number field type
    $Percentage = $Column.Percentage
    $Decimals = $Column.Decimals
    $MinimumValue = $Column.MinimumValue
    $MaximumValue = $Column.MaximumValue

    # Currency field type
    $CurrencyLocaleId = $Column.CurrencyLocaleId

    # DateTime field type
    $DateTimeFormat = $Column.DateTimeFormat

    # User field type
    $AllowMultipleSelections = $Column.AllowMultipleSelections
    $AllowSelectionOfPeopleAndGroups = $Column.AllowSelectionOfPeopleAndGroups

    # Managed Metadata field type
    $TermGroup = $Column.TermGroup
    $TermSet = $Column.TermSet
    $Term = $Column.Term
    $IsTermSetECCS = $Column.IsTermSetECCS
    $FallbackToLocalTermSet = $Column.FallbackToLocalTermSet


    $Field = $null;

    switch ($Type) {
        'Text' {
            $Field = [TextField]::new(
                $Group,
                $InternalName,
                $DisplayName,
                $Description,
                $Required,
                $EnforceUniqueValues,
                $DefaultValue
            )
        }
        'Note' {
            $Field = [NoteField]::new(
                $Group,
                $InternalName,
                $DisplayName,
                $Description,
                $Required,
                $EnforceUniqueValues,
                $DefaultValue,
                $NumLines,
                $RichText,
                $AllowHyperlink,
                $RichTextMode,
                $UnlimitedLengthInDocumentLibrary,
                $AppendOnly
            )
        }
        'Choice' {
            $Field = [ChoiceField]::new(
                $Group,
                $InternalName,
                $DisplayName,
                $Description,
                $Required,
                $EnforceUniqueValues,
                $DefaultValue,
                $AllowMultipleValues,
                $Choices
            )
        }
        'Number' {
            $Field = [NumberField]::new(
                $Group,
                $InternalName,
                $DisplayName,
                $Description,
                $Required,
                $EnforceUniqueValues,
                $DefaultValue,
                $Percentage,
                $Decimals,
                $MinimumValue,
                $MaximumValue
            )
        }
        'Currency' {
            $Field = [CurrencyField]::new(
                $Group,
                $InternalName,
                $DisplayName,
                $Description,
                $Required,
                $EnforceUniqueValues,
                $DefaultValue,
                $Decimals,
                $MinimumValue,
                $MaximumValue,
                $CurrencyLocaleId
            )
        }
        'DateTime' {
            $Field = [DateTimeField]::new(
                $Group,
                $InternalName,
                $DisplayName,
                $Description,
                $Required,
                $EnforceUniqueValues,
                $DefaultValue,
                $DateTimeFormat
            )
        }
        'Boolean' {
            $Field = [BooleanField]::new(
                $Group,
                $InternalName,
                $DisplayName,
                $Description,
                $Required,
                $EnforceUniqueValues,
                $DefaultValue
            )
        }
        'User' {
            $Field = [UserField]::new(
                $Group,
                $InternalName,
                $DisplayName,
                $Description,
                $Required,
                $EnforceUniqueValues,
                $AllowMultipleSelections,
                $AllowSelectionOfPeopleAndGroups
            )
        }
        'ManagedMetadata' {
            $Field = [TaxonomyField]::new(
                $Group,
                $InternalName,
                $DisplayName,
                $Description,
                $Required,
                $EnforceUniqueValues,
                $AllowMultipleValues,
                $TermGroup,
                $TermSet,
                $Term,
                $IsTermSetECCS,
                $FallbackToLocalTermSet,
                $CompanyId
            )
        }
        default {
            throw "Invalid field type: $Type."
        }
    }

    return $Field

}