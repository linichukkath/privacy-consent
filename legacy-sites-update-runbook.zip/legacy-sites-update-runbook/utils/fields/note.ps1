[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseApprovedVerbs', '', Justification = 'Field is a valid class name')]
class NoteField : Field {

    [int]$NumLines
    [bool]$RichText
    [bool]$AllowHyperlink
    [string]$RichTextMode #FullHtml ThemeHtml Compatible HtmlAsXml
    [bool]$UnlimitedLengthInDocumentLibrary
    [bool]$AppendOnly
    [string]$DefaultValue

    NoteField(
        [string]$Group,
        [string]$InternalName,
        [string]$DisplayName,
        [string]$Description,
        [bool]$Required,
        [bool]$EnforceUniqueValues,
        [string]$DefaultValue,
        [int]$numLines,
        [bool]$richText,
        [bool]$allowHyperlink,
        [string]$richTextMode,
        [bool]$unlimitedLengthInDocumentLibrary,
        [bool]$appendOnly
    ) : base(
        $Group,
        $InternalName,
        $DisplayName,
        $Description,
        $Required,
        $EnforceUniqueValues
    ) {
        $this.NumLines = $numLines
        $this.RichText = $richText
        $this.AllowHyperlink = $allowHyperlink
        $this.RichTextMode = $richTextMode
        $this.UnlimitedLengthInDocumentLibrary = $unlimitedLengthInDocumentLibrary
        $this.AppendOnly = $appendOnly
        $this.DefaultValue = $DefaultValue
    }

    [string]GetFieldSchema() {
        $schema = ([Field]$this).GetBasicFieldSchema('Note')
        if ($this.NumLines) {
            $schema += " NumLines='$($this.NumLines)'"
        }
        if ($this.RichText) {
            $schema += " RichText='$(BooleanToString -Value $this.RichText)'"
            if ($this.AllowHyperlink) {
                $schema += " AllowHyperlink='$(BooleanToString -Value $this.AllowHyperlink)'"
            }
            if ($this.RichTextMode) {
                $schema += " RichTextMode='$($this.RichTextMode)'"
            }
        }
        if ($this.UnlimitedLengthInDocumentLibrary) {
            $schema += " UnlimitedLengthInDocumentLibrary='$(BooleanToString -Value $this.UnlimitedLengthInDocumentLibrary)'"
        }
        if ($this.AppendOnly) {
            $schema += " AppendOnly='$(BooleanToString -Value $this.AppendOnly)'"
        }
        if ($this.DefaultValue) {
            $schema += ">"
            $schema += "<Default>$($this.DefaultValue)</Default>"
            $schema += "</Field>"
        } else {
            $schema += "/>"
        }

        return $schema
    }

    [void]CreateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.FieldCollection] $Fields
    ) {
        ([Field]$this).CreateSharePointField($Context, $Fields)
    }

    [void]UpdateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.Field] $Field
    ) {
        ([Field]$this).UpdateSharePointField($Context, $Field)
    }
}
