[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseApprovedVerbs', '', Justification = 'Field is a valid class name')]
class DateTimeField : Field {

    [string]$DateTimeFormat
    [string]$DefaultValue

    DateTimeField(
        [string]$Group,
        [string]$InternalName,
        [string]$DisplayName,
        [string]$Description,
        [bool]$Required,
        [bool]$EnforceUniqueValues,
        [string]$DefaultValue,
        [string]$DateTimeFormat # DateTime or DateOnly
    ) : base(
        $Group,
        $InternalName,
        $DisplayName,
        $Description,
        $Required,
        $EnforceUniqueValues
    ) {
        $this.DateTimeFormat = $DateTimeFormat
        $this.DefaultValue = $DefaultValue
    }

    [string]GetFieldSchema() {
        $schema = ([Field]$this).GetBasicFieldSchema('DateTime')

        $schema += " Format='$($this.DateTimeFormat)'"

        if($this.DefaultValue) {
            $schema += "><Default>$($this.DefaultValue)</Default></Field>"
        } else {
            $schema += "/>"
        }

        return $schema
    }

    [void]CreateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.FieldCollection] $Fields
    ) {
        ([Field]$this).CreateSharePointField($Context, $Fields)
    }
}
