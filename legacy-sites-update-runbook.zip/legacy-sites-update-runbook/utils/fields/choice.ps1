[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseApprovedVerbs', '', Justification = 'Field is a valid class name')]
class ChoiceField : Field {

    [bool]$AllowMultipleValues
    [string[]]$Choices
    [string]$DefaultValue

    ChoiceField(
        [string]$Group,
        [string]$InternalName,
        [string]$DisplayName,
        [string]$Description,
        [bool]$Required,
        [bool]$EnforceUniqueValues,
        [string]$DefaultValue,
        [bool]$AllowMultipleValues,
        [string[]]$Choices) : base(
            $Group,
            $InternalName,
            $DisplayName,
            $Description,
            $Required,
            $EnforceUniqueValues
        ) {
            $this.AllowMultipleValues = $AllowMultipleValues
            $this.Choices = $Choices
            $this.DefaultValue = $DefaultValue
    }

    [string]GetFieldSchema() {
        $schema = ([Field]$this).GetBasicFieldSchema('Choice')

        if($this.AllowMultipleValues) {
            $schema += " Mult='TRUE'" # TODO: check if this even works
        }

        $schema += ">"

        $schema += "<CHOICES>"
        foreach($choice in $this.Choices) {
            $schema += "<CHOICE>$($choice)</CHOICE>"
        }
        $schema += "</CHOICES>"

        if($this.DefaultValue) {
            $schema += "<Default>$($this.DefaultValue)</Default>"
        }

        $schema += "</Field>"

        return $schema
    }

    [void]CreateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.FieldCollection] $Fields
    ) {
        ([Field]$this).CreateSharePointField($Context, $Fields)
    }
}