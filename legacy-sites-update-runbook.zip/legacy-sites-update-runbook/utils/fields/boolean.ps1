[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseApprovedVerbs', '', Justification = 'Field is a valid class name')]
class BooleanField : Field {

    [bool]$DefaultValue

    BooleanField(
        [string]$Group,
        [string]$InternalName,
        [string]$DisplayName,
        [string]$Description,
        [bool]$Required,
        [bool]$EnforceUniqueValues,
        [bool]$DefaultValue
    ) : base(
        $Group,
        $InternalName,
        $DisplayName,
        $Description,
        $Required,
        $EnforceUniqueValues
    ) {
        $this.DefaultValue = $DefaultValue
    }

    [string]GetFieldSchema() {
        $schema = ([Field]$this).GetBasicFieldSchema('Boolean')

        $schema += "><Default>$(BooleanToInt -Value $this.DefaultValue)</Default></Field>"

        return $schema
    }

    [void]CreateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.FieldCollection] $Fields
    ) {
        ([Field]$this).CreateSharePointField($Context, $Fields)
    }
}