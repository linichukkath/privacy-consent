[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseApprovedVerbs', '', Justification = 'Field is a valid class name')]
class TaxonomyField : Field {

    [bool]$AllowMultipleValues
    [string]$TermGroupName
    [string]$TermSetName
    [string]$TermName
    [bool]$IsTermSetECCS
    [bool]$FallbackToLocalTermSet
    [string]$CompanyId

    TaxonomyField(
        [string]$Group,
        [string]$InternalName,
        [string]$DisplayName,
        [string]$Description,
        [bool]$Required,
        [bool]$EnforceUniqueValues,
        [bool]$AllowMultipleValues,
        [string]$TermGroupName,
        [string]$TermSetName,
        [string]$TermName,
        [bool]$IsTermSetECCS,
        [bool]$FallbackToLocalTermSet,
        [string]$CompanyId
    ) : base(
        $Group,
        $InternalName,
        $DisplayName,
        $Description,
        $Required,
        $EnforceUniqueValues
    ) {
        $this.AllowMultipleValues = $AllowMultipleValues
        $this.TermGroupName = $TermGroupName
        $this.TermSetName = $TermSetName
        $this.TermName = $TermName
        $this.IsTermSetECCS = $IsTermSetECCS
        $this.FallbackToLocalTermSet = $FallbackToLocalTermSet
        $this.CompanyId = $CompanyId
    }

    [string]GetFieldSchema() {
        $schema = ([Field]$this).GetBasicFieldSchema('TaxonomyFieldType')

        if ($this.AllowMultipleValues) {
            $schema += " Mult='TRUE'"
        }

        $schema += "/>"

        return $schema
    }

    [Microsoft.SharePoint.Client.Taxonomy.TermSet]CreateLocalTermSet(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.Taxonomy.TermStore] $TermStore
    ) {
        $Site = $Context.site
        $Context.load($Site)
        ExecuteQueryWithRetry -Ctx $Context

        $LocalGroup = $Termstore.GetSiteCollectionGroup($Site, $true)
        $Context.load($LocalGroup)
        ExecuteQueryWithRetry -Ctx $Context

        $Context.Load($LocalGroup.TermSets)
        ExecuteQueryWithRetry -Ctx $Context
        $TermSet = $LocalGroup.TermSets  | Where-Object {$_.Name -eq $this.TermSetName}

        if($null -eq $TermSet){
            $TermSet = $LocalGroup.CreateTermSet($this.TermSetName, [System.Guid]::NewGuid(), 1033)
            $Context.load($TermSet)
            ExecuteQueryWithRetry -Ctx $Context
        }

        return $TermSet
    }

    [void]BindTermSet(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.Field] $Fields
    ) {
        $TaxonomySession = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($Context)
        $TermStore = $TaxonomySession.GetDefaultSiteCollectionTermStore()
        $Context.Load($TaxonomySession)
        $Context.Load($TermStore)
        ExecuteQueryWithRetry -Ctx $Context
        #Get the Term Group
        $TermGroup = $TermStore.Groups.GetByName($this.TermGroupName)
        if ($null -eq $TermGroup) {
            throw "Term group $($this.TermGroupName) not found"
        }

        $TermSet = $null;
        $Term = $null;

        if ($this.IsTermSetECCS) {
            try {
                $Context.Load($TermGroup.TermSets)
                ExecuteQueryWithRetry -Ctx $Context
                $TermSet = $TermGroup.TermSets | Where-Object {$_.Name -eq $this.CompanyId}
                if($null -ne $TermSet) {
                    $Context.Load($TermSet.Terms)
                    ExecuteQueryWithRetry -Ctx $Context
                    $Term = $TermSet.Terms | Where-Object {$_.Name -eq $this.TermSetName}
                    if (($null -eq $Term)) {
                        if ($this.FallbackToLocalTermSet) {
                            try {
                                $TermSet = $this.CreateLocalTermSet($Context, $TermStore)
                                $Term = $null
                            } catch {
                                throw $_
                            }
                        } else {
                            try {
                                $TermSet = $TermGroup.TermSets | Where-Object {$_.Name -eq $this.TermSetName}
                                $Term = $null
                            } catch {
                                throw "non existing ECCS based term set without any fallback"
                            }
                        }
                    }
                } else {
                    Write-LogINFO "Termset for company $($this.CompanyId) not found in group $($this.TermGroupName)."
                    $TermSet = $TermGroup.TermSets | Where-Object {$_.Name -eq $this.TermSetName}
                    if($null -ne $TermSet) {
                        $Context.Load($TermSet.Terms)
                        ExecuteQueryWithRetry -Ctx $Context
                        if(($null -ne $this.TermName) -and ($this.TermName -ne '')) {
                            $Term = $TermSet.Terms.GetByName($this.TermName)
                            $Context.Load($Term)
                            ExecuteQueryWithRetry -Ctx $Context
                        }
                    }
                }
            } catch {
                throw $_
            }

        } else {
            try {
                $TermSet = $TermGroup.TermSets.GetByName($this.TermSetName)
                $Context.Load($TermSet)
                ExecuteQueryWithRetry -Ctx $Context
                $Term = $TermSet.Terms.GetByName($this.TermName)
                $Context.Load($Term)
                ExecuteQueryWithRetry -Ctx $Context
            }
            catch {
                throw
            }
        }

        # Exceptions
        if (($null -eq $TermSet)) {
            throw "Termset not found $($this.TermGroupName) / $($this.TermSetName) / $($this.TermName)"
        }

        #Bind Managed Metadata Termset to the column
        $TaxField = [Microsoft.SharePoint.Client.ClientContext].GetMethod("CastTo").MakeGenericMethod([Microsoft.SharePoint.Client.Taxonomy.TaxonomyField]).Invoke($Context, $Fields)
        $TaxField.SspId = $TermStore.Id
        $TaxField.TermSetId = $TermSet.Id
        if ($null -ne $Term) {
            $TaxField.AnchorId = $Term.Id
        } else {
            $TaxField.AnchorId = [System.Guid]::Empty
        }
        $TaxField.Update()
        ExecuteQueryWithRetry -Ctx $Context

        Write-LogINFO "Site Column Binded to the Termset Successfully!"
    }

    [void]CreateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.FieldCollection] $Fields
    ) {
        $Field = ([Field]$this).CreateSharePointField($Context, $Fields)
        $this.BindTermSet($Context, $Field)
    }

    [void]UpdateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.Field] $Field
    ) {
        ([Field]$this).BindTermSet($Context, $Field)
    }
}

