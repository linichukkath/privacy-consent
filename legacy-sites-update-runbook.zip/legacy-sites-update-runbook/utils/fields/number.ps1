[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseApprovedVerbs', '', Justification = 'Field is a valid class name')]
class NumberField : Field {

    [bool]$Percentage
    [int]$Decimals
    [int]$MinimumValue
    [int]$MaximumValue
    [string]$DefaultValue

    NumberField(
        [string]$Group,
        [string]$InternalName,
        [string]$DisplayName,
        [string]$Description,
        [bool]$Required,
        [bool]$EnforceUniqueValues,
        [string]$DefaultValue,
        [bool]$Percentage,
        [int]$Decimals,
        [int]$MinimumValue,
        [int]$MaximumValue) : base(
            $Group,
            $InternalName,
            $DisplayName,
            $Description,
            $Required,
            $EnforceUniqueValues
        ) {
            $this.Percentage = $Percentage
            $this.Decimals = $Decimals
            $this.MinimumValue = $MinimumValue
            $this.MaximumValue = $MaximumValue
            $this.DefaultValue = $DefaultValue
    }

    [string]GetFieldSchema() {
        $schema = ([Field]$this).GetBasicFieldSchema('Number')

        # CAUTION! when this is true the min and max values are multiplied by 100
        if ($this.Percentage) {
            $schema += " Percentage='TRUE'"
        }

        if ($null -ne $this.Decimals) {
            $schema += " Decimals='$($this.Decimals)'"
        }

        if ($this.MinimumValue) {
            $schema += " Min='$($this.MinimumValue)'"
        }

        if ($this.MaximumValue) {
            $schema += " Max='$($this.MaximumValue)'"
        }

        $schema += ">"

        if ($this.DefaultValue) {
            $schema += "<Default>$($this.DefaultValue)</Default>"
        }

        $schema += "</Field>"

        return $schema
    }

    [void]CreateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.FieldCollection] $Fields
    ) {
        ([Field]$this).CreateSharePointField($Context, $Fields)
    }
}