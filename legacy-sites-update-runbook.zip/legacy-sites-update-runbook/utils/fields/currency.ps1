[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseApprovedVerbs', '', Justification = 'Field is a valid class name')]
class CurrencyField : Field {

    [int]$Decimals
    [int]$MinimumValue
    [int]$MaximumValue
    [string]$CurrencyLocaleId
    [string]$DefaultValue

    CurrencyField(
        [string]$Group,
        [string]$InternalName,
        [string]$DisplayName,
        [string]$Description,
        [bool]$Required,
        [bool]$EnforceUniqueValues,
        [string]$DefaultValue,
        [int]$Decimals,
        [int]$MinimumValue,
        [int]$MaximumValue,
        [int]$CurrencyLocaleId) : base(
            $Group,
            $InternalName,
            $DisplayName,
            $Description,
            $Required,
            $EnforceUniqueValues
        ) {
            $this.Decimals = $Decimals
            $this.MinimumValue = $MinimumValue
            $this.MaximumValue = $MaximumValue
            $this.CurrencyLocaleId = $CurrencyLocaleId
            $this.DefaultValue = $DefaultValue
    }

    [string]GetFieldSchema() {
        $schema = ([Field]$this).GetBasicFieldSchema('Currency')

        if ($null -ne $this.Decimals) {
            $schema += " Decimals='$($this.Decimals)'"
        }

        if ($this.MinimumValue) {
            $schema += " Min='$($this.MinimumValue)'"
        }

        if ($this.MaximumValue) {
            $schema += " Max='$($this.MaximumValue)'"
        }

        if ($this.CurrencyLocaleId) {
            $schema += " LCID='$($this.CurrencyLocaleId)'"
        }

        $schema += ">"

        if ($this.DefaultValue) {
            $schema += "<Default>$($this.DefaultValue)</Default>"
        }

        $schema += "</Field>"

        return $schema
    }

    [void]CreateField(
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [Microsoft.SharePoint.Client.FieldCollection] $Fields
    ) {
        ([Field]$this).CreateSharePointField($Context, $Fields)
    }
}