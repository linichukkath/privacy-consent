$global:CurrDir = "."
Import-Module -Name Microsoft.Online.SharePoint.PowerShell
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Taxonomy.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.DocumentManagement.dll"

Import-Module "$global:CurrDir\utils\ups.ps1"
Import-Module "$global:CurrDir\utils\interceptor.ps1"
Import-Module "$global:CurrDir\workflows\site-design.ps1"

$tenant = "allianzms"
$storageQuota = "1"
$template = "STS#3"
$Params = Get-ProvisioningParameter
$Params.Title = "Legacy E3 Site 0001"

function createDocumentSet($ctx, $library, $documentSetName, $contentTypeName, $legacyContentTypes, $ContentTypeDefinitions) {

    try {
        $ContentType = $library.ContentTypes | Where-Object {$_.Name -eq $contentTypeName}
        $Ctx.Load($library.RootFolder)
        ExecuteQueryWithRetry -ctx $Ctx

        if ($Null -ne $ContentType) {
            $DocumentSet = [Microsoft.SharePoint.Client.DocumentSet.DocumentSet]::Create($Ctx, $library.RootFolder, $DocumentSetName, $ContentType.ID)
            ExecuteQueryWithRetry -ctx $Ctx

            $Folder = $Ctx.Web.GetFolderByServerRelativeUrl($DocumentSet.Value.Replace("https://allianzms.sharepoint.com",""))
            $Ctx.Load($Folder)
            ExecuteQueryWithRetry -ctx $Ctx
            $properties = $Folder.ListItemAllFields;
            $Ctx.Load($properties)
            $properties['_ExtendedDescription'] = 'Test Extended Description'
            $properties['DocumentSetDescription'] = 'Test Description'
            $properties['DocumentClass'] = 'Accounting record'
            $properties.Update()
            ExecuteQueryWithRetry -ctx $Ctx

            $index = 1
            foreach ($ContentTypeConfigItem in $legacyContentTypes) {
                $Id = $ContentTypeConfigItem.Key
                $ContentTypeConfig = $ContentTypeDefinitions.$Id;
                overrideSettings $ContentTypeConfig $ContentTypeConfigItem.Overrides
                if($ContentTypeConfig.ParentContentTypeId -ne '0x0120D520')
                {
                    uplodadTestFiles -Id $Id -Index $index -Library $library -Context $Ctx -Folder $folder
                }
                $index++
            }

            Write-LogINFO "Document Set '$DocumentSetName' Created Successfully!'"
        }
        else {
            Write-LogINFO "Content Type '$ContentTypeName' doesn't exist!'"
        }
    }
    catch {
        Write-LogERR "Error:" $_.Exception.Message
    }
}


function uplodadTestFiles($contentTypeId, $index, $library, $context, $folder) {
    $sourceFile = "$global:CurrDir\tests\files\document_with_old_content_type.docx"

    #Get the file from disk
    $FileStream = ([System.IO.FileInfo] (Get-Item $SourceFile)).OpenRead()
    #Get File Name from source file path
    $SourceFileName = "Document " + $index + ".docx"

    #sharepoint online upload file powershell
    $FileCreationInfo = New-Object Microsoft.SharePoint.Client.FileCreationInformation
    $FileCreationInfo.Overwrite = $true
    $FileCreationInfo.ContentStream = $FileStream
    $FileCreationInfo.URL = $SourceFileName
    if($null -eq $folder){
        $FileUploaded = $Library.RootFolder.Files.Add($FileCreationInfo)
    }
    else{
     $FileUploaded = $Folder.Files.Add($FileCreationInfo)
    }

    #powershell upload single file to sharepoint online
    $Context.Load($FileUploaded)
    ExecuteQueryWithRetry -Ctx $Context

    #Set Metadata
    $properties = $FileUploaded.ListItemAllFields;
    $Context.Load($properties)
    $properties["ContentTypeId"] = $contentTypeId
    $properties['_ExtendedDescription'] = 'Test Extended Description'
    $properties.Update()
    ExecuteQueryWithRetry -Ctx $Context

    $FileStream.Close()

    Write-LogINFO "File has been uploaded!"
}

function CreateDocumentLibrary($libraryName, $context, $legacyContentTypes, $ContentTypeDefinitions, $ContentTypeColl) {
    try {
        #create document library in sharepoint online powershell
        $ListInfo = New-Object Microsoft.SharePoint.Client.ListCreationInformation
        $ListInfo.Title = $libraryName
        $ListInfo.TemplateType = 101
        $List = $context.Web.Lists.Add($ListInfo)
        $List.ContentTypesEnabled = $true
        $List.Update()
        ExecuteQueryWithRetry -Ctx $Context

        #Get all existing content types of the list
        $ListContentTypes = $List.ContentTypes
        $Context.Load($ListContentTypes)
        ExecuteQueryWithRetry -Ctx $Context

        foreach ($ContentType in $legacyContentTypes) {
            $ctId = $ContentType.Key
            if($null -ne $ContentType.Overrides) {
            if($null -ne $ContentType.Overrides.Id) {
                    $ctId = $ContentType.Overrides.Id
                }
            }
            AddContentTypeToList $context $List $ctId $ContentTypeDefinitions $ListContentTypes $ContentTypeColl
        }
        Write-LogINFO "New Document Library has been created!"
        }
    catch {
        Write-LogERR "Failed to create document library $libraryName. Error: $_"
    }
}

function UpdateLib($libraryName, $context, $legacyContentTypes, $ContentTypeDefinitions) {
    try {
        $library = GetListByEntityTypeName $context $libraryName
        $language = $Params.Language
        $context.Load($library.ContentTypes)
        ExecuteQueryWithRetry -Ctx $Context
        foreach ($ContentTypeConfigItem in $legacyContentTypes) {
            $Id = $ContentTypeConfigItem.Key
            $ContentTypeConfig = $ContentTypeDefinitions.$Id;
            overrideSettings $ContentTypeConfig $ContentTypeConfigItem.Overrides
            if($ContentTypeConfig.ParentContentTypeId -eq '0x0120D520')
            {
                $index = Get-Random -Minimum 1 -Maximum 10000
                $name = "Document Set "+ $index
                $ctName = $ContentTypeConfigItem.Overrides.Name.$language
                createDocumentSet -context $context -library $library -name $name -ctName $ctName -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions
            }
            else{
                $i = 1
                Do {
                    foreach ($ContentTypeConfigItem in $legacyContentTypes) {
                        $index = Get-Random -Minimum 1 -Maximum 10000
                        uplodadTestFiles -Id $Id -Index $index -Library $library -Context $context
                    }
                    $i = $i + 1
                } While ($i -lt 3000)
            }
        }
        Write-LogINFO "New Document Library has been created!"
    }
    catch {
        Write-LogERR "Failed to create document library $libraryName. Error: $_"
    }
}

try {
    Write-LogINFO '=== The DMS provisioning script has started ==='
    ProvisionSite -tenant $tenant -owner $Params.Admin1 -url $Params.SPOURL -title $Params.Title -siteCollectionAdmin $Params.O365Admin -template $template -storagequota $storageQuota
    $context = GetSPOContext -siteUrl $Params.SPOURL

    $legacyConfigPath = "$global:CurrDir\configs\tests\e3-legacy-site-provisioning.json"

    # TODO upload some testing files
    $legacyConfig = Get-Content $legacyConfigPath -Raw -encoding utf8 | ConvertFrom-Json
    $legacyContentTypes = $legacyConfig.ContentTypes

    ProvisionSiteDesign $Params $legacyConfigPath


    # Content Types
    $ContentTypeDefinitions = Get-Content "$global:CurrDir\configs\content-types.json" -Raw -encoding utf8 | ConvertFrom-Json

    #Get the content type to Add to list
    $ContentTypeColl = $Context.Web.ContentTypes
    $Context.Load($ContentTypeColl)
    ExecuteQueryWithRetry -Ctx $Context

    CreateDocumentLibrary -library 'Lib1' -context $context -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions -ContentTypeColl $ContentTypeColl
    CreateDocumentLibrary -library 'Lib2' -context $context -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions -ContentTypeColl $ContentTypeColl
    CreateDocumentLibrary -library 'Lib3' -context $context -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions -ContentTypeColl $ContentTypeColl
    CreateDocumentLibrary -library 'Lib4' -context $context -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions -ContentTypeColl $ContentTypeColl
    CreateDocumentLibrary -library 'Lib5' -context $context -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions -ContentTypeColl $ContentTypeColl

    $ContentTypeDefinitions = Get-Content "$global:CurrDir\configs\content-types.json" -Raw -encoding utf8 | ConvertFrom-Json

    UpdateLib -library 'Lib1' -context $context -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions
    UpdateLib -library 'Lib2' -context $context -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions
    UpdateLib -library 'Lib3' -context $context -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions
    UpdateLib -library 'Lib4' -context $context -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions
    UpdateLib -library 'Lib5' -context $context -legacyContentTypes $legacyContentTypes -ContentTypeDefinitions $ContentTypeDefinitions

    # Remove temporary site collection admin
    RemoveSiteCollectionAdmin $Params.SPOURL $Params.O365Admin
}
catch {
    Write-LogERR $_.Exception.Message
    return
}