Import-Module "$global:CurrDir\utils\interceptor.ps1"
Import-Module "$global:CurrDir\utils\auth.ps1"
Import-Module "$global:CurrDir\utils\site.ps1"
Import-Module "$global:CurrDir\utils\columns.ps1"
Import-Module "$global:CurrDir\utils\content-types.ps1"
Import-Module "$global:CurrDir\utils\library.ps1"
Import-Module "$global:CurrDir\utils\property-bag.ps1"
Import-Module "$global:CurrDir\utils\update-utils.ps1"

Function ValidateSite($siteUrl, $tenant, $siteCollectionAdminUserName, $tenantAdminUserName, $isDMSUPS, $languageUPS,  $siteType, $context, $companyId) {
    $script:TaxonomyCache = $null
    Write-LogINFO "Integration test started....."
    if($null -eq $context) {
        Write-LogERR "No context provided for ValidateSite on $siteUrl"
        return $false
    }
    $siteType = GetPropertyBag $context 'customSiteType'
    if ($siteType -eq "DMS") {
        $configPath = "$global:CurrDir\configs\e5.json"
        $legacyUpdateConfigPath = "$global:CurrDir\configs\legacy-to-e5-update.json"
    }
    else {
        $configPath = "$global:CurrDir\configs\e3.json"
        $legacyUpdateConfigPath = "$global:CurrDir\configs\legacy-to-e3-update.json"
    }
    $libToIgnorePath = "$global:CurrDir\configs\library-ignore.json"
    $libToIgnore = Get-Content $libToIgnorePath -Raw -encoding utf8 | ConvertFrom-Json
    Write-LogINFO "Validating if the site is based on $($siteType) site template."

    $validateScripting = isCustomSiteScriptingDisabled $siteUrl
    Write-LogINFO "Site Scripting Protection: $($validateScripting)"
    # Check for string values "Enabled" or "Disabled"
    if ($validateScripting -eq "Disabled") {
        return $false
    }

    $validatePropertyBag = ValidatePropertyBag -Context $context -IsDMSUPS $isDMSUPS -LanguageUPS $languageUPS -companyId $companyId
    Write-LogINFO "Site property bag values: $($validatePropertyBag)"
    if (!$validatePropertyBag) {
        return $false
    }

    $validateFeatures = areAllFeaturesEnabled -Context $context
    Write-LogINFO "All features are enabled: $($validateFeatures)"
    if (!$validateFeatures) {
        return $false
    }

    $validateColumns = validateColumns -Context $context
    Write-LogINFO "All columns are there: $($validateColumns)"
    if (!$validateColumns) {
        return $false
    }

    $validateContentTypes = validateContentTypes -Context $context
    Write-LogINFO "All content types are there: $($validateContentTypes)"
    if (!$validateContentTypes) {
        return $false
    }

    $SiteConfig = Get-Content $configPath -Raw -encoding utf8 | ConvertFrom-Json
    $SiteDesignColumns = $SiteConfig.Columns
    $ColumnDefinitions = Get-Content "$global:CurrDir\configs\columns.json" -Raw -encoding utf8 | ConvertFrom-Json

    $areAllSiteCtsValid = ValidateCTColumns -Context $context -SiteDesignColumns $SiteDesignColumns -BaseColumnDefinitions $ColumnDefinitions
    Write-LogINFO "All columns are there in site level content types: $($ValidateCTColumns)"
    if (!$areAllSiteCtsValid) {
        return $false
    }

    $language = GetSitelanguage -Context $context -Web $context.Web

    $legacyUpdateConfig = Get-Content $legacyUpdateConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Write-LogINFO "Looking for all the document libraries..."
    $Libraries = GetAllDocumentLibraries -Ctx $context -Config $libToIgnore

    $LegacyContentTypes = @{}
    foreach ($ContentType in $legacyUpdateConfig.ContentTypes) {
        if ($ContentType.LegacyNames) {
            foreach ($LegacyName in $ContentType.LegacyNames) {
                $LegacyContentTypes[$LegacyName] = $ContentType.Key
            }
        }
    }

    foreach ($Library in $Libraries) {
        $validateDocumentsLibrary = validateDocumentContentTypes -Context $context -Library $Library
        Write-LogINFO "All content types are there in library - $($Library.Title): $($validateDocumentsLibrary)"
        if (!$validateDocumentsLibrary) {
            return $false
        }

        $areAllLibraryCtsValid = ValidateCTColumns -Context $context -Library $Library -SiteDesignColumns $SiteDesignColumns -BaseColumnDefinitions $ColumnDefinitions
        Write-LogINFO "Content type column settings are valid for library - $($Library.Title): $($ValidateDocCTColumns)"
        if (!$areAllLibraryCtsValid) {
            return $false
        }

        $validateViews = validateViews -Context $context -Library $Library -Language $language
        Write-LogINFO "Views configuration is valid for library - $($Library.Title): $($validateViews)"
        if (!$validateViews) {
            return $false
        }

        $areAllViewFieldsValid = validateViewFields -Context $context -Library $Library -Language $language
        Write-LogINFO "All view fields are there in library - $($Library.Title): $($areAllViewFieldsValid)"
        if (!$areAllViewFieldsValid) {
            return $false
        }

        # Validate New Button Menu Items
        $Libraries = $SiteConfig.Libraries
        $LibraryDefinitions = Get-Content "$global:CurrDir\configs\libraries.json" -Raw -encoding utf8 | ConvertFrom-Json
        $LibraryKey = $Libraries.Key
        $LibraryConfig = $LibraryDefinitions.$LibraryKey
        overrideSettings $LibraryConfig $Libraries.Overrides
        $ContentTypes = $LibraryConfig.ContentTypes
        $ExpectedMenuItems = $ContentTypes | Where-Object { $_.ShownInNewButtonMenu -eq $true }
        $validateNewButtonMenuItems = CheckNewButtonMenuItems -Context $context -Library $Library -ExpectedMenuItems $ExpectedMenuItems
        Write-LogINFO "New button menu items are valid for library - $($Library.Title): $($validateNewButtonMenuItems)"
        if (!$validateNewButtonMenuItems) {
            return $false
        }

        # Validate Legacy Content Types
        $LibraryLegacyContentTypesAtLibraryLevel = GetLegacyContentTypesAtLibraryLevel -Context $context -Library $Library -LegacyContentTypes $LegacyContentTypes
        if(@($LibraryLegacyContentTypesAtLibraryLevel).Count -gt 0) {
            $validateLegacyContentTypes = ValidateLegacyContentTypes -Context $context -Library $Library -LegacyContentTypes $LibraryLegacyContentTypesAtLibraryLevel
            Write-LogINFO "No items with legacy content types found in library - $($Library.Title): $($validateLegacyContentTypes)"
            if (!$validateLegacyContentTypes) {
                return $false
            }
        }
        else {
            Write-LogINFO "No items with legacy content types found in library - $($Library.Title)."
        }
    }
    return $true;
}
Function isCustomSiteScriptingDisabled($siteUrl) {
    $IsCustomSiteScriptingDisabled = Get-SPOSite -Identity $siteUrl -Detailed | Select-Object DenyAddAndCustomizePages
    return $IsCustomSiteScriptingDisabled.DenyAddAndCustomizePages
}
Function GetLibraryTitle($language) {

    # Load configurations from the file
    $Config = Get-Content $configPath -Raw -encoding utf8 | ConvertFrom-Json
    $Libraries = $Config.Libraries

    $LibraryDefinitions = Get-Content "$global:CurrDir\configs\libraries.json" -Raw -encoding utf8 | ConvertFrom-Json

    $LibraryKey = $Libraries.Key
    $LibraryConfig = $LibraryDefinitions.$LibraryKey

    # Get the document library
    $libraryTitle = $LibraryConfig.Name.$language
    return $libraryTitle
}
Function areAllFeaturesEnabled($context) {
    $Site = $Context.Site

    $Features = @(
        @{ Key = "DocumentSet"; Value = "3bae86a2-776d-499d-9db8-fa4cdc7884f8" },
        @{ Key = "Taxonomy"; Value = "73EF14B1-13A9-416b-A9B5-ECECA2B0604C" },
        @{ Key = "DocumentID"; Value = "b50e3104-6812-424f-a011-cc90e6327318" }
    )

    foreach ($Feature in $Features) {
        # The Feature Value is the GUID
        $FeatureStatus = $Site.Features.GetById($Feature.Value)
        $FeatureStatus.Retrieve("DefinitionId")
        $context.Load($FeatureStatus)
        ExecuteQueryWithRetry -Ctx $Context

        # If we have a definitionId => the feature was loaded
        if ($null -eq $FeatureStatus.DefinitionId) {
            return $false
        }
    }

    return $true
}
Function validateColumns($context) {
    $Config = Get-Content $configPath -Raw -encoding utf8 | ConvertFrom-Json
    $Columns = $Config.Columns
    $Fields = $context.web.Fields
    $context.Load($Fields)
    ExecuteQueryWithRetry -Ctx $Context
    $FieldHashTable = @{}
    foreach ($Field in $Fields) {
        $FieldHashTable[$Field.InternalName] = $true
    }
    foreach ($ColumnConfigItem in $Columns) {
        if (-not $FieldHashTable.ContainsKey($ColumnConfigItem.Key)) {
            Write-LogERR "Column $($ColumnConfigItem.Key) not found in fields."
            return $false
        }
        Write-LogINFO "Column $($ColumnConfigItem.Key) found."
    }
    return $true
}
Function validateContentTypes($context) {
    $Config = Get-Content $configPath -Raw -encoding utf8 | ConvertFrom-Json
    $ContentTypes = $Config.ContentTypes
    $SiteContentTypes = $context.web.ContentTypes
    $context.Load($SiteContentTypes)
    ExecuteQueryWithRetry -Ctx $Context
    $ContentTypeHashTable = @{}
    foreach ($SiteContentType in $SiteContentTypes) {
        if ($SiteContentType.Id) {
            $ContentTypeHashTable[$SiteContentType.Id] = $true
        }
    }
    foreach ($ContentType in $ContentTypes) {
        $found = $ContentTypeHashTable.Keys | Where-Object { $_ -like "*$($ContentType.Key)*" }
        if (-not $found) {
            Write-LogERR "Content type $($ContentType.Key) not found at site level."
            return $false
        }
        Write-LogINFO "Content type $($ContentType.Key) found at site level."
    }
    return $true
}
Function ValidateCTColumns($context, $library, $SiteDesignColumns, $BaseColumnDefinitions) {
    $Config = Get-Content $configPath -Raw -encoding utf8 | ConvertFrom-Json
    $ConfigContentTypes = $Config.ContentTypes
    $ContentTypeDefinitions = Get-Content "$global:CurrDir\configs\content-types.json" -Raw -encoding utf8 | ConvertFrom-Json
    $ContentTypes = LoadContentTypes -Context $context -Library $library
    foreach ($ContentType in $ConfigContentTypes) {
        $ContentTypeId = $ContentType.Key
        $ContentTypeConfig = $ContentTypeDefinitions.$ContentTypeId
        $ContentTypeObject = GetContentTypeObject -Context $context -Library $library -ContentTypeId $ContentTypeId -ContentTypes $ContentTypes
        if (-not $ContentTypeObject) {
            Write-LogERR "Content type '$ContentTypeId' not found."
            return $false
        }
        $IsValid = ValidateContentTypeColumns -Context $context -Library $library -ContentTypeObject $ContentTypeObject -ContentTypeConfig $ContentTypeConfig -SiteDesignColumns $SiteDesignColumns -BaseColumnDefinitions $BaseColumnDefinitions
        if (-not $IsValid) {
            return $false
        }
        if ($null -ne $library) {
            $HasUnwantedColumns = ValidateUnwantedColumns -Context $context -ContentTypeObject $ContentTypeObject -ContentTypeConfig $ContentTypeConfig
            if (-not $HasUnwantedColumns) {
                return $false
            }
        }
    }
    return $true
}
Function LoadContentTypes($Context, $Library) {
    if ($null -ne $Library) {
        $Context.Load($Library.ContentTypes)
        ExecuteQueryWithRetry -Ctx $Context
        return $Library.ContentTypes
    } else {
        $ContentTypes = $Context.Web.ContentTypes
        $Context.Load($ContentTypes)
        ExecuteQueryWithRetry -Ctx $Context
        return $ContentTypes
    }
}
Function GetContentTypeObject($Context, $Library, $ContentTypeId, $ContentTypes) {
    if ($null -ne $Library) {
        return GetListContentTypeByParent -Context $Context -contentTypeParentId $ContentTypeId -contentTypes $ContentTypes
    } else {
        return $ContentTypes | Where-Object { $_.Id.StringValue -eq $ContentTypeId }
    }
}
Function ValidateContentTypeColumns($Context, $Library, $ContentTypeObject, $ContentTypeConfig, $SiteDesignColumns, $BaseColumnDefinitions) {
    $Context.Load($ContentTypeObject.FieldLinks)
    $Parent = $ContentTypeObject.Parent
    $Context.Load($Parent)
    ExecuteQueryWithRetry -Ctx $Context
    if($null -ne $Library) {
        $Parent = $Parent.Parent
        $Context.Load($Parent)
        ExecuteQueryWithRetry -Ctx $Context
    }
    if ($Parent.Name -eq 'Document Set') {
        $DocSetTemplate = [Microsoft.SharePoint.Client.DocumentSet.DocumentSetTemplate]::GetDocumentSetTemplate($Context, $ContentTypeObject)
        $Context.Load($DocSetTemplate)
        $Context.Load($DocSetTemplate.SharedFields)
        ExecuteQueryWithRetry -Ctx $Context
    }
    foreach ($SiteColumnConfig in $ContentTypeConfig.Columns) {
        $FieldLink = $ContentTypeObject.FieldLinks | Where-Object { $_.Name -eq $SiteColumnConfig.InternalName }
        if (-not $FieldLink) {
            Write-LogERR "Column '$($SiteColumnConfig.InternalName)' not found in content type $($ContentTypeObject.Name), library $($Library.Title)."
            return $false
        }
        $IsValid = ValidateFieldLinkSettings -FieldLink $FieldLink -SiteColumnConfig $SiteColumnConfig
        if (-not $IsValid) {
            return $false
        }
        if ($SiteColumnConfig.Shared) {
            $IsShared = $DocSetTemplate.SharedFields | Where-Object { $_.InternalName -eq $SiteColumnConfig.InternalName }
            if (-not $IsShared) {
                Write-LogERR "The column '$($SiteColumnConfig.InternalName)' is NOT added as a shared field in the document set settings in content type '$($ContentTypeObject.Name), library $($Library.Title)'."
                return $false
            }
        }
        $IsTaxonomyValid = ValidateTaxonomyField -Context $Context -FieldLink $FieldLink -SiteColumnConfig $SiteColumnConfig -SiteDesignColumns $SiteDesignColumns -BaseColumnDefinitions $BaseColumnDefinitions
        if (-not $IsTaxonomyValid) {
            return $false
        }
    }
    return $true
}
Function ValidateFieldLinkSettings($FieldLink, $SiteColumnConfig) {
    if ($FieldLink.Required -ne $SiteColumnConfig.Required) {
        Write-LogERR "Column '$($SiteColumnConfig.InternalName)' 'Required' setting does not match."
        return $false
    }
    if ($FieldLink.Hidden -ne $SiteColumnConfig.Hidden) {
        Write-LogERR "Column '$($SiteColumnConfig.InternalName)' 'Hidden' setting does not match."
        return $false
    }
    return $true
}
Function ValidateTaxonomyField($Context, $FieldLink, $SiteColumnConfig, $SiteDesignColumns, $BaseColumnDefinitions) {
    $SiteColumn = $Context.Web.Fields.GetById($FieldLink.Id)
    $Context.Load($SiteColumn)
    ExecuteQueryWithRetry -Ctx $Context
    if ($SiteColumn.TypeAsString -eq 'TaxonomyFieldType') {
        $ColumnConfigItem = $SiteDesignColumns | Where-Object { $_.Key -eq $SiteColumnConfig.InternalName }
        $InternalName = $SiteColumnConfig.InternalName
        $ColumnConfig = $BaseColumnDefinitions.$InternalName
        overrideSettings $ColumnConfig $ColumnConfigItem.Overrides
        $IsTaxonomyMappingValid = ValidateManagedMetadataColumn -Column $SiteColumn -ColumnConfig $ColumnConfig
        if (-not $IsTaxonomyMappingValid) {
            Write-LogERR "Term set mapping is incorrect for column '$($SiteColumnConfig.InternalName)'."
            return $false
        }
    }
    return $true
}
Function ValidateUnwantedColumns($Context, $ContentTypeObject, $ContentTypeConfig) {
    $ConfiguredColumnNames = $ContentTypeConfig.Columns | ForEach-Object { $_.InternalName }
    $SystemColumns = @(
        "ContentTypeId", "Created", "Modified", "Author", "Editor", "_UIVersionString", "_ModerationStatus",
        "_CheckinComment", "_HasCopyDestinations", "_CopySource", "_Hidden", "_Level", "_IsCurrentVersion",
        "FileLeafRef", "Title", "ContentType", "SelectFilename", "Modified_x0020_By", "Created_x0020_By",
        "_dlc_DocId", "_dlc_DocIdUrl", "_dlc_DocIdPersistId", "TaxCatchAll", "TaxCatchAllLabel", "ItemChildCount",
        "FolderChildCount", "_ApprovalAssignedTo", "_ApprovalRespondedBy", "_ApprovalStatus", "_ApprovalSentBy", "MediaServiceLocation",
        "lcf76f155ced4ddcb4097134ff3c332f", "SharedWithUsers", "SharedWithDetails",
        "MediaServiceMetadata", "MediaServiceFastMetadata", "MediaServiceSearchProperties", "MediaServiceObjectDetectorVersions", "Keyword1"
    )
    $UnwantedFieldLinks = $ContentTypeObject.FieldLinks | Where-Object {
        $_.Name -notin $ConfiguredColumnNames -and $_.Name -notin $SystemColumns -and $_.Hidden -eq $false
    }
    $Context.Load($ContentTypeObject.Parent.FieldLinks)
    ExecuteQueryWithRetry -Ctx $Context
    $NonInheritedFieldLinks = @()
    foreach ($FieldLink in $UnwantedFieldLinks) {
        $IsInherited = $ContentTypeObject.Parent.FieldLinks | Where-Object { $_.Id -eq $FieldLink.Id }
        if (-not $IsInherited) {
            $NonInheritedFieldLinks += $FieldLink
        }
    }
    if ($NonInheritedFieldLinks.Count -gt 0) {
        foreach ($UnwantedFieldLink in $NonInheritedFieldLinks) {
            Write-LogERR "Unwanted column '$($UnwantedFieldLink.Name)' found in content type '$($ContentTypeObject.Name)'."
        }
        return $false
    }
    return $true
}
Function validateDocumentContentTypes($context, $library) {
    $Config = Get-Content $configPath -Raw -encoding utf8 | ConvertFrom-Json
    $Libraries = $Config.Libraries
    $LibraryDefinitions = Get-Content "$global:CurrDir\configs\libraries.json" -Raw -encoding utf8 | ConvertFrom-Json
    $LibraryKey = $Libraries.Key
    $LibraryConfig = $LibraryDefinitions.$LibraryKey
    $ContentTypes = $LibraryConfig.ContentTypes
    $context.Load($library.ContentTypes)
    ExecuteQueryWithRetry -Ctx $Context
    $ContentTypeHashTable = @{}
    foreach ($DocumentContentType in $library.ContentTypes) {
        if ($DocumentContentType.Id) {
            $ContentTypeHashTable[$DocumentContentType.Id] = $true
        }
    }

    foreach ($ContentType in $ContentTypes) {
       $found = $ContentTypeHashTable.Keys | Where-Object { $_ -like "*$($ContentType.Id)*" }
        if (-not $found) {
            Write-LogERR "Content type $($ContentType.Id) not found in library - $($Library.Title)."
            return $false
        }
        Write-LogINFO "Content type $($ContentType.Id) found in library - $($Library.Title)."
    }
    return $true
}
Function validateViews($context, $library, $language) {
    $context.Load($library.Views)
    ExecuteQueryWithRetry -Ctx $Context
    $ViewDefinitions = Get-Content "$global:CurrDir\configs\views.json" -Raw -encoding utf8 | ConvertFrom-Json
    $ViewConfig = Get-Content $configPath -Raw -encoding utf8 | ConvertFrom-Json
    OverrideViewSettings $ViewDefinitions $ViewConfig.Views
    $ViewHashTable = @{}
    foreach ($DocumentView in $library.Views) {
        if ($DocumentView.Title) {
            $key = $DocumentView.Title -replace ' ', ''
            $ViewHashTable[$key] = $DocumentView.Title
        }
    }
    foreach ($View in $ViewConfig.Views) {
        $Action = $View.Action
        if($Action -eq 'DELETE'){
            $viewTitle = $ViewDefinitions.$($View.Key).Name.($language)
            if ($ViewHashTable.ContainsValue($viewTitle) -eq $true) {
                Write-LogINFO "Legacy view $($View.Key) found in library - $($Library.Title)"
                return $false
            }
        }
        else{
            $viewTitle = $ViewDefinitions.$($View.Key).Name.($language)
            if ($ViewHashTable.ContainsValue($viewTitle) -eq $false) {
                Write-LogERR "View $($View.Key) not found in library - $($Library.Title)"
                return $false
            }
            Write-LogINFO "View $($View.Key) found in library - $($Library.Title)"
        }
    }
    return $true
}
Function validateViewFields($context, $library, $language) {
    $context.Load($library.Views)
    ExecuteQueryWithRetry -Ctx $Context
    $ViewDefinitions = Get-Content "$global:CurrDir\configs\views.json" -Raw -encoding utf8 | ConvertFrom-Json
    $ViewConfig = Get-Content $configPath -Raw -encoding utf8 | ConvertFrom-Json
    OverrideViewSettings $ViewDefinitions $ViewConfig.Views
    foreach ($View in $ViewConfig.Views) {
        $Action = $View.Action
        if($Action -ne 'DELETE'){
            $viewTitle = $ViewDefinitions.$($View.Key).Name.($language)
            $lstView = $library.Views | Where-Object {$_.Title -eq $viewTitle}
            $context.Load($lstView.ViewFields)
            ExecuteQueryWithRetry -Ctx $Context
            $viewConfigFields = $ViewDefinitions.$($View.Key).Fields
            $fieldHashTable = @{}
            foreach ($field in $lstView.ViewFields) {
                $fieldHashTable[$field] = $true
            }
            foreach ($field in $viewConfigFields) {
                $found = $fieldHashTable.Keys | Where-Object { $_ -like "*$($field)*" }

                if (-not $found) {
                    Write-LogERR "Field $($field) not found in view $($viewTitle) in library $($library.Title)."
                    return $false
                }
                Write-LogINFO "Field $($field) found in view $($viewTitle) in library $($library.Title)."
            }
        }
    }
    return $true
}
Function CheckNewButtonMenuItems($Context, $Library, $ExpectedMenuItems) {
    $Views = $Library.Views
    $Context.Load($Views)
    ExecuteQueryWithRetry -Ctx $Context
    $DefaultView = $Views | Where-Object { $_.DefaultView -eq $true }
    if ($null -eq $DefaultView) {
        Write-LogERR "Default view not found for library '$($Library.Title)'"
        return $false
    }
    $Context.Load($DefaultView)
    $Context.Load($Library.ContentTypes)
    ExecuteQueryWithRetry -Ctx $Context
    $NewButtonMenuJson = $DefaultView.NewDocumentTemplates
    if ($null -eq $NewButtonMenuJson) {
        Write-LogERR "No New button menu items found for library '$($Library.Title)'"
        return $false
    }
    $ActualMenuItems = $NewButtonMenuJson | ConvertFrom-Json
    $ActualMenuItems = $ActualMenuItems  | Where-Object { ($_.Visible) -and ($null -ne $_.contentTypeId) -and ($_.title -ne 'Folder') -and ($_.contentTypeId -ne '') }
    $LibContentTypes = @()
    foreach ($MenuItem in $ActualMenuItems) {
        $ContentType = $Library.ContentTypes.GetById($MenuItem.contentTypeId)
        $Context.Load($ContentType)
        $Context.Load($ContentType.Parent)
        ExecuteQueryWithRetry -Ctx $Context
        $ParentContentType = $ContentType.Parent
        if ($null -ne $ParentContentType) {
            $LibContentTypes += [PSCustomObject]@{
                Parent      = $ParentContentType
                ContentType = $ContentType
            }
        }
    }
    foreach ($ExpectedItem in $ExpectedMenuItems) {
        $Match = $LibContentTypes | Where-Object { $_.Parent.Id.StringValue -eq $ExpectedItem.Id }
        if ($null -eq $Match) {
            Write-LogERR "Menu item with contentTypeId '$($ExpectedItem.templateId)' is missing in the New button for library '$($Library.Title)'"
            return $false
        }
    }
    return $true
}
Function FetchLibraryItems ($Context, $Library, $CamlQuery) {
    $AllItems = @()
    $Position = $null

    do {
        $CamlQuery.ListItemCollectionPosition = $Position
        $Items = $Library.GetItems($CamlQuery)
        $Context.Load($Items)
        ExecuteQueryWithRetry -Ctx $Context

        $AllItems += $Items
        $Position = $Items.ListItemCollectionPosition
    } while ($null -ne $Position)

    Write-LogINFO "Completed fetching filtered items from library '$($Library.Title)'. Total items fetched: $($AllItems.Count)."
    return $AllItems
}
Function ValidateLegacyContentTypes($Context, $Library, $LegacyContentTypes) {
    Write-LogINFO "Checking library '$($Library.Title)' for legacy content types."
    $HasLegacyContentTypes = $false
    foreach($LegacyCT in $LegacyContentTypes) {
        $LegacyCTName = $LegacyCT.LegacyName
        $Query = New-Object Microsoft.SharePoint.Client.CamlQuery
        $Query.ViewXml = "<View Scope='RecursiveAll'><Query><Where><Eq><FieldRef Name='ContentType' /><Value Type='Computed'>" + $LegacyCTName + "</Value></Eq></Where></Query><RowLimit>500</RowLimit></View>"
        $FilteredItems = FetchLibraryItems -Context $Context -Library $Library -CamlQuery $Query
        ForEach($Item in $FilteredItems)
        {
            $HasLegacyContentTypes = $true
            Write-LogINFO "Item with ID '$($Item.Id)' in library '$($Library.Title)' has legacy content type '$LegacyCTName'."
        }
    }
    if ($HasLegacyContentTypes) {
        return $false
    } else {
        Write-LogINFO "No items with legacy content types found in library '$($Library.Title)'."
        return $true
    }
}
Function GetLegacyContentTypesAtLibraryLevel ($Context, $Library, $LegacyContentTypes) {
    $LibraryContentTypes = $Library.ContentTypes
    $Context.Load($LibraryContentTypes)
    ExecuteQueryWithRetry -Ctx $Context
    $LegacyContentTypesHash = @{}
    foreach ($LegacyName in $LegacyContentTypes.Keys) {
        $LegacyContentTypesHash[$LegacyName] = $LegacyContentTypes[$LegacyName]
    }
    $LibraryLegacyContentTypes = $LibraryContentTypes | Where-Object { $LegacyContentTypesHash.ContainsKey($_.Name) } | ForEach-Object {
        [PSCustomObject]@{
            LegacyName       = $_.Name
        }
    }
    return $LibraryLegacyContentTypes
}
Function EnsureTaxonomyCache ($Context) {
    if ($null -eq $script:TaxonomyCache) {
        $TaxonomySession = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($Context)
        $TermStore = $TaxonomySession.GetDefaultSiteCollectionTermStore()
        $Context.Load($TermStore)
        $Context.Load($TermStore.Groups)
        ExecuteQueryWithRetry -Ctx $Context
        $script:TaxonomyCache = @{
            TermStore = $TermStore
            Groups    = $TermStore.Groups
            TermSets  = @{}
            Terms     = @{}
        }
    }
    return $script:TaxonomyCache
}
Function ValidateManagedMetadataColumn ($Column, $ColumnConfig) {
    $RuntimeContext = [Microsoft.SharePoint.Client.ClientRuntimeContext]$Column.Context
    $cache = EnsureTaxonomyCache -Context $RuntimeContext
    $TermStore = $cache.TermStore

    $TargetTermGroup = $cache.Groups | Where-Object { $_.Name -eq $ColumnConfig.TermGroup }
    if (-not $TargetTermGroup) {
        return $false
    }

    # Load term sets for this group (cached)
    $groupKey = $TargetTermGroup.Id.ToString()
    if (-not $cache.TermSets.ContainsKey($groupKey)) {
        $RuntimeContext.Load($TargetTermGroup.TermSets)
        ExecuteQueryWithRetry -Ctx $RuntimeContext
        $cache.TermSets[$groupKey] = $TargetTermGroup.TermSets
    }
    $termSets = $cache.TermSets[$groupKey]

    # Determine the term set based on IsTermSetECCS
    $TermSet = $ColumnConfig.TermSet
    $ECCSCode = GetPropertyBag $RuntimeContext 'customECCS'
    if ($ColumnConfig.IsTermSetECCS) {
        $TargetTermSet = $termSets | Where-Object { $_.Name -eq $ECCSCode }
        if (-not $TargetTermSet) {
            $TargetTermSet = $termSets | Where-Object { $_.Name -eq $TermSet }
        }
    } else {
        $TargetTermSet = $termSets | Where-Object { $_.Name -eq $TermSet }
    }
    if (-not $TargetTermSet) {
        return $false
    }

    # Load terms for this term set (cached)
    $termSetKey = $TargetTermSet.Id.ToString()
    if (-not $cache.Terms.ContainsKey($termSetKey)) {
        $RuntimeContext.Load($TargetTermSet.Terms)
        ExecuteQueryWithRetry -Ctx $RuntimeContext
        $cache.Terms[$termSetKey] = $TargetTermSet.Terms
    }
    $terms = $cache.Terms[$termSetKey]

    if($null -ne $ColumnConfig.Term) {
        $TargetTerm = $terms | Where-Object { $_.Name -eq $ColumnConfig.Term }
        if (-not $TargetTerm) {
            return $false
        }
    }
    else {
        $TargetTerm = $terms | Where-Object { $_.Name -eq $TermSet }
        if(-not $TargetTerm) {
            return $true
        }
    }

    # Validate if the column is mapped to the term set
    $TaxonomyField = [Microsoft.SharePoint.Client.ClientContext].GetMethod("CastTo").MakeGenericMethod([Microsoft.SharePoint.Client.Taxonomy.TaxonomyField]).Invoke($RuntimeContext, $Column)
    $RuntimeContext.Load($TaxonomyField)
    ExecuteQueryWithRetry -Ctx $RuntimeContext
    if (($TaxonomyField.TermSetId -eq $TargetTermSet.Id) -and ($TaxonomyField.SspId -eq $TermStore.Id) -and ($TaxonomyField.AnchorId -eq $TargetTerm.Id)) {
        return $true
    } else {
        return $false
    }
}

function ValidatePropertyBag {
    param (
        [Microsoft.SharePoint.Client.ClientContext] $Context,
        [bool] $IsDMSUPS,
        [string] $LanguageUPS,
        [string] $companyId
    )

    $customECCS        = GetPropertyBag $Context "customECCS"
    $customSiteType    = GetPropertyBag $Context "customSiteType"
    $customSiteLanguage = GetPropertyBag $Context "customSiteLanguage"
    if ($customECCS -ne $companyId) {
        return $false
    }
    if ($null -ne $IsDMSUPS) {
        $upsSiteType = if ($IsDMSUPS) { 'DMS' } else { 'E3' }
        if ($customSiteType -ne $upsSiteType) {
            return $false
        }
    }
    if ($null -ne $LanguageUPS) {
        if ($customSiteLanguage -ne $LanguageUPS) {
            return $false
        }
    }
    return $true
}
