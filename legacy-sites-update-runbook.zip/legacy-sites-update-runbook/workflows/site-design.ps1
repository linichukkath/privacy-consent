Import-Module "$global:CurrDir\utils\interceptor.ps1"
Import-Module "$global:CurrDir\utils\auth.ps1"
Import-Module "$global:CurrDir\utils\site.ps1"
Import-Module "$global:CurrDir\utils\columns.ps1"
Import-Module "$global:CurrDir\utils\content-types.ps1"
Import-Module "$global:CurrDir\utils\library.ps1"
Import-Module "$global:CurrDir\utils\type-convertors.ps1"
Import-Module "$global:CurrDir\utils\property-bag.ps1"
Import-Module "$global:CurrDir\utils\update-utils.ps1"

$StartDate = (Get-Date)

function ProvisionSiteDesign() {
    param(
        [Parameter(Mandatory=$true)] [psobject] $params,
        [Parameter(Mandatory=$false)] [string] $configPathOverride # this overrides the implicit config path
    )
    try {
        # Getting context using app-only authentication
        $Context = GetSPOContext -siteUrl $params.SPOURL `
            -clientId $params.ClientId `
            -tenantId $params.TenantId `
            -clientSecret $params.ClientSecret `
            -certificate $params.Certificate
        decorateContextHeaders $Context

        $configPath = "$global:CurrDir\configs\e3.json"
        if ($params.IsDMS) {
            $configPath = "$global:CurrDir\configs\e5.json"
        }

        if("" -ne $configPathOverride) {
            $configPath = $configPathOverride
        }

        # Load configurations
        $Config = Get-Content $configPath -Raw -encoding utf8 | ConvertFrom-Json

        SetSiteScripting $true $params.SPOURL # to make property bag setting work

        # Updating group ownership
        try {
            #Get all Groups
            $Groups=$Context.Web.SiteGroups
            $Context.Load($Groups)
            ExecuteQueryWithRetry -Ctx $Context
            $memberGroup = $Groups | Where-Object { $_.Title -like "*Members" }
            $ownerGroup = $Groups | Where-Object { $_.Title -like "*Owners" }
            $visitorGroup = $Groups | Where-Object { $_.Title -like "*Visitors" }
            if($null -ne $memberGroup){
                $memberGroup.Owner = $ownerGroup
                $memberGroup.Update()
            }
            if($null -ne $visitorGroup){
                $visitorGroup.Owner = $ownerGroup
                $visitorGroup.Update()
            }
            ExecuteQueryWithRetry -Ctx $Context

            Write-LogINFO "Updated group ownership to the site owner group"
        }
        catch { throw }

        EnableSPOFeatures $Context

        # Columns
        ProvisionSiteColumns $Context $Config $params.Language $params.CompanyID

        # Content Types
        ProvisionSiteContentTypes $Context $Config $params.Language

        # Libraries
        ProvisionLibraries $Context $Config $params.Language

        # Property Bag
        mapParamsFromUPSToPropertyBag $context $params

        SetSiteScripting $false $params.SPOURL

    }
    catch {
        Write-LogERR $_.Exception.Message
        return $false
    }
    finally {
        # Dispose the SharePoint context
        if($Context) {
            $Context.Dispose()
        }
        $EndDate = (Get-Date)
        Write-LogINFO '=== The site design provisioning script has ended ==='
        Write-LogINFO "Duration: $((New-TimeSpan -Start $StartDate -End $EndDate).TotalSeconds)"
    }
    return $true

}
