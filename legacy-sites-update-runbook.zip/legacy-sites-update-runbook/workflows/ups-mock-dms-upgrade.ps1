# This file mitigates UPS server on localhost for the E3 site creation
$global:CurrDir = "."

Import-Module -Name Microsoft.Online.SharePoint.PowerShell
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Taxonomy.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.DocumentManagement.dll"

Import-Module "$global:CurrDir\utils\ups.ps1"
Import-Module "$global:CurrDir\workflows\site-design.ps1"
Import-Module "$global:CurrDir\workflows\dms-upgrade.ps1"
Import-Module "$global:CurrDir\tests\integration-test.ps1"

$tenant = "allianzms"
$Params = Get-ProvisioningParameter
$siteUrl = GetRedirectedSiteUrl($Params.SPOURL)

Write-LogINFO '=== The DMS upgrade script has started ==='
StartDMSUpgrade `
    -siteUrl $siteUrl `
    -tenant $tenant `
    -companyId $Params.CompanyID `
    -siteCollectionAdminUserName $Params.O365Admin `
    -tenantAdminUserName $Params.O365Admin
    -isDMSUPS $Params.IsDMS
    -languageUPS $Params.Language