$global:CurrDir = "."
Import-Module -Name Microsoft.Online.SharePoint.PowerShell
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Taxonomy.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.DocumentManagement.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Search.dll"

Import-Module "$global:CurrDir\utils\ups.ps1"
Import-Module "$global:CurrDir\utils\interceptor.ps1"
Import-Module "$global:CurrDir\utils\auth.ps1"
Import-Module "$global:CurrDir\utils\site.ps1"
Import-Module "$global:CurrDir\utils\columns.ps1"
Import-Module "$global:CurrDir\utils\content-types.ps1"
Import-Module "$global:CurrDir\utils\library.ps1"
Import-Module "$global:CurrDir\utils\property-bag.ps1"
Import-Module "$global:CurrDir\utils\update-utils.ps1"


$siteUrl = "https://allianzms.sharepoint.com/teams/DE1890-3697408"
$language = "en-US"
$tenant = "allianzms"
# $siteCollectionAdmin = "Mesgprovisioning@allianzms.onmicrosoft.com"
$siteCollectionAdmin = "spoipg01@allianzms.onmicrosoft.com"

Function auth($url) {
    # Use ACS OAuth (app-only authentication)
    LogInToTenant -tenant $tenant
    Set-SPOUser -site $url -LoginName $siteCollectionAdmin -IsSiteCollectionAdmin $true | Out-Null
    $context = GetSPOContext -siteUrl $url
    decorateContextHeaders $context
    return $context
}

function listSitePropertyBag() {
    $context = auth $siteUrl
    ListAllCustomPropertyBagItems $context
}

# listSitePropertyBag

function getTimezone() {
    $context = auth $siteUrl
    $timezone = $context.web.regionalSettings.timeZone
    $context.Load($timezone)
    ExecuteQueryWithRetry -Ctx $Context
    return $timezone
}

# ========================================================================================
# Function to create an empty text file in the document library
function addEmptyTextFile($context, $library, $fileName) {
    $fileCreationInfo = New-Object Microsoft.SharePoint.Client.FileCreationInformation
    $fileCreationInfo.Url = $fileName
    $fileCreationInfo.Overwrite = $true
    $fileCreationInfo.Content = [System.Text.Encoding]::UTF8.GetBytes("")

    $file = $library.RootFolder.Files.Add($fileCreationInfo)
    $context.Load($file)
    ExecuteQueryWithRetry -Ctx $Context

    $properties = $file.ListItemAllFields;
    $Context.Load($properties)
    $properties["ContentTypeId"] = "0x01010096F2970EAAEF6549A6B9C6DD03401118001D4D6C2542BBBB43BD6DC1761FA54D78"
    # $properties['_ExtendedDescription'] = 'Test Extended Description'
    # $properties['Document_Class'] = 'Corporate Rule'
    $properties.Update()
    ExecuteQueryWithRetry -Ctx $Context
}

function generateFiles($context) {
    for ($i = 1; $i -le 1000; $i++) {
        $fileName = "AnotherEmptyFile_$i.txt"
        $list = GetListByEntityTypeName $context "Shared_x0020_Documents"
        addEmptyTextFile -context $context -library $list -fileName $fileName
        Write-Output "Created file: $fileName"
    }
}

# $context = auth "https://allianzms.sharepoint.com/teams/DE1214-10634596"
# generateFiles $context

# delete all items in the library function
function deleteAllItems($context, $library) {
    $query = New-Object Microsoft.SharePoint.Client.CamlQuery
    $query.ViewXml = "@
    <View Scope='RecursiveAll'>
        <Query>
            <OrderBy><FieldRef Name='ID' Ascending='TRUE'/></OrderBy>
        </Query>
        <RowLimit Paged='TRUE'>2000</RowLimit>
    </View>"

    $items = $library.GetItems($query)
    $context.Load($items)
    ExecuteQueryWithRetry -Ctx $Context

    $itemsToDelete = @()
    $items | ForEach-Object {
        $itemsToDelete += $_
    }

    $batchSize = 100
    $totalItems = $itemsToDelete.Count
    $batches = [math]::Ceiling($totalItems / $batchSize)

    for ($i = 0; $i -lt $batches; $i++) {
        $startIndex = $i * $batchSize
        $endIndex = [math]::Min($startIndex + $batchSize, $totalItems)

        for ($j = $startIndex; $j -lt $endIndex; $j++) {
            $itemsToDelete[$j].DeleteObject()
        }

        ExecuteQueryWithRetry -Ctx $Context
    }
}
# deleteAllItems $context $list

function updateDocumentsLibraryOnlyTest() {
    $siteUrl = "https://allianzms.sharepoint.com/teams/DE1890-3681105"
    $ctx = auth $siteUrl
    $Library = GetListByEntityTypeName $ctx "Shared_x0020_Documents"

    $documentClassTerms = getDocumentClassTerms $ctx
    $contentTypeDefinitions = Get-Content "$global:CurrDir\configs\content-types.json" -Raw | ConvertFrom-Json
    $updateConfigPath = "$global:CurrDir\configs\legacy-to-e5-update.json"
    $updateConfig = Get-Content $updateConfigPath -Raw | ConvertFrom-Json
    $language = "en-US"
    $timeZoneOffset = getTimezoneOffset -ctx $ctx

    updateItems `
        -siteUrl $siteUrl `
        -libraryGUID $Library.Id.ToString() `
        -libraryTitle $Library.Title `
        -contentTypesConfig $contentTypeDefinitions `
        -documentClassTerms $documentClassTerms `
        -updateConfig $updateConfig `
        -language $language `
        -timeZoneOffset $timeZoneOffset
}

# updateDocumentsLibraryOnlyTest

function selectItemById($id, $listGUID, $headers, $siteUrl) {
    # $url = "$siteUrl/_api/web/lists(guid'$listGUID')/items($id)?`$select=ComplianceTag,ComplianceTagWrittenTime,File,Title,Modified,Editor/Name,EditorId,ContentTypeId,ContentType/Name,ContentType/Parent/Id,ID,FileSystemObjectType,Document_Class,DocumentSetDescription&`$expand=Editor,ContentType,ContentType/Parent,File/Name"
    $url = "$siteUrl/_api/web/lists(guid'$listGUID')/items($id)?`$select=File,Title,ComplianceTag"
    try {
        $response = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
        $json = $response.Replace("""ID""", "_ID") | ConvertFrom-Json
        $item = $json.d
        return $item
    }
    catch {
        Write-LogINFO "Error: $($_.Exception.Message)"
    }
}

function updateItemTest() {

    $siteUrl = "https://allianzms.sharepoint.com/teams/DE1890-3681105"
    $ctx = auth $siteUrl

    $accessToken = $ctx.AuthState.Token

    $headers = @{
        Authorization = "Bearer $accessToken"
        Accept        = "application/json;odata=verbose"
    }
    $listGUID = "912a31a4-300b-4287-aba5-b3b51053b22e"
    $id = 5183
    $timeZoneOffset = getTimezoneOffset -ctx $ctx
    $documentClassTerms = getDocumentClassTerms $ctx
    $contentTypeDefinitions = Get-Content "$global:CurrDir\configs\content-types.json" -Raw | ConvertFrom-Json

    $wantedContentTypeId = "0x01010001230DD08B124A94B2819109BC903B8C00C3AB33C5905B7E478C2DE764E72388D6"

    $item = selectItemById -id $id -listGUID $listGUID -headers $headers -siteUrl $siteUrl

    if (hasWantedContentTypeAlready -item $item -contentTypesConfig $contentTypeDefinitions) {
        Write-LogINFO "Item already has the wanted content type"
    }

    $hashArguments = @{
        siteUrl             = $siteUrl
        libraryGUID         = $listGUID
        headers             = $headers
        item                = $item
        wantedContentTypeId = $wantedContentTypeId
        documentClassTerms  = $documentClassTerms
        timeZoneOffset      = $timeZoneOffset

    }
    $exception = &$updateItem @hashArguments
    if ($exception) {
        Write-LogERR $exception
    }
}

# updateItemTest


function updateRecordLabelTest() {
    $siteUrl = "https://allianzms.sharepoint.com/teams/DE1890-3681105"
    $ctx = auth $siteUrl

    $accessToken = $ctx.AuthState.Token

    $headers = @{
        Authorization = "Bearer $accessToken"
        Accept        = "application/json;odata=verbose"
    }

    $listGUID = "912a31a4-300b-4287-aba5-b3b51053b22e"
    $id = 5183


    $item = selectItemById -id $id -listGUID $listGUID -headers $headers -siteUrl $siteUrl
    $fieldCheckUrl = "$siteUrl/_api/web/lists(guid'$listGUID')/fields"

    try {
        $response = Invoke-RestMethod -Uri $fieldCheckUrl -Headers $headers -Method Get
        # $json =  $response.Replace("""ID""", "_ID") | ConvertFrom-Json
        $fields = $response.d.results
        #iterate through fields and print their InternalName
        $fields | ForEach-Object {
            Write-LogINFO $_.InternalName
        }
        Write-LogINFO "Fields count: $($fields.Count)"

    }
    catch {
        Write-LogINFO "Error: $($_.Exception.Message)"
    }


    Write-LogINFO $item.ContentType.Name
}

updateRecordLabelTest

function deleteColumnsFromLibraryTest() {
    $siteUrl = "https://allianzms.sharepoint.com/teams/DE1214-7254907"
    $libraryName = "Shared_x0020_Documents"

    $context = auth $siteUrl
    $library = GetListByEntityTypeName $context $libraryName

    $updateConfig = Get-Content "$global:CurrDir\configs\libraries.json" -Raw | ConvertFrom-Json
    $libraryConfig = $updateConfig.Shared_x0020_Documents
    deleteColumnsFromLibrary $context $libraryConfig $library
}
# deleteColumnsFromLibraryTest

