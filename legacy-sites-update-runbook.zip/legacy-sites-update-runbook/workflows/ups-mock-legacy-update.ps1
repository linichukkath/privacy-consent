$global:CurrDir = "."

Import-Module -Name Microsoft.Online.SharePoint.PowerShell
Add-Type -Path "$global:CurrDir\dll\Microsoft.Identity.Client.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Taxonomy.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.DocumentManagement.dll"

Import-Module "$global:CurrDir\utils\ups.ps1"
Import-Module "$global:CurrDir\utils\site.ps1"
Import-Module "$global:CurrDir\utils\legacy-update-util.ps1"

$tenant = "allianzms"
$Params = Get-ProvisioningParameters
$siteUrl = GetRedirectedSiteUrl($Params.SPOURL)

Write-LogINFO '=== The legacy update script has started ==='
startLegacyUpdate `
    -url $siteUrl `
    -isSourceDMSUpgrade $false `
    -companyId $Params.CompanyID `
    -libraryUrl $null `
    -tenant $tenant `
    -siteCollectionAdminUserName $Params.O365Admin `
    -tenantAdminUserName $Params.O365Admin `
    -isDMSUPS $Params.IsDMS `
    -languageUPS $Params.Language