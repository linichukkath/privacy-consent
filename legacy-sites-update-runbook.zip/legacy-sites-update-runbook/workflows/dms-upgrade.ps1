Import-Module "$global:CurrDir\utils\interceptor.ps1"
Import-Module "$global:CurrDir\utils\auth.ps1"
Import-Module "$global:CurrDir\utils\site.ps1"
Import-Module "$global:CurrDir\utils\columns.ps1"
Import-Module "$global:CurrDir\utils\content-types.ps1"
Import-Module "$global:CurrDir\utils\library.ps1"
Import-Module "$global:CurrDir\utils\property-bag.ps1"
Import-Module "$global:CurrDir\utils\update-utils.ps1"
Import-Module "$global:CurrDir\utils\legacy-update-util.ps1"
Import-Module "$global:CurrDir\tests\integration-test.ps1"

$clientId = "d4dfa3f9-88ac-4d83-af72-cc72ff128699"
$clientSecret = "DLX8Q~yxmmOGCR2tYQJF85XrlTHT-OyT-g_88afB"
$tenantId = "6e06e42d-6925-47c6-b9e7-9581c7ca302a"

Function ApplyDmsTemplateToSite($url, $language, $updateConfig, $LibraryDefinitions, $context) {

    Write-LogINFO "Looking for all the updatable document libraries..."
    $libraryIgnoreConfigPath = "$global:CurrDir\configs\library-ignore.json"
    $libraryIgnoreConfig = Get-Content $libraryIgnoreConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $Libraries = GetAllDocumentLibraries -Ctx $context -Config $libraryIgnoreConfig
    Write-LogINFO "Number of updatable document libraries found: $($Libraries.Count)"

    ProvisionSiteColumns $Context $updateConfig $language $companyID
    ProvisionSiteContentTypes $Context $updateConfig $language

    # Views and library content types
    Write-LogINFO 'Upgrading libraries'
    $DefaultLibraryEntityTypeName = $updateConfig.DefaultLibraryConfigKey
    $LibraryConfig = $LibraryDefinitions.$DefaultLibraryEntityTypeName

    $SiteConfigPath = "$global:CurrDir\configs\e5.json"
    $SiteConfig = Get-Content $SiteConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $LibraryConfigItem = $SiteConfig.Libraries[0]

    overrideSettings $LibraryConfig $LibraryConfigItem.Overrides

    foreach ($Library in $Libraries) {
        $DefaultColumnValues = GetManagedMetadataDefaultValue -Context $Context -Library $Library
        UpdateLibrary $Context $LibraryConfig $Library $DefaultLibraryEntityTypeName $ViewDefinitions $updateConfig.Views $language $DefaultColumnValues
    }
    SetSiteScripting $true $url # to make property bag setting work
    SetPropertyBag $context 'customSiteType' 'DMS' $true
    # SetPropertyBag $context 'customSiteUpdatedOn' (Get-Date) $true
    SetPropertyBag $context 'customDateUpgradedToDMS' (Get-Date) $true
    SetSiteScripting $false $url # to make property bag setting work
}

Function UpgradeSiteToDms($url, $companyId) {
    try {
        $context = GetSPOContext -siteUrl $url -clientId $clientId -clientSecret $clientSecret -tenantId $tenantId
        if($null -eq $context) {
            Write-LogINFO "Unable to create context, skipping site $url"
            return
        }
        $context.Load($context.Web)
        ExecuteQueryWithRetry -Ctx $Context

        $updateConfigPath = "$global:CurrDir\configs\e3-to-e5-upgrade.json"
        $updateConfig = Get-Content $updateConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $language = GetSitelanguage $context $context.Web
        $LibraryDefinitions = Get-Content "$global:CurrDir\configs\libraries.json" -Raw -encoding utf8 | ConvertFrom-Json
        $ViewDefinitions = Get-Content "$global:CurrDir\configs\views.json" -Raw -encoding utf8 | ConvertFrom-Json
        if ($null -ne $updateConfig.Views) {
            OverrideViewSettings $ViewDefinitions $updateConfig.Views
        }

        $siteType = GetPropertyBag $context 'customSiteType'
        $siteUpdatedOn = GetPropertyBag $context 'customSiteUpdatedOn'


        if ($siteType -eq "E3" -and $null -ne $siteUpdatedOn){
            #E3 site
            ApplyDmsTemplateToSite -Url $url -language $language -updateConfig $updateConfig -LibraryDefinitions $LibraryDefinitions -context $context
        }
        else {
            #legacy E3 site
            startLegacyUpdate `
                -url $url `
                -context $context `
                -language $language `
                -LibraryDefinitions $LibraryDefinitions `
                -ViewDefinitions $ViewDefinitions `
                -isSourceDMSUpgrade $true `
                -companyId $companyId `
                -libraryUrl $libraryUrl `
                -tenant $tenant `
                -siteCollectionAdminUserName $siteCollectionAdminUserName `
                -tenantAdminUserName $tenantAdminUserName

            ApplyDmsTemplateToSite `
                -Url $url `
                -language $language `
                -updateConfig $updateConfig `
                -LibraryDefinitions $LibraryDefinitions `
                -context $context
        }
        Write-LogInfo "Successfully upgraded SP Site: $($url) to DMS"
        return $true
    }
    catch {
        Write-LogERR "Error upgrading SP Site: $($url) to DMS : $($_.Exception.Message) at line $($_.InvocationInfo.ScriptLineNumber): $($_.InvocationInfo.Line)"
        return $false
    }
}
function StartDMSUpgrade {
    param(
        [string]$siteUrl,
        [string]$tenant,
        [string]$companyId,
        [string]$siteCollectionAdminUserName,
        [string]$tenantAdminUserName,
        [bool]$isDMSUPS,
        [string]$languageUPS
    )

    # Upgrade the parent SharePoint site to DMS
    $isParentSiteUpdated = UpgradeSiteToDms -url $siteUrl -companyId $companyId

    $areAllChannelsUpdated = $true
    # Retrieve all private channels associated with the site
    $PrivateChannels = GetPrivateChannels $siteUrl

    # Upgrade each private channel to DMS
    foreach ($channel in $PrivateChannels) {
        $channelContext = GetSPOContext -siteUrl $channel.Url -clientId $clientId -clientSecret $clientSecret -tenantId $tenantId
        if($null -eq $channelContext) {
            Write-LogINFO "Unable to create context, skipping site $($channel.Url)"
            continue
        }
        $channelContext.Load($channelContext.Web)
        $channelContext.ExecuteQuery()
        $channelUrl = $channel.Url

        $result = UpgradeSiteToDms -url $channelUrl -companyId $companyId

        if ($result) {
            Write-LogINFO "DMS upgrade completed for private channel - $($channelUrl)"
        } else {
            Write-LogERR "DMS upgrade failed for private channel - $($channelUrl)"
            $areAllChannelsUpdated = $false
            continue
        }
    }

    if ($isParentSiteUpdated -and $areAllChannelsUpdated) {
        $mainSiteCtx = GetSPOContext -siteUrl $siteUrl -clientId $clientId -clientSecret $clientSecret -tenantId $tenantId
        $isParentSiteValid = ValidateSite -siteUrl $siteUrl -tenant $tenant -isDMSUPS $isDMSUPS -languageUPS $languageUPS -context $mainSiteCtx -companyId $companyId

        if ($isParentSiteValid) {
            Write-LogINFO "Site $siteUrl DMS template is valid"
        } else {
            Write-LogERR "Site $siteUrl DMS template is invalid."
        }

        foreach ($channel in $PrivateChannels) {
            $channelCtx = GetSPOContext -siteUrl $channel.Url -clientId $clientId -clientSecret $clientSecret -tenantId $tenantId
            $isPrivateChannelSiteValid = ValidateSite -siteUrl $channel.Url -tenant $tenant -isDMSUPS $isDMSUPS -languageUPS $languageUPS -context $channelCtx -companyId $companyId
            if ($isPrivateChannelSiteValid) {
                Write-LogINFO "Site (private channel) $($channel.Url) DMS template is valid"
            } else {
                Write-LogERR "Site (private channel) $($channel.Url) DMS template is invalid"
            }
            RemoveSiteCollectionAdmin $channel.Url $tenantAdminUserName
        }
    }
    return $isParentSiteUpdated -and $areAllChannelsUpdated
}