$global:CurrDir = "."
Import-Module -Name Microsoft.Online.SharePoint.PowerShell
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Taxonomy.dll"

Import-Module "$global:CurrDir\utils\ups.ps1"
Import-Module "$global:CurrDir\utils\auth.ps1"

$term = @{
    name = @{
        en = "House7"
        de = "Haus34"
        it = "Casa35"
        fr = "Maison27"
        pt = "Test4"
        es = "Test5"
    }
    defaultLanguage = "en"
    eccs = @("AA0001")
    type = "Dossier department"
    availableForTagging = $true
}

$languageMapping = @{
    en = 1033
    de = 1031
    fr = 1036
    it = 1040
    es = 1034
    pt = 2070
}

Function createTerm($termConfig) {
    try{
        $siteCollectionAdminCred = Get-Password "spoipg01@allianzms.onmicrosoft.com"
        $context = GetSPOContext "https://allianzms-admin.sharepoint.com" $siteCollectionAdminCred
        decorateContextHeaders $context

        $TaxonomySession = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($context)
        $TermStore = $TaxonomySession.GetDefaultSiteCollectionTermStore()
        $context.Load($TaxonomySession)
        $context.Load($TermStore)
        ExecuteQueryWithRetry -Ctx $Context

        $TermGroup = $TermStore.Groups.GetByName("Document management")
        $context.Load($TermGroup)

        $defaultLanguageId = $languageMapping.($termConfig.defaultLanguage)

        $TermSets = $TermGroup.TermSets
        $context.Load($TermSets)
        ExecuteQueryWithRetry -Ctx $Context

        foreach ($eccsCode in $termConfig.eccs) {
            Write-LogINFO "Looking for the term set named: '$eccsCode'..."
            $TermSet = $TermSets | Where-Object {$_.Name -eq $eccsCode}

            If(-not $TermSet) {
                Write-LogINFO "Term set named: '$eccsCode' not found. Creating a new one..."
                $TermSet = $TermGroup.CreateTermSet($eccsCode, [System.Guid]::NewGuid().toString(), $defaultLanguageId)
                $context.Load($TermSet)
                ExecuteQueryWithRetry -Ctx $Context
                Write-LogINFO "Term set '$eccsCode' created successfully."
            } else {
                Write-LogINFO "Term set '$eccsCode' exists already!"
            }

            $Terms = $TermSet.Terms
            $context.load($Terms)
            ExecuteQueryWithRetry -Ctx $Context

            if(($null -ne $ParentTerm) -or ($ParentTerm -ne '')){
                $TermType = $Terms | Where-Object {$_.Name -eq $termConfig.type}
            }
            else{
                $TermType = $Terms | Where-Object {$_.Name -eq 'Document class'}
            }

            If(-not $TermType) {
                Write-LogINFO "Term type '$($termConfig.type)' doesn't exist. Creating a new one..."
                # if the term type doesnt exist create one
                $TermType = $TermSet.CreateTerm($termConfig.type, $defaultLanguageId, [System.Guid]::NewGuid().toString()) # how about other languages?
                $TermType.IsAvailableForTagging = $false
                ExecuteQueryWithRetry -Ctx $Context
                $TermStore.CommitAll()

                Write-LogINFO "New term type '$($termConfig.type)' created successfully."
            } else {
                if(($null -ne $ParentTerm) -or ($ParentTerm -ne '')){
                    Write-LogINFO "Term type '$($termConfig.type)' exists already!"
                }
                else{
                    Write-LogINFO "Term type 'Document class' exists already!"
                }
            }

            $TermTypeTerms = $TermType.Terms
            $context.load($TermTypeTerms)
            ExecuteQueryWithRetry -Ctx $Context
            $existingTerm = $TermTypeTerms | Where-Object {$_.Name -eq $termConfig.name.($termConfig.defaultLanguage)}
            if ($existingTerm) {
                Write-LogINFO "Term '$($termConfig.name.($termConfig.defaultLanguage))' already exists in the term type $($termConfig.type)."
                return
            }

            Write-LogINFO "Creating term in the default language $($termConfig.name.($termConfig.defaultLanguage))..."

            if($null -ne $termConfig.parent){
                $ParentTerm = $TaxonomySession.GetTerm($termConfig.parent)
                $context.load($ParentTerm)
                ExecuteQueryWithRetry -Ctx $Context
            }
            else{
                $ParentTerm = $TermType
            }

            if(($null -ne $ParentTerm) -or ($ParentTerm -ne '')){
                $id = [System.Guid]::NewGuid().toString()
                $NewTerm = $ParentTerm.CreateTerm($termConfig.name.($termConfig.defaultLanguage), $defaultLanguageId, $id)
            }
            else{
                Write-LogINFO "Parent Term with ID '$($termConfig.parent)' not found in the term type $($termConfig.type)."
                return
            }
            $NewTerm.IsAvailableForTagging = $termConfig.availableForTagging
            foreach ($language in $termConfig.name.Keys) {
                if ($language -ne $termConfig.defaultLanguage) {
                    Write-LogINFO "Creating term in $language : $($termConfig.name[$language])..."
                    $NewTerm.CreateLabel($termConfig.name[$language], $languageMapping[$language], $False) | Out-Null
                }
            }
            ExecuteQueryWithRetry -Ctx $Context
            $TermStore.CommitAll()
            Write-LogINFO "Terms created successfully in '$eccsCode'."
            retrun $id
        }
    }
    catch {
        return $null
    }
}

createTerm $term