# This file mitigates UPS server on localhost for the E3 site creation
$global:CurrDir = "."

Import-Module -Name Microsoft.Online.SharePoint.PowerShell
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.Taxonomy.dll"
Add-Type -Path "$global:CurrDir\dll\Microsoft.SharePoint.Client.DocumentManagement.dll"

Import-Module "$global:CurrDir\utils\ups.ps1"
Import-Module "$global:CurrDir\workflows\site-design.ps1"
Import-Module "$global:CurrDir\tests\integration-test.ps1"

$tenant = "allianzms"
$storageQuota = "1"
$template = "STS#3"
$tenantAdminUserName = "spoipg01@allianzms.onmicrosoft.com"
$clientId = "d4dfa3f9-88ac-4d83-af72-cc72ff128699"
$clientSecret = "DLX8Q~yxmmOGCR2tYQJF85XrlTHT-OyT-g_88afB"
$tenantId = "6e06e42d-6925-47c6-b9e7-9581c7ca302a"

$Params = Get-ProvisioningParameter

try {
    Write-LogINFO '=== The DMS provisioning script has started ==='
    ProvisionSite -tenant $tenant -owner $Params.Admin1 -url $Params.SPOURL -title $Params.Title -siteCollectionAdmin $Params.O365Admin -template $template -storagequota $storageQuota

    ProvisionSiteDesign $Params

    $siteUrl = $Params.SPOURL
    $validationCtx = GetSPOContext -siteUrl $siteUrl -clientId $clientId -clientSecret $clientSecret -tenantId $tenantId
    $isSiteValid = ValidateSite -siteUrl $siteUrl -tenant $tenant -isDMSUPS $Params.IsDMS -languageUPS $Params.Language -context $validationCtx -companyId $Params.companyID
    if($isSiteValid) {
        Write-LogINFO "Successfully provisioned site $($siteUrl)."
    } else {
        Write-LogERR "Site provisioning $($siteUrl) was incomplete."
    }

    # Remove temporary site collection admin
    RemoveSiteCollectionAdmin $Params.SPOURL $Params.O365Admin
}
catch {
    Write-LogERR $_.Exception.Message
    return
}
