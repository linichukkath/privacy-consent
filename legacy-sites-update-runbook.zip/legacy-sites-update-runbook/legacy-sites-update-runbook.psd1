@{
    ModuleVersion = '2.0.1'
    RootModule = 'legacy-sites-update-runbook.psm1'
    RequiredModules = @(
        # Microsoft.Online.SharePoint.PowerShell is imported explicitly in the runbook script
        # BEFORE this module loads, to avoid DLL version conflicts. Do NOT add it here
        # as it causes a redundant import (~100 cmdlet exports repeated).
    )
    Description = 'Legacy SharePoint sites update automation with certificate-based app-only authentication'
    Author = 'Allianz Workplace Services'
}