$global:CurrDir = $PSScriptRoot

# Only load DLLs if they haven't been loaded by Microsoft.Online.SharePoint.PowerShell module
# Check if the ClientContext type is already loaded
$clientContextType = [System.AppDomain]::CurrentDomain.GetAssemblies() |
    Where-Object { $_.GetName().Name -eq "Microsoft.SharePoint.Client" }

if (-not $clientContextType) {
    Write-Verbose "Loading SharePoint Client DLLs from module directory..."
    Add-Type -Path "$PSScriptRoot\dll\Microsoft.SharePoint.Client.dll"
    Add-Type -Path "$PSScriptRoot\dll\Microsoft.SharePoint.Client.Runtime.dll"
    Add-Type -Path "$PSScriptRoot\dll\Microsoft.SharePoint.Client.Taxonomy.dll"
    Add-Type -Path "$PSScriptRoot\dll\Microsoft.SharePoint.Client.DocumentManagement.dll"
}
else {
    Write-Verbose "SharePoint Client DLLs already loaded (version: $($clientContextType.GetName().Version)). Loading additional DLLs..."

    # Even if base DLLs are loaded, we need to ensure Taxonomy and DocumentManagement are loaded
    # These might not be included in the Microsoft.Online.SharePoint.PowerShell module
    $taxonomyType = [System.AppDomain]::CurrentDomain.GetAssemblies() |
        Where-Object { $_.GetName().Name -eq "Microsoft.SharePoint.Client.Taxonomy" }

    if (-not $taxonomyType) {
        Write-Verbose "Loading SharePoint Taxonomy DLL..."
        Add-Type -Path "$PSScriptRoot\dll\Microsoft.SharePoint.Client.Taxonomy.dll"
    }

    $docMgmtType = [System.AppDomain]::CurrentDomain.GetAssemblies() |
        Where-Object { $_.GetName().Name -eq "Microsoft.SharePoint.Client.DocumentManagement" }

    if (-not $docMgmtType) {
        Write-Verbose "Loading SharePoint DocumentManagement DLL..."
        Add-Type -Path "$PSScriptRoot\dll\Microsoft.SharePoint.Client.DocumentManagement.dll"
    }
}

# Load MSAL (Microsoft.Identity.Client) for certificate-based authentication
Write-Verbose "Loading MSAL and dependencies..."
$msalType = [System.AppDomain]::CurrentDomain.GetAssemblies() |
    Where-Object { $_.GetName().Name -eq "Microsoft.Identity.Client" }

if (-not $msalType) {
    try {
        # Load dependencies in correct order
        $dependencies = @(
            "System.Runtime.CompilerServices.Unsafe.dll",
            "System.Memory.dll",
            "System.Text.Json.dll",
            "Microsoft.IdentityModel.Abstractions.dll",
            "Microsoft.Identity.Client.dll"
        )

        foreach ($dll in $dependencies) {
            $dllPath = "$PSScriptRoot\dll\$dll"
            if (Test-Path $dllPath) {
                # Check if not already loaded
                $assemblyName = [System.IO.Path]::GetFileNameWithoutExtension($dll)
                $existingAssembly = [System.AppDomain]::CurrentDomain.GetAssemblies() |
                    Where-Object { $_.GetName().Name -eq $assemblyName }

                if (-not $existingAssembly) {
                    try {
                        Add-Type -Path $dllPath -ErrorAction Stop
                        Write-Verbose "Loaded $dll"
                    }
                    catch {
                        Write-Warning "Failed to load $dll`: $_"
                        # Continue loading other DLLs
                    }
                }
                else {
                    Write-Verbose "$dll already loaded"
                }
            }
            else {
                Write-Verbose "Skipping missing dependency: $dll"
            }
        }

        Write-Verbose "MSAL library loaded successfully"
    }
    catch {
        Write-Warning "Failed to load MSAL library: $_"
        Write-Warning "Certificate-based authentication will fall back to client secret"
        # Don't throw - continue module loading
    }
}
else {
    Write-Verbose "Microsoft.Identity.Client already loaded (version: $($msalType.GetName().Version))"
}

# Dot-source all utilities in dependency order so functions land directly in this
# module's scope and get exported automatically when this module is imported.
# (Nested Import-Module -Global calls do NOT reliably re-export to the true global
# scope when this script itself runs as another module's RootModule — dot-sourcing avoids that.)
# Capture root path first: dot-sourcing shares scope, so each dot-sourced file's own
# $PSScriptRoot would otherwise overwrite ours as soon as it runs.
$moduleRoot = $PSScriptRoot

# Group 1: No dependencies (leaf modules)
. "$moduleRoot\utils\runbook.ps1"
. "$moduleRoot\utils\auth.ps1"
. "$moduleRoot\utils\migration-tracker.ps1"
. "$moduleRoot\utils\interceptor.ps1"
. "$moduleRoot\utils\site.ps1"
. "$moduleRoot\utils\property-bag.ps1"
. "$moduleRoot\utils\update-utils.ps1"
. "$moduleRoot\utils\checked-out-files-detection.ps1"
. "$moduleRoot\utils\type-convertors.ps1"
. "$moduleRoot\utils\selectors.ps1"
. "$moduleRoot\utils\configuration-item.ps1"

# Group 2: Field type handlers (no dependencies on other utils)
. "$moduleRoot\utils\fields\field.ps1"
. "$moduleRoot\utils\fields\choice.ps1"
. "$moduleRoot\utils\fields\boolean.ps1"
. "$moduleRoot\utils\fields\currency.ps1"
. "$moduleRoot\utils\fields\date-time.ps1"
. "$moduleRoot\utils\fields\managed-metadata.ps1"
. "$moduleRoot\utils\fields\note.ps1"
. "$moduleRoot\utils\fields\number.ps1"
. "$moduleRoot\utils\fields\text.ps1"
. "$moduleRoot\utils\fields\user.ps1"

# Group 3: Depend on Group 1 and 2
. "$moduleRoot\utils\columns.ps1"
. "$moduleRoot\utils\content-types.ps1"
. "$moduleRoot\utils\library.ps1"

# Group 4: Depends on all above
. "$moduleRoot\tests\integration-test.ps1"
. "$moduleRoot\utils\legacy-update-util.ps1"
. "$moduleRoot\workflows\site-design.ps1"